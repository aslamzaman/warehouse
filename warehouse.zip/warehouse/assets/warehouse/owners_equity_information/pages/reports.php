<?php
session_start();
// reports.php
date_default_timezone_set("Asia/Dhaka");
$title ="Owners Equity Information";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
require_once ('../classes/account_chart_information_class.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
$d1 = $_POST['dt1'];
$d2 = $_POST['dt2'];

function customPageHeader(){?>	
<style>
	@media print
	{
		#com_name{display: none;}
		#hide{display: none;}
		#add{display: none;}
		#close{display: none;}
		#print{display: none;}
		
		@page{margin-top:72px;}
		@page{margin-left:72px;}
		@page{margin-right:72px;}
		@page{margin-bottom:54px;}
		
		body{margin: 0px;}

		#tbl tbody td{border: 1px solid black;}
		#tbl thead th{border: 1px solid black;}
	}
	
	
		.doubleUnderline{
		  border-bottom:1px solid #000;
		  text-decoration:underline;
		  display:inline-block;
		}	
	
</style>
<?php };?>
	

<div class="row" id="page">
	<div class="col-sm-12">
		<?php
			echo $company_name->show_html($company_id);
		?>
 	</div>
	<div class="col-sm-12">
		<h3 class="text-primary"><u>Owners Equity Information</u></h3>
		<p>Period: <?php echo "$d1 to $d2";?></p>
 	</div>
 	<div class="col-sm-12">
 	    <p class="text-right"><?php echo date("Y-m-d");?></p>
		<div class="table-responsive">		
			<table class="table table-striped" id="tbl">
				<thead>
					<tr>
						<th>Date</th>	
						<th>Descriptions</th>					
						<th class='text-right'>Cash In</th>
						<th class='text-right'>Cash Out</th>
						<th class='text-right'>Balance</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$account_chart_information->balcne_create($company_id,$d1,$d2);
					?>
				</tbody>
			</table>
		</div>	
 	</div>
 	<div class="col-sm-12" id="hide">
		<?php 
			require_once ('owners_equity_info.php');
		?>	
	</div>
</div>	
<script>
 	$(document).ready(function(){
 	    $('[data-toggle="tooltip"]').tooltip();
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
