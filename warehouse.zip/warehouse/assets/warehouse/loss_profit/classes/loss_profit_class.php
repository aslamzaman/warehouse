<?php
class loss_profit_class
{

	public function lossProfit($company_id,$d1,$d2)
	{
		$exp = $this->expance($company_id,$d1,$d2);
		$rev = $this->revenue($company_id,$d1,$d2);	
		
		$pIn = $this->product_in($company_id,$d1,$d2);
		$pOut = $this->product_out($company_id,$d1,$d2);

		$cp = $pIn + $exp;
		$sp = $pOut+ $rev;
		$profit = $sp - $cp;

		
		echo "<tr>\n";
		echo "<td>Cost Price (Total Purchase Cost + Total Expanses)</td>\n";
		echo "<td class='text-right'>".number_format($cp,2)."</td>\n";
		echo "</tr>\n";
		
		echo "<tr>\n";
		echo "<td>Sales Pricre (Total Sales Price + Total Revenue)</td>\n";
		echo "<td class='text-right'>".number_format($sp,2)."</td>\n";
		echo "</tr>\n";		
		
		$percnt = 0;
		$pro = "";
		$n = "";
		if($profit < 0 )
		{
			$pro = "Loss";
			$n = -1;
			$a = $cp - $sp;
			if($cp < 1)
			{
				$percnt = 0;
			}
			else
			{
				$percnt = ($a / $cp)*100;	
			}
			
		}
		else
		{
			$pro = "Profit";
			$n = 1;	
			$a =  $sp - $cp;
			if($cp < 1)
			{			
				$percnt = 0;
			}
			else
			{
				$percnt = ($a / $cp)*100;
			}
	
			
		}		
		echo "<tr>\n";
		echo "<td>$pro</td>\n";
		echo "<td class='text-right'>".number_format($profit*$n,2)."</td>\n";
		echo "</tr>\n";
		
		echo "<tr>\n";
		echo "<td><strong>$pro in percent</strong></td>\n";
		echo "<td class='text-right'><strong><span class='doubleUnderline'>".number_format($percnt,2)."%</span></strong></td>\n";
		echo "</tr>\n";
		
	}

		


	public function revenue($company_id,$d1,$d2)
	{
		global $mysqldb;
		
		$balance = 0;
		$row = $mysqldb->select_all_row("account_chart","`company_id`= $company_id AND `account_type_id` = 4", $orderBy=false, $limit=false);
		if(count($row) > 0) 
		{
			foreach ($row as $rows)
			{

				$table = "`cash_in`";
				$field = "amount";
				$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2' AND `account_chart_id` = ".$rows['id'];	
				$ca_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
				/** -------------------------------------- */
				
				
				$table = "`cheque_in`";
				$field = "amount";
				$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2' AND `account_chart_id` = ".$rows['id'];		
				$ch_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
			
				$x = $ch_in + $ca_in;
			
			$balance = $balance + $x ;
			
			}
		}
		return $balance; 
	}


	public function expance($company_id,$d1,$d2)
	{
		global $mysqldb;
		
		$balance = 0;
		$row = $mysqldb->select_all_row("account_chart","`company_id`= $company_id AND `account_type_id` = 5", $orderBy=false, $limit=false);
		if(count($row) > 0) 
		{
			foreach ($row as $rows)
			{
				$table = "`cash_out`";
				$field = "amount";
				$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2' AND `account_chart_id` = ".$rows['id'];	
				$ca_out = $mysqldb->total_amount($table, $field, $where, $limit=false);	
				/** -------------------------------------- */
				
				
				$table = "`cheque_out`";
				$field = "amount";
				$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2' AND `account_chart_id` = ".$rows['id'];		
				$ch_out = $mysqldb->total_amount($table, $field, $where, $limit=false);	
			
			
				$x = $ch_out + $ca_out;
			
				$balance = $balance + $x ;
			
			}
		}
		return $balance; 
	}


	public function product_out($company_id,$d1,$d2)
	{
		global $db;
		$sql = "SELECT `qty` * `sales_value` as total FROM product_out  WHERE `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x = 0;
		if($Numrows > 0)
 	 	{
			$t = 0;
			while($rows= mysqli_fetch_array($result))
			{
				$t = $t + $rows['total'];
			}
			$x = $t;
		}
		else
		{
			$x = 0;	
		}
		return $x;
	}	
	

	public function product_in($company_id,$d1,$d2)
	{
		global $db;
		$sql = "SELECT `qty` * `unit_value` as total FROM product_in WHERE `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x = 0;
		if($Numrows > 0)
 	 	{
			$t = 0;
			while($rows= mysqli_fetch_array($result))
			{
				$t = $t + $rows['total'];
			}
			$x = $t;
		}
		else
		{
			$x = 0;	
		}
		return $x;
	}


	
}
$loss_profit = new loss_profit_class();
?>	
	
	