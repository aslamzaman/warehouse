<?php

/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('Asia/Dhaka');

/** PHPExcel_IOFactory */
require_once dirname(__FILE__) . '/../../../plugins/phpexcel/Classes/PHPExcel/IOFactory.php';


// echo date('H:i:s') , " Load from Excel5 template" , EOL;

$objReader = PHPExcel_IOFactory::createReader('Excel5');
/* ------------    Border   ---------------- */
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);

/*  ================ Customize section ================  */
/* ------------------------------------------------------------------ */
$objPHPExcel = $objReader->load("../excel/x.xls"); /** Load Excel File */
//=========Statement Updae End======================= 
	
	
	/** Company Name and Address */
	$company = $company_name->show_phpexcel($company_id);
	$objPHPExcel->getActiveSheet()->setCellValue('A1',$company[0]);
	$objPHPExcel->getActiveSheet()->setCellValue('A2',$company[1]);
	$objPHPExcel->getActiveSheet()->setCellValue('A3',$company[2]);
	
	
	/** Period */
	$objPHPExcel->getActiveSheet()->setCellValue('A5',"Period: ".$d1." to ". $d2);	
	
	
	/** Date Today */
	$objPHPExcel->getActiveSheet()->setCellValue('B5',"Date: ".date("Y-m-d"));
	
	
	/** Details  */	
		
		$exp = $loss_profit->expance($company_id,$d1,$d2);
		$rev = $loss_profit->revenue($company_id,$d1,$d2);	
		
		$pIn = $loss_profit->product_in($company_id,$d1,$d2);
		$pOut = $loss_profit->product_out($company_id,$d1,$d2);

		$cp = $pIn + $exp;
		$sp = $pOut+ $rev;
		$profit = $sp - $cp;
		
		
		$objPHPExcel->getActiveSheet()->setCellValue('A7',"Cost Price (Total Purchase Cost + Total Expanses)");
		$objPHPExcel->getActiveSheet()->setCellValue('B7',number_format($cp,2,'.',''));
		
		$objPHPExcel->getActiveSheet()->setCellValue('A8',"Sales Pricre (Total Sales Price + Total Revenue)");
		$objPHPExcel->getActiveSheet()->setCellValue('B8',number_format($sp,2,'.',''));
		
		
		$percnt = 0;
		$pro = "";
		$n = "";
		if($profit < 0 )
		{
			$pro = "Loss";
			$n = -1;
			$a = $cp - $sp;
			if($cp < 1)
			{
				$percnt = 0;
			}
			else
			{
				$percnt = ($a / $cp)*100;	
			}			
			
		}
		else
		{
			$pro = "Profit";
			$n = 1;	
			$a =  $sp - $cp;
			if($cp < 1)
			{
				$percnt = 0;
			}
			else
			{
				$percnt = ($a / $cp)*100;	
			}			
			
		}
		
		$objPHPExcel->getActiveSheet()->setCellValue('A9',$pro);
		$objPHPExcel->getActiveSheet()->setCellValue('B9',number_format(($profit*$n),2,'.',''));

		$objPHPExcel->getActiveSheet()->setCellValue('A10',$pro." in percent");
		$objPHPExcel->getActiveSheet()->setCellValue('B10',number_format($percnt,2,'.','')."%");
		
		
echo "<a href='loss_profit_info.xlsx' class='btn btn-primary btn-xs'>Download <i class='fa fa-file-excel-o '></i> </a>";


$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save(str_replace('.php', '.xlsx', __FILE__));

?>