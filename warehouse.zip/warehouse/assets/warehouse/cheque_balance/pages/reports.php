<?php
session_start();
// reports.php
date_default_timezone_set("Asia/Dhaka");
$title ="Bank Account Balance";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
require_once ('../classes/cheque_balance.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
$d1 = $_POST['dt1'];
$d2 = $_POST['dt2'];
$id = $_POST['id'];

function customPageHeader(){?>	
<style>
	@media print
	{
		#com_name{display: none;}
		#hide{display: none;}
		#add{display: none;}
		#close{display: none;}
		#print{display: none;}
		
		@page{margin-top:72px;}
		@page{margin-left:72px;}
		@page{margin-right:72px;}
		@page{margin-bottom:54px;}
		
		body{margin: 0px;}

		#tbl tbody td{border: 1px solid black;}
		#tbl thead th{border: 1px solid black;}
	}
</style>
<?php };?>
	

<div class="row" id="page">
	<div class="col-sm-12">
		<?php
			echo $company_name->show_html($company_id);
		?>
 	</div>
	<div class="col-sm-12">		
		<h3 class="text-primary">Bank Account Balance</h3>
		<p>
		<?php
			$table = "bank_account";
			$whereId = "`id` = $id AND`company_id`= $company_id";
			$orderBy = "`name` ASC";
			$ac_name = $mysqldb->select_one_row($table, $whereId, $orderBy);	
		echo "<strong>Account Name: ".$ac_name['name']."</strong><br>".$ac_name['address'];
		?><br>Period: <?php echo "$d1 to $d2";?></p>
				
 	</div>
 	<div class="col-sm-12"> 
		<p class="text-right"><?php echo date("Y-m-d");?></p>	
		<div class="table-responsive"> 
			<table class="table table-striped" id="tbl">
				<thead>
					<tr>
						<th>Date</th>
						<th>Descriptions</th>					
						<th class='text-right'>Cash In</th>
						<th class='text-right'>Cash Out</th>
						<th class='text-right'>Balance</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$cheque->balcne_create($company_id,$d1,$d2,$id);
					?>
				</tbody>
			</table>
		</div>	
 	</div>
 	<div class="col-sm-12" id="hide">
		<?php 
			require_once ('bank_balance.php');
		?>	
	</div>		
</div>	
<script>
 	$(document).ready(function(){
 	    $('[data-toggle="tooltip"]').tooltip();
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
