<?php

/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('Asia/Dhaka');

/** PHPExcel_IOFactory */
require_once dirname(__FILE__) . '/../../../plugins/phpexcel/Classes/PHPExcel/IOFactory.php';


// echo date('H:i:s') , " Load from Excel5 template" , EOL;

$objReader = PHPExcel_IOFactory::createReader('Excel5');
/* ------------    Border   ---------------- */
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);

/*  ================ Customize section ================  */
/* ------------------------------------------------------------------ */
$objPHPExcel = $objReader->load("../excel/x.xls"); /** Load Excel File */
//=========Statement Updae End======================= 
	
	
	/** Company Name and Address */
	$company = $company_name->show_phpexcel($company_id);
	$objPHPExcel->getActiveSheet()->setCellValue('A1',$company[0]);
	$objPHPExcel->getActiveSheet()->setCellValue('A2',$company[1]);
	$objPHPExcel->getActiveSheet()->setCellValue('A3',$company[2]);
	
	
	/** Period */
	$objPHPExcel->getActiveSheet()->setCellValue('A5',"Period: ".$d1." to ". $d2);	
	
	
	/** Date Today */
	$objPHPExcel->getActiveSheet()->setCellValue('D5',"Date: ".date("Y-m-d"));
	
	
	/** Temporary Table Data  */	
		$table = "`temp_table`";
		$orderBy ="`dt` ASC";
		$p = $mysqldb->select_all_row($table, $where=false, $orderBy, $limit=false);
			$i = 8;
			$r =array();		
		if(count($p) > 0) 
		{
			
			/** Previous Balance */
			$b = $account_chart_information->previous_expance($company_id,$d1);
			$objPHPExcel->getActiveSheet()->setCellValue('A7',$d1);
			$objPHPExcel->getActiveSheet()->setCellValue('B7',"Previous Balance");
			$objPHPExcel->getActiveSheet()->setCellValue('E7',$b);
			/** Previous Balance Border */
			$objPHPExcel->getActiveSheet()->getStyle('A7:A7')->applyFromArray($styleThinBlackBorderOutline);
			$objPHPExcel->getActiveSheet()->getStyle('B7:B7')->applyFromArray($styleThinBlackBorderOutline);
			$objPHPExcel->getActiveSheet()->getStyle('B7:D7')->applyFromArray($styleThinBlackBorderOutline);
			$objPHPExcel->getActiveSheet()->getStyle('E7:E7')->applyFromArray($styleThinBlackBorderOutline);
			
			foreach ($p as $q)
			{
				$b = $b + $q['c_in'] - $q['c_out'];
				
				$r =array("A$i","B$i","C$i","D$i","E$i");
				$objPHPExcel->getActiveSheet()->setCellValue($r[0],$q['dt']);
				$objPHPExcel->getActiveSheet()->setCellValue($r[1],$q['name']);				

				if($q['c_in'] > 0)
				{
					$objPHPExcel->getActiveSheet()->setCellValue($r[2],number_format($q['c_in'],2,'.',''));
				}
				else
				{
					$objPHPExcel->getActiveSheet()->setCellValue($r[2],"-");					
					$objPHPExcel->getActiveSheet()->getStyle($r[2])->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);

				}
				
				if($q['c_out'] > 0)
				{
					$objPHPExcel->getActiveSheet()->setCellValue($r[3],number_format($q['c_out'],2,'.',''));
				}
				else
				{
					$objPHPExcel->getActiveSheet()->setCellValue($r[3],"-");
					$objPHPExcel->getActiveSheet()->getStyle($r[3])->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
				}				
					$objPHPExcel->getActiveSheet()->setCellValue($r[4],number_format($b,2,'.',''));

					$x = "";
					$n =0;	
					while($n < 5)
					{								
						$x = "$r[$n]:$r[$n]";
						$objPHPExcel->getActiveSheet()->getStyle($x)->applyFromArray($styleThinBlackBorderOutline);
						$n++;
					}
			
				
				$i++;
					
			}
		}
echo "<a href='regular_expenditure_info.xlsx' class='btn btn-primary btn-xs'>Download <i class='fa fa-file-excel-o '></i> </a>";


$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save(str_replace('.php', '.xlsx', __FILE__));

?>