<?php
class user_check_class
{
	public function check($user)
	{
		global $mysqldb;
		$x=0;
		$table = "pw";
		$where = "`user` = '$user'";
		$p = $mysqldb->select_one_row($table, $where, $orderBy=false);
		if ($p)		
		{
			$x=1;
		}
		else
		{
			$x=0;
		}
		return $x;
	
	}
}
$user_check = new user_check_class();
?>	
	
	