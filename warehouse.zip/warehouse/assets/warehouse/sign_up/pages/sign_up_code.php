<?php
session_start();
date_default_timezone_set("Asia/Dhaka");
$title = "Sign up";
require_once ('../../layout/header/header_sign_in_up.php');
require_once ('../../layout/load/load.php');
require_once("../classes/user_check.php");

function customPageHeader(){?>
<style>
 	#margin_top{
 	 	margin-top:50px;
 	}
</style>
<?php }?>

	<div class="row" style="margin-top:50px;">
			<div class="col-sm-12">
						<?php
						if(isset($_POST['submit']))
						{
							$iuser = $_POST['iuser'];
							$ipw = $_POST['ipw'];
								$table = "pw";
								$field = "company_id";
								$startCode = "101";
								$comid = $mysqldb->code_increment($table, $field, $startCode, $where=false);
							$icompany_id = $comid;
							$ishort_name = $_POST['ishort_name'];
							$ibill_dt = date("Y-m-d",(strtotime(date("Y-m-d")) + (86400*90)));  // 90 days advance
							$ibill_amount = 0;	
							$iip_address = $mysqldb->getUserIpAddr();
							
							$check = $user_check->check($iuser);
							if ($check > 0)		
							{
								?>			
								<div class="row" id="page">
									<div class="col-sm-offset-3 col-sm-6">
										<div class="panel panel-default">
											<div class="panel-heading"><h2>Sign In</h2></div>
											<div class="panel-body">
												<p class="text-center">Email / User Name Exists!<br>Please try with another one.</p>
												<a href ="index.php" class="btn btn-default">Close</a>
											</div>
										</div>	
									</div>
								</div>		
								<?php
							}
							else
							{
								/** Create company id */
								$table = "`pw`";
								$fields = "`user`,   `pw`,   `company_id`,   `short_name`,   `bill_dt`,   `bill_amount`, `user_ip`";
								$vars = "'$iuser', '$ipw',   $icompany_id, '$ishort_name', '$ibill_dt',   $ibill_amount,'$iip_address'";
								
								$a = $mysqldb->add($table, $fields, $vars);
								if($a)
								{
									?>			
									<div class="row" id="page">
										<div class="col-sm-offset-3 col-sm-6">
											<div class="panel panel-default">
												<div class="panel-heading"><h2>Sign Up</h2></div>
												<div class="panel-body">
													<p class="text-center">Sign up successfully completed.</p>
													<a href ="../../index.php" class="btn btn-default">Sign In</a>
												</div>
											</div>	
										</div>
									</div>		
									<?php
								}
								else
								{
									?>			
									<div class="row" id="page">
										<div class="col-sm-offset-3 col-sm-6">
											<div class="panel panel-default">
												<div class="panel-heading"><h2>Sign Up</h2></div>
												<div class="panel-body">
													<p class="text-center">Sign up error!</p>
													<a href ="sign_up.php" class="btn btn-default">Close</a>
												</div>
											</div>	
										</div>
									</div>		
									<?php
								}
							}
						}
						?>				
				
			</div>

	</div>
<?php include "../../layout/footer/footer.php"; ?>


	
