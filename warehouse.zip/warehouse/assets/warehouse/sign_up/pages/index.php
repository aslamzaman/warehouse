<?php
session_start();
// date_picker.php
date_default_timezone_set("Asia/Dhaka");
$title = "Sign up";
require_once ('../../layout/header/header_sign_in_up.php');

function customPageHeader(){?>
<style>
 	#margin_top{
 	 	margin-top:50px;
 	}
</style>
<?php } ?>
	<div class="row" style="margin-top:50px;">
			<div class="col-sm-12">
				<h3 class="text-primary">Sign up</h3>
			</div>		
			<div class="col-sm-6">
				<form class="form-horizontal" role="form" action="sign_up_code.php" method="post">
					<div class="row">
						<div class="col-sm-12">
							<div class='form-group'>
								<div class='col-sm-12'>
									<label for='iuser'>Email / User Name:<small><span id='infouser' class='text-warning'></span></small></label>
									<input type='text' class='form-control' id='iuser' name='iuser' value='' placeholder='Enter Email' maxlength=100>
								</div>
							</div>
							<div class='form-group'>
								<div class='col-sm-12'>
									<label for='ipw'>Password:<small><span id='infopw' class='text-warning'></span></small></label>
									<input type='text' class='form-control' id='ipw' name='ipw' value='' placeholder='Enter Password' maxlength=100>
								</div>
							</div>
							<div class='form-group'>
								<div class='col-sm-12'>
									<label for='irpw'>Confirm Password:<small><span id='inforpw' class='text-warning'></span></small></label>
									<input type='text' class='form-control' id='irpw' name='irpw' value='' placeholder='Confirm Password' maxlength=100>
								</div>
							</div>
							<div class='form-group'>
								<div class='col-sm-12'>
									<label for='ishort_name'>Company Short Name:<small><span id='infoshort_name' class='text-warning'></span></small></label>
									<input type='text' class='form-control' id='ishort_name' name='ishort_name' value='' placeholder='Enter Short_name' maxlength=100>
								</div>
							</div>
							<br>
							<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
							<a href ="../../index.php" class="btn btn-default">Close</a>

						</div>
					</div>
				</form>	
			</div>
			<div class="col-sm-6">
			</div>

	</div>	
	<script>
		$(document).ready(function(){
		// date_picker('idt');
			$("#submit").click(function(){
				$("form span").each(function(){
					$(this).html("");
				})
				if($('#iuser').val() == ''){$('#infouser').html(' ** Please write email address'); return false;};
				if($('#ipw').val() == ''){$('#infopw').html(' ** Please type password'); return false;};
				if($('#irpw').val() == ''){$('#inforpw').html(' ** Please retype password'); return false;};
				if($('#ishort_name').val() == ''){$('#infoshort_name').html(' ** Please write short_name'); return false;};
				if(retype() < 1){$('#inforpw').html(' ** Password and confirm password does not match.'); return false;};
			
			})
			
		 $('[data-toggle="tooltip"]').tooltip();


			function retype()
			{
					var z = 0;
					var x = $('#ipw').val();
					var y = $('#irpw').val();
					if(x == y)
					{
						z =  1;
					}
					else
					{
						z = 0;
					}
				return z;	
			}
			
		})
	</script>
<?php include "../../layout/footer/footer.php";	?>


	
