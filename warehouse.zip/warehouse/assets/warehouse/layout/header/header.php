<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title;?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="shortcut icon" href="../../lib/img/logo.png">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- header.php -->	
<!-- bootstrap -->	
	<link rel="stylesheet" href="../../../plugins/bootstrap/dist/css/bootstrap.min.css">
	<script src="../../../plugins/bootstrap/dist/js/jquery.min.js"></script>
	<script src="../../../plugins/bootstrap/dist/js/bootstrap.min.js"></script>	
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">

<!-- font-awesome -->	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
<!-- Date picker -->	
	<link rel="stylesheet" href="../../../plugins/datepicker/pikaday.css">
	<script src="../../../plugins/datepicker/moment.js"></script>
	<script src="../../../plugins/datepicker/pikaday.js"></script>
	<script src="../../../plugins/datepicker/my_function.js"></script>	
	
<!-- highcharts -->
	<script src="../../../plugins/highcharts/highcharts.js"></script>
	
<!-- charts -->
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	

	<?php
	if(function_exists('customPageHeader'))
	{
		customPageHeader();
	}
	?>
    <style>
      body, .btn, .form-control, textarea{
        font-family: 'Open+Sans';
       font-size: 14px;
      }
      

    </style>	
</head>
<body>
	<?php
		if(!isset($_SESSION["pw_id"]))
		{
			echo "<script>window.location.href='http://www.aslamzaman.com/warehouse/';</script>";
		}
		include "../../layout/menu/menu.php";
	?>
	<div class="container-fluid">
