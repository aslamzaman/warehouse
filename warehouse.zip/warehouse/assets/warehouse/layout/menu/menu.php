<!-- menu.php -->	
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="../../dashboard/pages/"><span class="glyphicon glyphicon-stats"></span> <?php echo $_SESSION["short_name"];?>  </a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li class="dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-transfer"></span> Transection
					<span class="caret"></span></a>
					<ul class="dropdown-menu">
						<li class="dropdown-header">Products</li>	
						<li><a href="../../product_in/pages/">Products In</a></li>
						<li><a href="../../product_out/pages/">Products Out</a></li>
						<li class="divider"></li>
						<li class="dropdown-header">Cash</li>	
						<li><a href="../../cash_in/pages/">Cash In</a></li>
						<li><a href="../../cash_out/pages/">Cash Out</a></li>
						<li class="divider"></li>
						<li class="dropdown-header">Cheque</li>	
						<li><a href="../../cheque_in/pages/">Cheque In</a></li>	
						<li><a href="../../cheque_out/pages/">Cheque Out</a></li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>							
					</ul>
				</li>	
				<li class="dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-file"></span> Bills
					<span class="caret"></span></a>
					<ul class="dropdown-menu">
					
						<li><a href="../../bills/pages/index.php"><i class="fa fa-folder-open-o"></i> Show Bills</a></li>
						<li class="divider"></li>
						<li><a href="../../money_receipt/pages/"><i class="fa fa-newspaper-o"></i> Money Receipt</a></li>						
						<li>&nbsp;</li>
						<li>&nbsp;</li>					
					</ul>
				</li>
				
				<li class="dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-wrench"></span> Settings
					<span class="caret"></span></a>
					<ul class="dropdown-menu">	
					
						<li><a href="../../company/pages/"><i class="fa fa-building"></i> Company</a></li>
						<li><a href="../../employee/pages/"><i class="fa fa-male"></i> Employee</a></li>
						<li class="divider"></li>
						<li><a href="../../customer/pages/"><i class="fa fa-user-md"></i> Customer</a></li>
						<li><a href="../../supplier/pages/"> <i class="fa fa-user"></i> Supplier</a></li>						
						<li class="divider"></li>
						<li><a href="../../product_type/pages/"><i class="fa fa-qrcode"></i> Product Type</a></li>
						<li><a href="../../product/pages/"><i class="fa fa-bitbucket"></i> Products</a></li>
						<li><a href="../../location/pages/"><i class="fa fa-map"></i> Location</a></li>
						<li class="divider"></li>
						<li><a href="../../account_type/pages/"><i class="fa fa-object-ungroup"></i> Account Type</a></li>
						<li><a href="../../account_chart/pages/"><i class="fa fa-list-ol"></i> Chart Of Account</a></li>
						<li><a href="../../bank_account/pages/"><i class="fa fa-credit-card"></i> Bank Account</a></li>						
						<li class="divider"></li>
						<li><a href="../../vat_tax/pages/"><i class="fa fa-ticket"></i> VAT & TAX</a></li>						
						<li class="divider"></li>
						<li><a href="../../schedule/pages/"><i class="fa fa-file-excel-o"></i> Work Schedule</a></li>	
						<li class="divider"></li>						
					    <li><a href="../../change_password/pages/"><i class="fa fa-lock"></i> Change Password</a></li>	
						<li><a href="../../sign_out/pages/"><span class="glyphicon glyphicon-log-out"></span> Sign out</a></li> 
						<li>&nbsp;</li>
						<li>&nbsp;</li>	
					</ul>
				</li>
				
				<li class="dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-fire"></span> Views
					<span class="caret"></span></a>
					<ul class="dropdown-menu">
						<li><a href="../../stock_balance_all/pages/"><i class="fa fa-group"></i> All Stock</a></li>
						<li><a href="../../stock_balance_specific/pages/"><i class="fa fa-map"></i> Stock at Location</a></li>
						<li><a href="../../stock_balance_sheet/pages/"><i class="fa fa-file-excel-o"></i> Stock Balance Sheet</a></li>							
						<li class="divider"></li>
						<li><a href="../../cash_balance/pages/"><i class="fa fa-credit-card"></i> Cash Balance</a></li>						
						<li><a href="../../cheque_balance/pages/"><i class="fa fa-building"></i> Bank Balance</a></li>
						<li class="divider"></li>
						<li><a href="../../suppliers_history/pages/"><i class="fa fa-heart-o"></i> Suppliers History</a></li>						
						<li><a href="../../customers_history/pages/"><i class="fa fa-heart"></i> Customer History</a></li>						
						<li class="divider"></li>
						<li><a href="../../asset_information/pages/"><i class="fa fa-circle"></i> Asset Information</a></li>						
						<li><a href="../../liabilities_information/pages/"><i class="fa fa-circle"></i> Liabilities Information</a></li>
						<li><a href="../../owners_equity_information/pages/"><i class="fa fa-circle"></i> Owners Equity Information</a></li>
						<li><a href="../../regular_expenditure/pages/"><i class="fa fa-circle"></i> Regular Expenditure</a></li>
						<li><a href="../../revenue_information/pages/"><i class="fa fa-circle"></i> Revenue Information</a></li>
						<li><a href="../../ledger/pages/"><i class="fa fa-circle"></i> Ledger On Account</a></li>						
						<li class="divider"></li>		
						<li><a href="../../receipts_payments/pages/"><i class="fa fa-handshake-o"></i> Receipts And Payments</a></li>	
						<li><a href="../../days_summary/pages/"><i class="fa fa-cogs"></i> Days Summary</a></li>	
						<li class="divider"></li>						
						<li><a href="../../dues_information/pages/"><i class="fa fa-frown-o"></i> Dues Information</a></li>
						<li><a href="../../dues_information_all/pages/"><i class="fa fa-list-alt"></i> Dues Information All</a></li>
					
						<li class="divider"></li>	
						<li><a href="../../loss_profit/pages/"><i class="fa fa-pie-chart"></i> Loss / Profit Information</a></li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>	
					</ul>
				</li>
				<li><a href="../../helps/pages/"><i class="fa fa-question-circle"></i> Helps</a></li>
				
				<li><a href="../../comments/pages/"><i class="fa fa-comments"></i> Comments</a></li>
				
				
			</ul>
		</div>
	</div>
</nav>