	<!-- footer.php -->	
		<div class="row">
			<div  class="col-sm-12" style="height:75px;"></div>		
			<div class="col-sm-12">
				<nav class="navbar navbar-default navbar-fixed-bottom">
					<p class="text-right"><small>Design By: Aslam Zaman-2018, Email: aslamcmes@gmail.com</small></p>
				</nav>
			</div>	
		</div>
	</div> <!-- container end -->
</body>
</html>