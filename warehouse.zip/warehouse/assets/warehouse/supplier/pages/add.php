<?php
session_start();
// add.php
date_default_timezone_set("Asia/Dhaka");
$title ="Supplier Information";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	$iname = $_POST['iname'];
	$iaddress = $_POST['iaddress'];
	$idistrict_id = $_POST['idistrict_id'];
	$icountry_id = $_POST['icountry_id'];
	$imobile = $_POST['imobile'];
	$icompany_id = $company_id;

	
	$database = "`supplier`";
	$fields = "`name`,   `address`,   `district_id`,   `country_id`,   `mobile`,   `company_id`";
	$vars = "'$iname', '$iaddress', $idistrict_id, $icountry_id, '$imobile', $icompany_id";

		$a = $mysqldb->add($database, $fields, $vars);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Saved Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Saving Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}
function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Supplier Information</h3>
 	</div>
 	<div class="col-sm-12 text-right">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="add.php" method="post">
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iname'>Name:<small><span id='infoname' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iname' name='iname' value='' placeholder='Enter Name' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iaddress'>Address:<small><span id='infoaddress' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iaddress' name='iaddress' value='' placeholder='Enter Address' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idistrict_id'>District:<small><span id='infodistrict_id' class='text-warning'></span></small></label>
							<select class='form-control' id='idistrict_id' name='idistrict_id'>
							<?php 
								$table = "districts";
								$field1 = "id";
								$field2 = "name";
								$selectedId = 1;
								$orderBy = "`name` ASC";
								$mysqldb->drop_down($table, $field1, $field2, $selectedId, $where=false, $orderBy, $limit=false);
							?>						
							</select>							
						
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icountry_id'>Country:<small><span id='infocountry_id' class='text-warning'></span></small></label>
							<select class='form-control' id='icountry_id' name='icountry_id'>
							<?php 
								$table = "countries";
								$field1 = "id";
								$field2 = "name";
								$selectedId = 1;
								$orderBy = "`name` ASC";
								$mysqldb->drop_down($table, $field1, $field2, $selectedId, $where=false, $orderBy, $limit=false);
							?>						
							</select>						
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='imobile'>Mobile:<small><span id='infomobile' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='imobile' name='imobile' value='' placeholder='Enter Mobile' maxlength=100>
						</div>
					</div>

					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	// date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			if($('#iname').val() == ''){$('#infoname').html(' ** Please write name'); return false;};
			if($('#iaddress').val() == ''){$('#infoaddress').html(' ** Please write address'); return false;};
			if($('#imobile').val() == ''){$('#infomobile').html(' ** Please write mobile'); return false;};
 	 	})
 	 	
 	 $('[data-toggle="tooltip"]').tooltip();	
 	 	
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
