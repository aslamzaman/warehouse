<?php
class stock_balance
{
	
	public function avg_rate_product_in($company_id,$pid,$locId)
	{
		global $db;
		global $mysqldb;		
		$table = "product_in";
		$field = "sales_value";
		$where = "`product_id`= $pid AND `company_id` = $company_id AND `location_id` = $locId";	
		$x = $mysqldb->avg_amount($table, $field, $where, $limit=false);
		return $x;
	}
	
	
	public function balance_product($company_id,$id,$location)
	{
		global $balance;
		$d2 = date("Y-m-d");		
		$x= $balance->procuct_by_id_location($company_id,"1970-01-01",$d2,$id,$location);
		return $x;
	}

	
}
$stock = new stock_balance();
?>	
	
	