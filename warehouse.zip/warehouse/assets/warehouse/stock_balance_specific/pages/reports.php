<?php
session_start();
// reports.php
date_default_timezone_set("Asia/Dhaka");
$title ="Stock Balance";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
require_once ('../classes/stock_balance.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
$locId = $_POST["locId"];

$table = "location";
$where = "`id` = $locId";
//$orderBy = "`name` ASC";
$location=$mysqldb->select_one_row($table, $where, $orderBy=false);

function customPageHeader(){?>	
<style>
	@media print
	{
		#com_name{display: none;}
		#hide{display: none;}
		#add{display: none;}
		#close{display: none;}
		#print{display: none;}
		
		@page{margin-top:72px;}
		@page{margin-left:72px;}
		@page{margin-right:72px;}
		@page{margin-bottom:54px;}
		
		body{margin: 0px;}

		#tbl tbody td{border: 1px solid black;}
		#tbl thead th{border: 1px solid black;}
	}
</style>
<?php };?>
	

<div class="row" id="page">
	<div class="col-sm-12">
		<?php
			echo $company_name->show_html($company_id);
		?>
 	</div>
	<div class="col-sm-12">
		<h3 class="text-primary"><u>Stock Balance</u></h3>
		<p>Locations: <strong><?php echo $location['name'];?></strong></p>		
 	</div>
 	<div class="col-sm-12">
 		<p class='text-right'>Date: <?php echo date("Y-m-d");?></p>
	    <div class="table-responsive">
			<table class="table table-striped" id="tbl">
				<thead>
					<tr>
						<th>Product Name</th>					
						<th>Product Code</th>
						<th class='text-right'>Avarage Rate</th>
						<th class='text-right'>Balance</th>
		
					</tr>
				</thead>
				<tbody>
					<?php
					
						$table = "`product`";
						$where = "`company_id`= $company_id AND id IN(SELECT `product_id` FROM product_in WHERE `company_id` = $company_id AND `location_id` = $locId)";
						$orderBy = "`name` ASC";
						$p = $row = $mysqldb->select_all_row($table, $where, $orderBy, $limit=false);
						if(count($p) > 0) 
						{
							foreach ($p as $q)
							{
								$avr = $stock->avg_rate_product_in($company_id,$q['id'],$locId);
								$t = $stock->balance_product($company_id,$q['id'],$locId);
								
								$clss =false;
								if($t == 0)
								{								
									$clss = "class='warning'";
								}
								echo "<tr $clss>";
								$cd = $q['product_code']; 
								$nm = $q['name']; 
								echo "<td>$nm</td>";							
								echo "<td>$cd</td>";
								echo "<td class='text-right'>".number_format($avr,2)."</td>";
								echo "<td class='text-right'>".number_format($t,2)."</td>";
								echo "</tr>";
							}
							
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
 	<div class="col-sm-12" id="hide">
		<?php 
			require_once ('stock_balance_on_location.php');
		?>	
	</div>	
</div>	
<script>
 	$(document).ready(function(){
 	    $('[data-toggle="tooltip"]').tooltip();
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
