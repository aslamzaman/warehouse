<?php
session_start();
// reports.php
date_default_timezone_set("Asia/Dhaka");
$title ="Ledger Balance";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
require_once ('../classes/ledger.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
$d1 = $_POST['dt1'];
$d2 = $_POST['dt2'];
$id = $_POST['id'];
function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 2.5cm;}


			#tbl, th, td {
				border: 1px solid black;
			}
		#tbl th {
				border: 1px solid black;
			}			
			
			#page{margin-top: 100px;}	
 	 	}
 	</style>
<?php };?>
	

<div class="row" id="page">
	<div class="col-sm-12">		
		<h3 class="text-primary text-center">Ledger Balance</h3>
		<p class="text-center">
		<?php
		
			$table = "account_chart";
			$where = "`id` = $id AND`company_id`= $company_id";
			$orderBy = "`name` ASC";
			$ac_name = $mysqldb->select_one_row($table, $where, $orderBy=false);
			echo "<h3>Account Name: ".$ac_name['name']."</h3>";
		?><br>Period: <?php echo "$d1 to $d2";?></p>
				
 	</div>
 	<div class="col-sm-12">
		<p class="text-right"><?php echo date("Y-m-d");?></p>
		<div class="table-responsive">	
			<table class="table table-striped" id="tbl">
				<thead>
					<tr>
						<th>Date</th>	
						<th>Description</th>					
						<th class='text-right'>Cash In</th>
						<th class='text-right'>Cash Out</th>
						<th class='text-right'>Balance</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$ledger->balcne_create($company_id,$d1,$d2,$id);
					?>
				</tbody>
			</table>
		</div>	
 	</div>
 	<div class="col-sm-12" id="hide">
		<?php 
			 require_once ('ledger_info.php');
		?>	
	</div>	
</div>	
<script>
 	$(document).ready(function(){
 	    $('[data-toggle="tooltip"]').tooltip();
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
