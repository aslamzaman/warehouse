<?php
session_start();
// edit.php
date_default_timezone_set("Asia/Dhaka");
$title ="Product In Information";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
require_once ('../classes/cash_source_drop_down.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	
	$id = $_POST['id'];
	$idt = $_POST['idt'];
	$iproduct_id = $_POST['iproduct_id'];
	$iqty = $_POST['iqty'];
	$iunit_value = $_POST['iunit_value'];
	$isales_value = $_POST['isales_value'];
	$idescription = $_POST['idescription'];
	$iaccount_chart_id = $_POST['iaccount_chart_id'];
	$icash_source_id = $_POST['icash_source_id'];
	$ilocation_id = $_POST['ilocation_id'];

	
	$table = "`product_in`";
	$field_vars = "`dt` = '$idt', `product_id` = $iproduct_id, `qty` = $iqty, `unit_value` = $iunit_value, `sales_value` = $isales_value, `description` = '$idescription', `account_chart_id` = $iaccount_chart_id, `cash_source_id` = $icash_source_id, `location_id` = $ilocation_id";
	$where = "`id` = $id";	

		$a = $mysqldb->edit($table, $field_vars, $where);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Update Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Updating Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}

$id = $_GET['id'];
$table = "`product_in`";
$where = "`id` = $id";
$rows = $mysqldb->select_one_row($table, $where, $orderBy=false);
	

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Product In Information</h3>
 	</div>
 	<div class="col-sm-12 text-right">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="edit.php" method="post">
			<INPUT type="hidden" class="form-control" id="id" name="id" value="<?php echo $id;?>">						
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idt'>Date:<small><span id='infodt' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idt' name='idt' value='<?php echo $rows['dt']; ?>' placeholder='Enter Date' maxlength=10>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iproduct_id'>Product_id:<small><span id='infoproduct_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iproduct_id' name='iproduct_id'>
							<?php
								$mysqldb->drop_down("product", "id", "product_code", $rows['product_id'], "`company_id` = $company_id", "`product_code` ASC", $limit=false);							
							?>
							</select>							
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iqty'>Quantity:<small><span id='infoqty' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iqty' name='iqty' value='<?php echo $rows['qty']; ?>' placeholder='Enter Quantity' maxlength=8>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iunit_value'>Unit Value:<small><span id='infounit_value' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iunit_value' name='iunit_value' value='<?php echo $rows['unit_value']; ?>' placeholder='Enter Unit Value' maxlength=10>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='isales_value'>Sales Value:<small><span id='infosales_value' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='isales_value' name='isales_value' value='<?php echo $rows['sales_value']; ?>' placeholder='Enter Sales Value' maxlength=10>
						</div>
					</div>

					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icash_source_id'>Account Type:<small><span id='infocash_source_id' class='text-warning'></span></small></label>
							<select class='form-control' id='icash_source_id' name='icash_source_id'>
							<?php 
								$mysqldb->drop_down("cash_source","id", "name",$rows['cash_source_id'],$where=false, "`name` ASC", $limit=false);
							?>
							</select>
						</div>
					</div>
					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iaccount_chart_id'>Supplier:<small><span id='infoaccount_chart_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iaccount_chart_id' name='iaccount_chart_id'>
							<?php 
								$from_source->drop_down_table($company_id, $rows['cash_source_id'], $rows['account_chart_id']);
							?>
							</select>							
						</div>
					</div>
					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='ilocation_id'>Location:<small><span id='infolocation_id' class='text-warning'></span></small></label>
							<select class='form-control' id='ilocation_id' name='ilocation_id'>
							<?php
								$mysqldb->drop_down("location", "id", "name",$rows['location_id'],"`company_id` = $company_id", "`name` ASC", $limit=false);
							?>
							</select>								
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idescription'>Description:<small><span id='infodescription' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idescription' name='idescription' value='<?php echo $rows['description']; ?>' placeholder='Enter Description' maxlength=100>
						</div>
					</div>
					
					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	// date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			if($('#idt').val() == ''){$('#infodt').html(' ** Please write dt'); return false;};
			if($('#iproduct_id').val() == null){$('#infoproduct_id').html(' ** Please select product'); return false;};
			if($('#iqty').val() == ''){$('#infoqty').html(' ** Please write qty'); return false;};
			if($.isNumeric($('#iqty').val())==false){$('#infoqty').html(' ** Please write qty in numeric'); return false;};
			if($('#iunit_value').val() == ''){$('#infounit_value').html(' ** Please write unit_value'); return false;};
			if($.isNumeric($('#iunit_value').val())==false){$('#infounit_value').html(' ** Please write unit value in numeric'); return false;};
			if($('#isales_value').val() == ''){$('#infosales_value').html(' ** Please write sales_value'); return false;};
			if($.isNumeric($('#isales_value').val())==false){$('#infosales_value').html(' ** Please write sales value in numeric'); return false;};
			if($('#ilocation_id').val() == null){$('#infolocation_id').html(' ** Please select location'); return false;};
 	 	})
 	 	$('[data-toggle="tooltip"]').tooltip();
		
//--------------------------------------------------------------------------------------------
		$("#icash_source_id").click(function(){
			var cash_source_id = $('#icash_source_id').val();

			$.post("add_post.php",
			{
				cash_source_id: cash_source_id,
				chart_id:1
				
			}, 
			function(result){
					$("#iaccount_chart_id").html(result);
			});

		})		
		
		
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
