<?php
session_start();
// add.php
date_default_timezone_set("Asia/Dhaka");
$title ="Product In Information";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
require_once ('../classes/cash_source_drop_down.php');

$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	
	$idt = $_POST['idt'];
	$iproduct_id = $_POST['iproduct_id'];
	$iqty = $_POST['iqty'];
	$iunit_value = $_POST['iunit_value'];
	$isales_value = $_POST['isales_value'];
	$idescription = $_POST['idescription'];
	$iaccount_chart_id = $_POST['iaccount_chart_id'];
	$icash_source_id = $_POST['icash_source_id'];
	$iemployee_id = $_POST['iemployee_id'];
	$ilocation_id = $_POST['ilocation_id'];
	$icompany_id = $company_id ;
	
	$table = "`product_in`";
	$fields = "`dt`,   `product_id`,   `qty`,   `unit_value`,   `sales_value`,   `description`,   `account_chart_id`,   `cash_source_id`,   `employee_id`,   `location_id`,   `company_id`";
	$vars = "'$idt',   $iproduct_id,   $iqty,   $iunit_value,   $isales_value, '$idescription',   $iaccount_chart_id,  $icash_source_id,    $iemployee_id,   $ilocation_id,   $icompany_id";	

		$a = $mysqldb->add($table, $fields, $vars);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Saved Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Saving Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}
function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Product In Information</h3>
 	</div>
 	<div class="col-sm-12 text-right">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="add.php" method="post">
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idt'>Date:<small><span id='infodt' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idt' name='idt' value='<?php echo date("Y-m-d");?>' placeholder='Enter Date' maxlength=10>
						</div>
					</div>
					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iproduct_id'>Product:<small><span id='infoproduct_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iproduct_id' name='iproduct_id'>
							<?php
								$mysqldb->drop_down("product", "id", "product_code",1, "`company_id` = $company_id", "`product_code` ASC", $limit=false);							
							?>
							</select>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iqty'>Quantity:<small><span id='infoqty' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iqty' name='iqty' value='' placeholder='Enter Quantity' maxlength=8>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iunit_value'>Unit Value:<small><span id='infounit_value' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iunit_value' name='iunit_value' value='' placeholder='Enter Unit Value' maxlength=10>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='isales_value'>Sales Value:<small><span id='infosales_value' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='isales_value' name='isales_value' value='' placeholder='Enter Sales Value' maxlength=10>
						</div>
					</div>
					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icash_source_id'>Account Type:<small><span id='infocash_source_id' class='text-warning'></span></small></label>
							<select class='form-control' id='icash_source_id' name='icash_source_id'>
							<?php 
								$mysqldb->drop_down("cash_source","id", "name",1,$where=false, "`name` ASC", $limit=false);
							?>
							</select>
						</div>
					</div>
					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iaccount_chart_id'>Supplier:<small><span id='infoaccount_chart_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iaccount_chart_id' name='iaccount_chart_id'>
							<?php 
								$from_source->drop_down_table($company_id,1,1);
							?>
							</select>							
						</div>
					</div>					

					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iemployee_id'>Employee:<small><span id='infoemployee_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iemployee_id' name='iemployee_id'>
							<?php
								$mysqldb->drop_down("employee", "id", "name",1,"`company_id` = $company_id", "`name` ASC", $limit=false);
							?>
							</select>								
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='ilocation_id'>Location:<small><span id='infolocation_id' class='text-warning'></span></small></label>
							<select class='form-control' id='ilocation_id' name='ilocation_id'>
							<?php
								$mysqldb->drop_down("location", "id", "name",1,"`company_id` = $company_id", "`name` ASC", $limit=false);
							?>
							</select>	
						</div>
					</div>
					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idescription'>Description:<small><span id='infodescription' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idescription' name='idescription' value='' placeholder='Enter Description' maxlength=100>
						</div>
					</div>					
					
					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
		date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			if($('#idt').val() == ''){$('#infodt').html(' ** Please write dt'); return false;};
			if($('#iproduct_id').val() == null){$('#infoproduct_id').html(' ** Please select product'); return false;};
			if($('#iqty').val() == ''){$('#infoqty').html(' ** Please write qty'); return false;};
			if($.isNumeric($('#iqty').val())==false){$('#infoqty').html(' ** Please write qty in numeric'); return false;};
			if($('#iunit_value').val() == ''){$('#infounit_value').html(' ** Please write unit_value'); return false;};
			if($.isNumeric($('#iunit_value').val())==false){$('#infounit_value').html(' ** Please write unit value in numeric'); return false;};
			if($('#isales_value').val() == ''){$('#infosales_value').html(' ** Please write sales value'); return false;};
			if($.isNumeric($('#isales_value').val())==false){$('#infosales_value').html(' ** Please write sales_value in numeric'); return false;};
			if($('#iemployee_id').val() == null){$('#infoemployee_id').html(' ** Please select employee'); return false;};
			if($('#ilocation_id').val() == null){$('#infolocation_id').html(' ** Please select location'); return false;};
		})
 	 	
 	 $('[data-toggle="tooltip"]').tooltip();	
 
//--------------------------------------------------------------------------------------------
		$("#icash_source_id").click(function(){
			var cash_source_id = $('#icash_source_id').val();

			$.post("add_post.php",
			{
				cash_source_id: cash_source_id,
				chart_id:1
				
			}, 
			function(result){
					$("#iaccount_chart_id").html(result);
			});

		})
 
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
