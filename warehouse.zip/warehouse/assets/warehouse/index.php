<!DOCTYPE html>
<html>
<head>
	<title>Log In</title>
	<link rel="shortcut icon" href="lib/img/logo.png">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<!-- index.php -->		
<!-- bootstrap -->	
	<link rel="stylesheet" href="../plugins/bootstrap/dist/css/bootstrap.min.css">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
	<script src="../plugins/bootstrap/dist/js/jquery.min.js"></script>
	<script src="../plugins/bootstrap/dist/js/bootstrap.min.js"></script>
<script>
if (window.location.protocol !== 'https:') {
   // window.location = "https://aslamzaman.com/wgi/";
}
</script>
<style>


</style>	
</head>
<body>
<div class="container">
	<div class="row" style="margin-top:10px;">
		<div class="col-sm-offset-3 col-sm-6">
            <div class="panel panel-default">
			   <div class="panel-heading"><h2>Sign In <small>- to warehouse</small></h2></div>
				<div class="panel-body">
				    <form class="form-horizontal" role="form" action="sign_in/pages/index.php" method="post" id="logform">
					    <div class="form-group">
						    <div class="col-sm-12">
							    <label for="user">Email / User Name: <small><span id='infouser' class='text-warning'></span></small></label>
							    <input type="text" class="form-control" id="user" name="user" value="" placeholder="Enter password">
						    </div>
					    </div>						
					    <div class="form-group">
						    <div class="col-sm-12">
							    <label for="pw">Password: <small><span id='infopw' class='text-warning'></span></small></label>
							    <input type="password" class="form-control" id="pw" name="pw" value="" placeholder="Enter password">
						    </div>
					    </div>
					    <div class="btn-group">
						    <input type="submit" class="btn btn-default" name="submit" id="submit" value="Submit">
					    </div>
				    </form>
                </div>
            </div>
    	    <div class="col-sm-12">
    			<div class="row">
    				<div class="col-xs-8">
    					<a href='lib/app/WHMS.apk'><span class='glyphicon glyphicon-download'></span> Download mobile app</a>
    				</div>
    				<div class="col-xs-4 text-right">				
    					<a href='sign_up/pages/'><span class='glyphicon glyphicon-download'></span> Sign up</a>
    				</div>				
    			</div>
    		</div>        
		</div>
			
<script>
$(document).ready(function(){
	
	$("#submit").click(function(){
	    
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})	    
	    
	//----------------------------------------	
		if($("#user").val() == ""){$("#infouser").html("Please write  user id"); return false;};
		if($("#pw").val() == ""){$("#infopw").html("Please write password"); return false;};
	//-----------------------------------	
	});
	
	$("form input" ).each(function(){
		var x = this.value;
		$(this).change(function(){$("#info" ).html(" ");})
	});
	

}); 

</script>

		<div class="col-sm-12"><br></div>
	</div>
</div>
	<br>
	<nav class="navbar navbar-default navbar-fixed-bottom">
		<p class="text-right"><small>Design By: Aslam Zaman-2018, Email: aslamcmes@gmail.com</small></p>
	</nav>
</body>
</html>
