<?php
session_start();
// date_picker.php
date_default_timezone_set("Asia/Dhaka");
$title = "Date Information";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');

$dt_before = $dateClass->dateadd(date("Y-m-d"),-180);
function customPageHeader(){
    
?>
<style>
 	#margin_top{
 	 	margin-top:50px;
 	}
</style>
<?php }?>
<div class="row" id="margin_top">
 	<div class="col-sm-offset-3 col-sm-6">
 	 	<div class="well">
 	 	 	<div class="row">
 	 	 	 	<div class="col-sm-12 text-center">
                    <h3 class="text-primary">Cash Balance Sheet</h3>
 	 	 	 	</div>
 	 	 	</div>
 	 	 	<div class="row">
 	 	 	 	<div class="col-sm-12">
 	 	 	 	 	<form class="form-horizontal" role="form" action="reports.php" method="post">
 	 	 	 	 	 	<div class="form-group">
 	 	 	 	 	 	 	<div class="col-sm-12">
 	 	 	 	 	 	 	 	<label for="dt1">Start Date:<small><span id="infodt1" class="text-warning"></span></small></label>
 	 	 	 	 	 	 	 	<input type="text" class="form-control" id="dt1" name="dt1" value='<?php echo $dt_before; ?>' placeholder="Enter Start Date" maxlength=10>
 	 	 	 	 	 	 	</div>
 	 	 	 	 	 	</div>
 	 	 	 	 	 	<div class="form-group">
 	 	 	 	 	 	 	<div class="col-sm-12">
 	 	 	 	 	 	 	 	<label for="dt2">End Date:<small><span id="infodt2" class="text-warning"></span></small></label>
 	 	 	 	 	 	 	 	<input type="text" class="form-control" id="dt2" name="dt2" value='<?php echo date('Y-m-d'); ?>' placeholder="Enter Start Date" maxlength=10>
 	 	 	 	 	 	 	</div>
 	 	 	 	 	 	</div>
 	 	 	 	 	 	<input type="submit" class="btn btn-default" name="submit" id="submit" value="Next">
 	 	 	 	 	</form>
 	 	 	 	</div>
 	 	 	</div>
 	 	</div>
 	</div>
</div>
<script>
 	$(document).ready(function(){
 	 	date_picker('dt1');
 	 	date_picker('dt2');
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>
  
  
