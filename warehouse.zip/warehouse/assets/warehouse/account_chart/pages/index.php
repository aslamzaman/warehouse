<?php
session_start();
// index.php
date_default_timezone_set("Asia/Dhaka");
$title ="Chart Of Account";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_GET['id']))
{
	$table = "`account_chart`";
	$where = "`id` = ".$_GET['id'];
	
		$a = $mysqldb->remove($table, $where);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Deleted Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Deleting Error!";
 	 	}
}

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Chart Of Account</h3>
 	</div>
 	<div class="col-sm-6" id="display">
		<?php
 	 	 	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
 	 	 	 	echo $_SESSION['msg'];
 	 	 	 	unset($_SESSION['msg']);
 	 	 	}
 	 	?>
 	</div>	
 	<div class="col-sm-6 text-right">
 	    <div class="btn-group btn-group-sm" id="hide">
		    <a href="add.php" class="btn btn-default" id="add" data-toggle='tooltip' data-placement='top' title='Add New'><span class='glyphicon glyphicon-plus'></span></a>
 	    </div>
 	</div>
 	<div class="col-sm-12">
 	 	<table class="table table-striped">
 	 	 	<thead>
 	 	 	 	<tr>
					<th>Name</th>
					<th>Account Type</th>
				</tr>
 	 	 	</thead>
 	 	 	<tbody>
 	 	 	<?php
				$table = "`account_chart`";
				$where = "`company_id`= $company_id";
				$orderBy = "`id` DESC";
				$limit = false;
				$row = $mysqldb->select_all_row($table, $where, $orderBy, $limit);
				if(count($row) > 0)
 	 	 	 	{
 	 	 	 	 	foreach($row as $rows)
 	 	 	 	 	{	
						echo "<tr>";
						echo "<td>".$rows['name']."</td>";
						
						$table = "account_type";
						$whereId = "`id` = ".$rows['account_type_id'];
						$orderBy = "`name` ASC";
						$account_type = $mysqldb->select_one_row($table, $whereId, $orderBy);						
						echo "<td>".$account_type['name']."</td>";
						
						echo "<td>";
						echo "<div class='btn-group btn-group-xs' id='hide'>";
						echo "<a href='edit.php?id=".$rows['id']."' class='btn btn-default' data-toggle='tooltip' data-placement='top' title='Edit'><span class='glyphicon glyphicon-edit'></span></a>";
						// echo "<a href='#' class='btn btn-default delete' id='".$rows['id']."' onclick='deletefunction(this.id)' data-toggle='tooltip' data-placement='top' title='Delete'><span class='glyphicon glyphicon-remove'></span></a>";
						echo "</div>";
						echo "</td>";
						echo "</tr>";
	
		 	 	 	}
 	 	 	 	}
 	 	 	?>
 	 	 	</tbody>
 	 	</table>
 	</div>
</div>	
<script>
 	function deletefunction(id){
 	 	if (confirm("Are u sure?") == true){
 	 	 	window.location.href="index.php?id=" + id;
 	 	}
 	}
 	
 	$('[data-toggle="tooltip"]').tooltip();
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
