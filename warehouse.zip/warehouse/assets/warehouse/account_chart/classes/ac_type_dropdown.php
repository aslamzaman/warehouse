<?php
class ac_type_dropdown_class
{

	public function drop_down($company_id, $selectedId)
	{
		global $db;

		$sql = "SELECT *FROM `account_type` WHERE `id` NOT IN(6,7,8) ORDER BY `name` ";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		if($Numrows > 0)
 	 	{
			echo "\n";
			while($rows= mysqli_fetch_array($result))
			{
				if($rows['id']== $selectedId)
 	 	 	 	{
 	 	 	 	 	echo "<option value='".$rows['id']."' selected>".$rows['name']."</option>\n";
 	 	 	 	}
 	 	 	 	else
 	 	 	 	{
 	 	 	 	 	echo "<option value='".$rows['id']."'>".$rows['name']."</option>\n";
 	 	 	 	}
			}
		}
		
			echo "<option value='' disabled>-------------------------------------</option>\n";
		


		$sql = "SELECT *FROM `account_type` WHERE `id` IN(6,7,8) ORDER BY `name` ";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		if($Numrows > 0)
 	 	{
			echo "\n";
			while($rows= mysqli_fetch_array($result))
			{
				if($rows['id']== $selectedId)
 	 	 	 	{
 	 	 	 	 	echo "<option value='".$rows['id']."' selected>".$rows['name']."</option>\n";
 	 	 	 	}
 	 	 	 	else
 	 	 	 	{
 	 	 	 	 	echo "<option value='".$rows['id']."'>".$rows['name']."</option>\n";
 	 	 	 	}
			}
		}
	
	}


	
}
$ac_type_dropdown = new ac_type_dropdown_class();
?>