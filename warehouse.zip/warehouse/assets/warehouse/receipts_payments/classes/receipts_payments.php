<?php
class receipts_payments_class
{
	
	
	public $total_in=0;
	public $total_out=0;
	public function receive_create($company_id,$d1,$d2)
	{	
		global $mysqldb;
		$sql = "SELECT `dt`,`name`, `c_in` FROM `temp_table` WHERE `dt` BETWEEN '$d1' AND '$d2' ORDER BY `dt` ASC";
		$p = $mysqldb->select_all_raw($sql);		
		if(count($p) > 0) 
		{
			$x=0;
			foreach ($p as $q)
			{
				if($q['c_in'] > 0)
				{
					echo "<tr>\n";
					echo "<td>".$q['dt']."</td>\n";
					echo "<td>".$q['name']."</td>\n";
					echo "<td class='text-right'>".number_format($q['c_in'],2)."</td>\n";				
					echo "</tr>\n";
				}
				$x = $x + $q['c_in'];				
			}
			echo "<tr>\n";
			echo "<td colspan=2><strong><i>Sub Total</i></strong></td>\n";
			echo "<td class='text-right'><strong><i>".number_format($x,2)."</i></strong></td>\n";				
			echo "</tr>\n";			
			$this->total_in = $x;
		}
		
	}	
	public function payment_create($company_id,$d1,$d2)
	{	
		global $mysqldb;
		$sql = "SELECT `dt`,`name`, `c_out` FROM `temp_table` WHERE `dt` BETWEEN '$d1' AND '$d2' ORDER BY `dt` ASC";
		$p = $mysqldb->select_all_raw($sql);		
		if(count($p) > 0) 
		{
			$x=0;
			foreach ($p as $q)
			{
				if($q['c_out'] > 0)
				{
					echo "<tr>\n";
					echo "<td>".$q['dt']."</td>\n";
					echo "<td>".$q['name']."</td>\n";
					echo "<td class='text-right'>".number_format($q['c_out'],2)."</td>\n";				
					echo "</tr>\n";
				}
				$x = $x + $q['c_out'];				
			}
			echo "<tr>\n";
			echo "<td colspan=2><strong><i>Sub Total</i></strong></td>\n";
			echo "<td class='text-right'><strong><i>".number_format($x,2)."</i></strong></td>\n";				
			echo "</tr>\n";			
			$this->total_out = $x;
		}
		
	}

//=============================================================
	public function tbl_create($company_id,$d1,$d2)
	{
		global $db;
		global $mysqldb;
		global $name_by_id_from_source;
		$sql_create = "CREATE TEMPORARY TABLE `temp_table`(
		`dt` date NOT NULL,
		`name` varchar(100) NOT NULL,		
		`c_in` double(15,2) NOT NULL,
		`c_out` double(15,2) NOT NULL
		) ENGINE=MyISAM DEFAULT CHARSET=latin1";
		mysqli_query($db, $sql_create);
		
		
		$table = "`cheque_in`";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '1970-01-01' AND '$d2'";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);

		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				$nm = $name_by_id_from_source->get($company_id,$q['cash_source_id'],$q['account_chart_id'])." (Ch.No.".$q['cheque_no'].", ".$q['cheque_dt'].")";
				$table = "`temp_table`";
				$fields =          "`dt`,`name`,           `c_in`, `c_out`";
				$vars = "'". $q['dt']."', '$nm',". $q['amount'].",     0";
				$mysqldb->add($table, $fields, $vars);
			}
		}
		
		
		$table = "`cheque_out`";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '1970-01-01' AND '$d2'";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
				
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				$nm = $name_by_id_from_source->get($company_id,$q['cash_source_id'],$q['account_chart_id'])." (Ch.No.".$q['cheque_no'].", ".$q['cheque_dt'].")";

				$table = "`temp_table`";
				$fields =          "`dt`, `name`,`c_in`, `c_out`";
				$vars = "'". $q['dt']."', '$nm',     0,". $q['amount'];
				$mysqldb->add($table, $fields, $vars);
			}
		}	
//------------------------------------------------		

		$table = "`cash_in`";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '1970-01-01' AND '$d2'";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);

		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				$nm =$name_by_id_from_source->get($company_id,$q['cash_source_id'],$q['account_chart_id'])." (Cash)";
				$table = "`temp_table`";
				$fields =          "`dt`,  `name`,           `c_in`, `c_out`";
				$vars = "'". $q['dt']."', '$nm',". $q['amount'].",     0";
				$mysqldb->add($table, $fields, $vars);
			}
		}
		
		$table = "`cash_out`";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '1970-01-01' AND '$d2'";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				$nm = "To: ".$name_by_id_from_source->get($company_id,$q['cash_source_id'],$q['account_chart_id'])." (Cash)";
				$table = "`temp_table`";
				$fields =          "`dt`,  `name`,`c_in`, `c_out`";
				$vars = "'". $q['dt']."', '$nm',     0, ". $q['amount'];
				$mysqldb->add($table, $fields, $vars);
			}
		}		
			
	
	}	


//============================================================
	public function previous_expance($company_id,$d1)
	{
		global $mysqldb;
		
		$d2 = date("Y-m-d",(strtotime($d1) - 86400));

		$table = "`temp_table`";
		$field = "c_in";
		$where = "`dt` BETWEEN '1970-01-01' AND '$d2'";	
		$ca_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		
		$table = "`temp_table`";
		$field = "c_out";
		$where = "`dt` BETWEEN '1970-01-01' AND '$d2'";	
		$ca_out = $mysqldb->total_amount($table, $field, $where, $limit=false);		
		
		$x = $ca_in - $ca_out;
		return $x; 
	}	
	
}
$receipts_payments = new receipts_payments_class();
?>	
	
	