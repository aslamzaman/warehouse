<?php

/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('Asia/Dhaka');

/** PHPExcel_IOFactory */
require_once dirname(__FILE__) . '/../../../plugins/phpexcel/Classes/PHPExcel/IOFactory.php';


// echo date('H:i:s') , " Load from Excel5 template" , EOL;

$objReader = PHPExcel_IOFactory::createReader('Excel5');
/* ------------    Border   ---------------- */
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);




/*  ================ Customize section ================  */
/* ------------------------------------------------------------------ */
$objPHPExcel = $objReader->load("../excel/x.xls"); /** Load Excel File */
//=========Statement Updae End======================= 
	
	
	/** Company Name and Address */
	$company = $company_name->show_phpexcel($company_id);
	$objPHPExcel->getActiveSheet()->setCellValue('A1',$company[0]);
	$objPHPExcel->getActiveSheet()->setCellValue('A2',$company[1]);
	$objPHPExcel->getActiveSheet()->setCellValue('A3',$company[2]);
	
	
	/** Period */
	$objPHPExcel->getActiveSheet()->setCellValue('A5',"Period: ".$d1." to ". $d2);	
	
	
	/** Date Today */
	$objPHPExcel->getActiveSheet()->setCellValue('C5',date("Y-m-d"));
	
	/** Previou Balance */
	$objPHPExcel->getActiveSheet()->setCellValue('C7',$b);
	
	
	/** Temporary Table Data Receipt */	
		$sql = "SELECT `dt`,`name`, `c_in` FROM `temp_table` WHERE `dt` BETWEEN '$d1' AND '$d2' AND `c_in` NOT IN(0) ORDER BY `dt` ASC";
		$p = $mysqldb->select_all_raw($sql);		
			$i = 10;
			$r =array();		
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{
				$r =array("A$i","B$i","C$i");

				$objPHPExcel->getActiveSheet()->setCellValue($r[0],$q['dt']);
				$objPHPExcel->getActiveSheet()->setCellValue($r[1],$q['name']);				
				$objPHPExcel->getActiveSheet()->setCellValue($r[2],number_format($q['c_in'],2,'.',''));
				$x = "";
				$n =0;	
				while($n < 3)
				{								
					$x = "$r[$n]:$r[$n]";
					$objPHPExcel->getActiveSheet()->getStyle($x)->applyFromArray($styleThinBlackBorderOutline);
					$n++;
				}				
				$i++;
				
			}
		}
		
		
		
		
		/** Sub total receipt */
		$r =array("A$i","B$i","C$i");
		$m_in = $receipts_payments->total_in;
		
		$objPHPExcel->getActiveSheet()->setCellValue($r[0],"Sub Total");
		$objPHPExcel->getActiveSheet()->getStyle($r[0])->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle($r[0])->getFont()->setItalic(true);
	
		$objPHPExcel->getActiveSheet()->setCellValue($r[2],$m_in);		
		$objPHPExcel->getActiveSheet()->getStyle($r[2])->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle($r[2])->getFont()->setItalic(true);
		
		$x = "";
		$n =0;	
		while($n < 3)
		{								
			$x = "$r[$n]:$r[$n]";
			$objPHPExcel->getActiveSheet()->getStyle($x)->applyFromArray($styleThinBlackBorderOutline);
			$n++;
		}

		/** Add New Ling */
		$i++;$i++;

		
		/** Payment Header */
		$r =array("A$i","B$i","C$i");
		
		$objPHPExcel->getActiveSheet()->setCellValue($r[0],"3. Payment");
		$objPHPExcel->getActiveSheet()->getStyle($r[0])->getFont()->setBold(true);
		$j = "$r[0]:$r[2]";
		$objPHPExcel->getActiveSheet()->mergeCells($j);
		
		$x = "";
		$n =0;	
		while($n < 3)
		{								
			$x = "$r[$n]:$r[$n]";
			$objPHPExcel->getActiveSheet()->getStyle($x)->applyFromArray($styleThinBlackBorderOutline);
			$n++;
		}



				
		
		$i++;
	/** Temporary Table Data Payment */	
		$sql = "SELECT `dt`,`name`, `c_out` FROM `temp_table` WHERE `dt` BETWEEN '$d1' AND '$d2' AND `c_out` NOT IN(0) ORDER BY `dt` ASC";
		$p = $mysqldb->select_all_raw($sql);		
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{
				$r =array("A$i","B$i","C$i");

				$objPHPExcel->getActiveSheet()->setCellValue($r[0],$q['dt']);
				$objPHPExcel->getActiveSheet()->setCellValue($r[1],$q['name']);				
				$objPHPExcel->getActiveSheet()->setCellValue($r[2],number_format($q['c_out'],2,'.',''));
				$x = "";
				$n =0;	
				while($n < 3)
				{								
					$x = "$r[$n]:$r[$n]";
					$objPHPExcel->getActiveSheet()->getStyle($x)->applyFromArray($styleThinBlackBorderOutline);
					$n++;
				}				
				$i++;
			}
		}





		/** Sub total payment */
		$r =array("A$i","B$i","C$i");
		$m_out = $receipts_payments->total_out;
		
		$objPHPExcel->getActiveSheet()->setCellValue($r[0],"Sub Total");
		$objPHPExcel->getActiveSheet()->getStyle($r[0])->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle($r[0])->getFont()->setItalic(true);
	
		$objPHPExcel->getActiveSheet()->setCellValue($r[2],$m_out);		
		$objPHPExcel->getActiveSheet()->getStyle($r[2])->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle($r[2])->getFont()->setItalic(true);
		
		$x = "";
		$n =0;	
		while($n < 3)
		{								
			$x = "$r[$n]:$r[$n]";
			$objPHPExcel->getActiveSheet()->getStyle($x)->applyFromArray($styleThinBlackBorderOutline);
			$n++;
		}
	


		/** Add New Ling */	
		$i++;$i++;
		
		
		
		/** Balance total */
		$r =array("A$i","B$i","C$i");
		
		$m_balance = $b + $m_in - $m_out;
		
		$objPHPExcel->getActiveSheet()->setCellValue($r[0],"Balance Total (1+2-3)");
		$objPHPExcel->getActiveSheet()->getStyle($r[0])->getFont()->setBold(true);
	
		$objPHPExcel->getActiveSheet()->setCellValue($r[2],$m_balance);		
		$objPHPExcel->getActiveSheet()->getStyle($r[2])->getFont()->setBold(true);
		
		$x = "";
		$n =0;	
		while($n < 3)
		{								
			$x = "$r[$n]:$r[$n]";
			$objPHPExcel->getActiveSheet()->getStyle($x)->applyFromArray($styleThinBlackBorderOutline);
			$n++;
		}

	
echo "<a href='receipt_payment_info.xlsx' class='btn btn-primary btn-xs'>Download <i class='fa fa-file-excel-o '></i> </a>";


$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save(str_replace('.php', '.xlsx', __FILE__));

?>