<?php
session_start();
// edit.php
date_default_timezone_set("Asia/Dhaka");
$title ="Cash Out Information";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
require_once ('../classes/cash_source_drop_down.php');

$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	$id = $_POST['id'];
	$idt = $_POST['idt'];
	$iaccount_chart_id = $_POST['iaccount_chart_id'];
	$icash_source_id = $_POST['icash_source_id'];
	$icause = $_POST['icause'];
	$iamount = $_POST['iamount'];
	
	$table = "`cash_out`";
	$field_vars = "`dt` = '$idt', `account_chart_id` = $iaccount_chart_id, `cash_source_id` = $icash_source_id, `cause` = '$icause', `amount` = $iamount";
	$where = "`id` = $id";

		$a = $mysqldb->edit($table, $field_vars, $where);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Update Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Updating Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}

$id = $_GET['id'];
$rows = $mysqldb->select_one_row("`cash_out`","`id` = $id", $orderBy=false);



	
$cas_in = $mysqldb->total_amount("`cash_in`", "amount","`company_id`= $company_id", $limit=false);	
$cas_out = $mysqldb->total_amount("`cash_out`", "amount", "`company_id`= $company_id", $limit=false);		
$cas_one = $mysqldb->total_amount("`cash_out`", "amount", "`company_id`= $company_id AND`id` = $id", $limit=false);		
$balance_taka = $cas_in - ($cas_out - $cas_one);

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Cash Out Information</h3>
 	</div>
 	<div class="col-sm-12 text-right">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="edit.php" method="post">
			<INPUT type="hidden" class="form-control" id="id" name="id" value="<?php echo $id;?>">						
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idt'>Date:<small><span id='infodt' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idt' name='idt' value='<?php echo $rows['dt']; ?>' placeholder='Enter Date' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icash_source_id'>Account Type:<small><span id='infocash_source_id' class='text-warning'></span></small></label>
							<select  class='form-control' id='icash_source_id' name='icash_source_id'>
							<?php 
								$mysqldb->drop_down("cash_source", "id", "name",$rows['cash_source_id'], $where=false, "`name` ASC", $limit=false);
							?>
							</select>								
						</div>
					</div>					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iaccount_chart_id'>Chart Of Account:<small><span id='infoaccount_chart_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iaccount_chart_id' name='iaccount_chart_id'>
							<?php 
								$from_source->drop_down_table($company_id,$rows['cash_source_id'],$rows['account_chart_id']);
							?>
							</select>								
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iamount'>Amount:<small><span id='infoamount' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iamount' name='iamount' value='<?php echo $rows['amount']; ?>' placeholder='Enter Amount' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icause'>Cause:<small><span id='infocause' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='icause' name='icause' value='<?php echo $rows['cause']; ?>' placeholder='Enter Cause' maxlength=100>
						</div>
					</div>					

					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	 date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			if($('#idt').val() == ''){$('#infodt').html(' ** Please write dt'); return false;};
			if($('#iaccount_chart_id').val() == null){$('#infoaccount_chart_id').html(' ** Please setup account chart'); return false;};
			
			if($('#iamount').val() == ''){$('#infoamount').html(' ** Please write amount'); return false;};
			if($.isNumeric($('#iamount').val())==false){$('#infoamount').html(' ** Please write amount in numeric'); return false;};
			if($('#icause').val() == ''){$('#infocause').html(' ** Please write cause'); return false;};
			
			var a = <?php echo $balance_taka;?>;
			var b = $('#iamount').val();
			var msg = " ** Balance not available !(" + a +")";
			if(a < b)
			{
				$('#infoamount').html(msg);
				return false;
			} 	 
	
	})
 	 	
 	 $('[data-toggle="tooltip"]').tooltip();	

//--------------------------------------------------------------------------------------------
		$("#icash_source_id").click(function(){
			var cash_source_id = $('#icash_source_id').val();

			$.post("add_post.php",
			{
				cash_source_id: cash_source_id,
				chart_id:1
				
			}, 
			function(result){
					$("#iaccount_chart_id").html(result);
			});

		})


	 
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
