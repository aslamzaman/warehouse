<?php
class customer_history_class
{

	public function balcne_create($company_id,$d1,$d2,$id)
	{
		global $mysqldb;
		$this->tbl_create($company_id,$id);
		
		$table = "`temp_table`";
		$where ="`dt` BETWEEN '$d1' AND '$d2'";		
		$orderBy ="`dt` ASC";
		$p = $mysqldb->select_all_row($table, $where, $orderBy, $limit=false);
		if(count($p) > 0) 
		{
			$b = $this->previous_balance($company_id,$d1);
			echo "<tr>\n";
			echo "<td>$d1</td>\n";	
			echo "<td colspan=3>Bring Forword</td>\n";			
			echo "<td class='text-right'>$b</td>\n";
			echo "</tr>\n";			
			foreach ($p as $q)
			{
				$b = $b + $q['c_in'] - $q['c_out'];
				echo "<tr>\n";
				echo "<td>".$q['dt']."</td>\n";	
				echo "<td>".$q['name']."</td>\n";	
				if($q['c_in'] > 0)
				{
					echo "<td class='text-right'>".$q['c_in']."</td>\n";
				}
				else
				{
					echo "<td class='text-right'>-</td>\n";
				}
				
				if($q['c_out'] > 0)
				{
					echo "<td class='text-right'>".$q['c_out']."</td>\n";
				}
				else
				{
					echo "<td class='text-right'>-</td>\n";
				}				
				
				echo "<td class='text-right'>$b</td>\n";
				echo "</tr>\n";				
			}
		}
		
	}





	public function tbl_create($company_id, $id)
	{
		global $db;
		global $mysqldb;
		global $name_by_id_from_source;
		$sql_create = "CREATE TEMPORARY TABLE `temp_table`(
		`dt` date NOT NULL,
		`name` varchar(150) NOT NULL,
		`c_in` double(15,2) NOT NULL,
		`c_out` double(15,2) NOT NULL
		) ENGINE=MyISAM DEFAULT CHARSET=latin1";
		mysqli_query($db, $sql_create);
		
		/** ----------------------------------------------------- */		
		$table = "`cash_in`";
		$where ="`account_chart_id` = $id AND `cash_source_id` = 1 AND `company_id`= $company_id";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				
				$nm = "From Cash";
				$table = "`temp_table`";
				$fields = "`dt`, `name`, `c_in`,   `c_out`";
				$vars = "'". $q['dt']."', '$nm',". $q['amount'].", 0";
				$mysqldb->add($table, $fields, $vars);				
				
				
			}
		}
		
		/** ----------------------------------------------------- */
		$table = "`cash_out`";
		$where ="`account_chart_id` = $id AND `cash_source_id` = 1 AND `company_id`= $company_id";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				$nm = "To Cash";
				$table = "`temp_table`";
				$fields = "`dt`, `name`, `c_in`,   `c_out`";
				$vars = "'". $q['dt']."', '$nm', 0,". $q['amount'];
				$mysqldb->add($table, $fields, $vars);
				
			}
		}	



		/** ----------------------------------------------------- */		
		$table = "`cheque_in`";
		$where ="`account_chart_id` = $id AND `cash_source_id` = 1 AND `company_id`= $company_id";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	

				$nm = "Cheque No: " .$q['cheque_no'].", Date: ".$q['cheque_dt'];
				$table = "`temp_table`";
				$fields = "`dt`, `name`, `c_in`,   `c_out`";
				$vars = "'". $q['dt']."', '$nm',". $q['amount'].", 0";
				$mysqldb->add($table, $fields, $vars);	
			}
		}
		
		/** ----------------------------------------------------- */
		$table = "`cheque_out`";
		$where ="`account_chart_id` = $id AND `cash_source_id` = 1 AND `company_id`= $company_id";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	

				
				$nm = "Cheque No: " .$q['cheque_no'].", Date: ".$q['cheque_dt'];
				$table = "`temp_table`";
				$fields = "`dt`, `name`, `c_in`,   `c_out`";
				$vars = "'". $q['dt']."', '$nm', 0,". $q['amount'];
				$mysqldb->add($table, $fields, $vars);				
			}
		}




		
		/** ----------------------------------------------------- */
		$table = "`product_in`";
		$where ="`account_chart_id` = $id AND `cash_source_id` = 1 AND `company_id`= $company_id";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	

				$table = "product";
				$where = "`id` = ".$q['product_id']." AND `company_id` = $company_id";
				$a = $mysqldb->select_one_row($table, $where, $orderBy=false);	
				
				
				$table = "unit";
				$where = "`id` = ".$a['unit_id'];
				$u = $mysqldb->select_one_row($table, $where, $orderBy=false);	
			
				
				$nm1 = "From Product: ".$a['name']." (".$q['qty']." ".$u['name'].")";
				$tk = $q['qty']* $q['unit_value'];
				
				$table = "`temp_table`";
				$fields ="`dt`, `name`, `c_in`, `c_out`";
				$vars = "'". $q['dt']."', '$nm1', $tk, 0";
				$mysqldb->add($table, $fields, $vars);
				
			}
		}

		/** ----------------------------------------------------- */
		$table = "`product_out`";
		$where ="`account_chart_id` = $id AND `cash_source_id` = 1 AND `company_id`= $company_id";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	

				$table = "product";
				$where = "`id` = ".$q['product_id']." AND `company_id` = $company_id";
				$a = $mysqldb->select_one_row($table, $where, $orderBy=false);	
				
				$table = "unit";
				$where = "`id` = ".$a['unit_id'];
				$u = $mysqldb->select_one_row($table, $where, $orderBy=false);	
			
				
				
				$nm1 = "To Product: ".$a['name']." (".$q['qty']." ".$u['name'].")";
				$tk = $q['qty']* $q['sales_value'];
				
				$table = "`temp_table`";
				$fields ="`dt`, `name`, `c_in`, `c_out`";
				$vars = "'". $q['dt']."', '$nm1', 0,$tk";
				$mysqldb->add($table, $fields, $vars);				
			}
		}

		
	}
//============================================================
	public function previous_balance($company_id,$d1)
	{
		global $mysqldb;
		
		$pdt = date("Y-m-d",(strtotime($d1) - 86400));
		
		$table = "`temp_table`";
		$field = "c_in";
		$where ="`dt` BETWEEN '1970-01-01' AND '$pdt'";
		$cashIn = $mysqldb->total_amount($table, $field, $where, $limit=false);		
		
		$table = "`temp_table`";
		$field = "c_out";
		$where ="`dt` BETWEEN '1970-01-01' AND '$pdt'";
		$cashOut = $mysqldb->total_amount($table, $field, $where, $limit=false);		
		
		$x = $cashIn- $cashOut;
		
		return $x; 

		
	}
	
}
$customer_history = new customer_history_class();
?>	
	
	