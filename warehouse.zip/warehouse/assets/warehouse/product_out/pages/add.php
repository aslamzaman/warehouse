<?php
session_start();
// add.php
date_default_timezone_set("Asia/Dhaka");
$title ="Product Out";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
require_once ('../classes/cash_source_drop_down.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];


if(isset($_POST['submit']))
{
	$id = $_POST['id'];
	$idt = $_POST['idt'];
	$iqty = $_POST['iqty'];
	$isales_value = $_POST['isales_value'];	
	$iaccount_chart_id = $_POST['iaccount_chart_id'];
	$icash_source_id = $_POST['icash_source_id'];
	
	$vt = $mysqldb->select_one_row("vat_tax", "`company_id`= $company_id",$orderBy=false);	
	$vat = $vt['vat'];
	$tax = $vt['tax'];

		$to_table = "product_out";		
		$from_table = "product_in";
		$to_fields =     "`dt`, `product_id`, `qty`, `sales_value`, `vat`, `tax`, `description`, `account_chart_id`,   `cash_source_id`, `employee_id`, `company_id`,`product_in_id`, `location_id`";
		$from_fields = "'$idt', `product_id`, $iqty, $isales_value,  $vat,  $tax, `description`, $iaccount_chart_id,   $icash_source_id, `employee_id`, `company_id`,            $id, `location_id`";
		$from_where = "`id`= $id";
		$a = $mysqldb->add_from_another($to_table, $from_table, $to_fields, $from_fields,  $from_where);		
		
		
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Saved Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Saving Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}
function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };


$id = $_GET['id'];
$rows = $mysqldb->select_one_row("product_in", "`id` = $id",$orderBy=false);
//------------------------------------

$product = $mysqldb->select_one_row("product", "`id` = ".$rows['product_id']." AND `company_id`= $company_id", $orderBy=false);
	
// ---------------------------------------

$in = $mysqldb->select_one_row("product_in", "`id` = $id AND `company_id`= $company_id", $orderBy=false);
$out = $mysqldb->total_amount("product_out", "qty", "`product_in_id` = $id AND `company_id`= $company_id", $limit=false);	
$balance = $in['qty'] - $out;


$vt = $mysqldb->select_one_row("vat_tax", "`company_id`= $company_id",$orderBy=false);	
$vat = $vt['vat'];
$tax = $vt['tax'];

?>

<div class="row">
	<div class="col-xs-9">
		<h3 class="text-primary">Product Out</h3>
		<p>Product Name: <?php echo  $product['name'];?><br>Code: <?php echo  $product['product_code'];?><br>Stock: <?php echo "$balance (Vat: ".$vt['vat']."%, Tax: ".$vt['tax'];?>%)</p>
 	</div>
 	<div class="col-xs-3 text-right">
 	 	<br>
		<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
</div>	
<div class="row">	
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="add.php" method="post">
			<input type='hidden' class='form-control' id='id' name='id' value='<?php echo $id;?>'>
			<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idt'>Date:<small><span id='infodt' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idt' name='idt' value='<?php echo date("Y-m-d"); ?>' placeholder='Enter Date' maxlength=100>
						</div>
					</div>

					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iqty'>Quantity:<small><span id='infoqty' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iqty' name='iqty' value='<?php echo $balance; ?>' placeholder='Enter Quantity' maxlength=100>
						</div>
					</div>					
					
					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='isales_value'>Sales Value:<small><span id='infosales_value' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='isales_value' name='isales_value' value='<?php echo $rows['sales_value'];?>' placeholder='Enter Sales Value' maxlength=100>
						</div>
					</div>	
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='itotal'>Total (With Vat & Tax):<small><span id='infotax' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='itotal' name='itotal' value='' placeholder='Total' maxlength=100 readonly>
						</div>
					</div>	
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icash_source_id'>Account Type:<small><span id='infocash_source_id' class='text-warning'></span></small></label>
							<select class='form-control' id='icash_source_id' name='icash_source_id'>
							<?php 
								$mysqldb->drop_down("cash_source","id", "name",1,$where=false, "`name` ASC", $limit=false);
							?>
							</select>
						</div>
					</div>
					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iaccount_chart_id'>Customer:<small><span id='infoaccount_chart_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iaccount_chart_id' name='iaccount_chart_id'>
							<?php 
								$from_source->drop_down_table($company_id,1,1);
							?>
							</select>							
						</div>
					</div>	
					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
	<div class='col-sm-6'>
	</div>
</div>	
<script>
 	$(document).ready(function(){
		
// -----------------------------------------------------------
		
 	date_picker('idt');

// -----------------------------------------------------------
	
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
						
			if($('#idt').val() == ''){$('#infodt').html(' ** Please write dt'); return false;};
			if($('#iqty').val() == ''){$('#infoqty').html(' ** Please write qty'); return false;};
			if($.isNumeric($('#iqty').val())==false){$('#infoqty').html(' ** Please write qty in numeric'); return false;};
			if($('#isales_value').val() == ''){$('#infosales_value').html(' ** Please write sales_value'); return false;};
			if($.isNumeric($('#isales_value').val())==false){$('#infosales_value').html(' ** Please write sales_value in numeric'); return false;};
			
			var vatTax = "<?php echo $vat;?>";
			if (vatTax == ""){$('#infotax').html(' ** Please setup vat and tax from settings menu'); return false;};
			
			var a = "<?php echo $balance;?>";
			var b = $('#iqty').val();
			var c = eval(a) - eval(b);
			var ms = " ** Balance Not available";
			if(c < 0){$('#infoqty').html(ms); return false;};		

		})
		
		
// ----------------------------------------------------------- 	 
	
 	 $('[data-toggle="tooltip"]').tooltip();
	 
// -----------------------------------------------------------
	 
		$("#isales_value").change(function(){
			cal_qty();
		})
		
// -----------------------------------------------------------	
		$("#iqty").change(function(){
			cal_qty();
		})		
// -----------------------------------------------------------		
 	cal_qty();

		function cal_qty()
		{
			var i_qty = $("#iqty").val();
			var i_sale = $("#isales_value").val();
			
			var v = eval(i_qty) * eval(i_sale) * (eval(<?php echo $vat;?>)/100);
			var t = eval(i_qty) * eval(i_sale) * (eval(<?php echo $tax;?>)/100);
			var to =(eval(i_qty) *  eval(i_sale)) + eval(v) + eval(t);

			$("#itotal").val(to);
		}	
	
	
//--------------------------------------------------------------------------------------------
		$("#icash_source_id").click(function(){
			var cash_source_id = $('#icash_source_id').val();

			$.post("add_post.php",
			{
				cash_source_id: cash_source_id,
				chart_id:1
				
			}, 
			function(result){
					$("#iaccount_chart_id").html(result);
			});

		})


///===================================================== 	
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
