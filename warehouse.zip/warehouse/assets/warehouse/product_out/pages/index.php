<?php
session_start();
// index.php
date_default_timezone_set("Asia/Dhaka");
$title ="Product Stock For Out";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">

	<div class="col-sm-12">
		<h3 class="text-primary">Product Stock For Out</h3>
 	</div>
 	
 	<div class="col-sm-6" id="display">
		<?php
 	 	 	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
 	 	 	 	echo $_SESSION['msg'];
 	 	 	 	unset($_SESSION['msg']);
 	 	 	}
 	 	?>
 	</div>	
 	<div class="col-sm-12 text-right">
 	    <div class="btn-group btn-group-sm" id="hide">
		    <a href="outed_list.php" class="btn btn-default" id="add" data-toggle='tooltip' data-placement='top' title='Out List'><span class='glyphicon glyphicon-list-alt'></span> Show Outed List</a>
		</div>
 	</div>   
 	<div class="col-sm-12">
		<div class="table-responsive"> 
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Date</th>
						<th>Product</th>
						<th>Code</th>
						<th class='text-right'>Stock</th>
						<th class='text-right'>Rate</th>
						<th class='text-right'>Vat</th>
						<th class='text-right'>Tax</th>
						<th class='text-right'>Sale Rate</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
				<?php
					$row = $mysqldb->select_all_row("`product_in`", "`company_id`= $company_id","`id` DESC", $limit=false);
					if(count($row) > 0)
					{
						foreach($row as $rows)
						{	
							$id = $rows['id'];
							$in = $mysqldb->select_one_row("product_in", "`id` = $id AND `company_id`= $company_id", $orderBy=false);
							$out = $mysqldb->total_amount("product_out", "qty", "`product_in_id` = $id AND `company_id`= $company_id", $limit=false);	
							$x = $in['qty'] - $out;
							if($x > 0)
							{
								echo "<tr>";
								echo "<td>".$rows['dt']."</td>";
								/** ------------------------------------------------------------------ */
								$product = $mysqldb->select_one_row("product","`id` = ".$rows['product_id']." AND `company_id`= $company_id", $orderBy=false);							
								echo "<td>".$product['name']."</td>";
								echo "<td>".$product['product_code']."</td>";
								
								echo "<td class='text-right'>$x</td>";
								/** ------------------------------------------------------------------ */						
								echo "<td class='text-right'>".number_format($rows['sales_value'],2)."</td>";
								$vt = $mysqldb->select_one_row("vat_tax", "`company_id`= $company_id", $orderBy=false);							
								echo "<td class='text-right'>".number_format($vt['vat'],2)."%</td>";
								echo "<td class='text-right'>".number_format($vt['tax'],2)."%</td>";
								/** ------------------------------------------------------------------ */								
								
								$s_rate = $rows['sales_value'] + ($rows['sales_value']*($vt['vat']/100)) + ($rows['sales_value']*($vt['tax']/100));
								echo "<td class='text-right'>".number_format($s_rate,2)."</td>";
								
								echo "<td class='text-right'>";
								echo "<div class='btn-group btn-group-xs' id='hide'>";
								echo "<a href='add.php?id=".$rows['id']."' class='btn btn-default' data-toggle='tooltip' data-placement='top' title='Sale'><span class='glyphicon glyphicon-export'></span></a>";
								echo "</div>";
								echo "</td>";
								echo "</tr>";
							}
						}
					}
				?>
				</tbody>
			</table>
		</div> <!---- table-responsive ---->	
 	</div>
</div>	
<script>
 	$('[data-toggle="tooltip"]').tooltip();
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
