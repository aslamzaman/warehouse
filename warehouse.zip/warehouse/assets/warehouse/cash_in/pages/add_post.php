<?php
session_start();
require_once ('../../layout/load/load.php');
require_once ('../classes/cash_source_drop_down.php');
$company_id = $_SESSION["company_id"];
$cash_source_id = $_POST['cash_source_id'];
$chart_id= $_POST['chart_id'];
$from_source->drop_down_table($company_id, $cash_source_id, $chart_id);;
?>






	
