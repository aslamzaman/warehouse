<?php
date_default_timezone_set("Asia/Dhaka");

class date_class
{
	
	public $date_diff_manual_yrs;
	public $date_diff_manual_months;
	public $date_diff_manual_days; 
	
	
	
	/**
	* $dateClass->date_dot("2017-09-20");
	* return 20.09.2017
	*/		
	public function date_dot($d)
	{
		$d1=strtotime($d);
		$dt2=date("d.m.Y",$d1);
		return $dt2;
	}
	
	
	
	/**
	* $dateClass->datediff("2017-09-20","2017-10-15", 1);
	* return 26
	*/	
		
	public function datediff($d_1,$d_2,$day)
	{
		$d1=strtotime($d_1);
		$dt2=strtotime($d_2);
		$diff=round(($dt2-$d1)/86400)+$day;	
		return $diff;
	}
	
	
	
	/**
	* $dateClass->dateadd("2017-09-20", 5);
	* return 2017-09-25
	*/	
	
	public function dateadd($dt,$days)
	{
		$x = "$days days";
		$date=date_create($dt);
		date_add($date,date_interval_create_from_date_string($x));
		return date_format($date,"Y-m-d");
	}

	
	
	/**
	* $dateClass->date_diff_manual("2011-02-01","2017-09-20");
	* echo $dateClass->date_diff_manual_yrs; return  6;
	* echo $dateClass->date_diff_manual_months; return 7;
	* echo $dateClass->date_diff_manual_days; return 19;
	*/		
	
	public function date_diff_manual($dt1,$dt2)
	{
		$x1 = explode("-",$dt1);
		$x2 = explode("-",$dt2);

		$ext_m = 0;
		$ext_y = 0;
		$d = "";$m = "";$y = "";
		if($x1[2] > $x2[2])
		{
			$ext_m = 1;
			$d = $x2[2]+ 30 - $x1[2];
		}
		else
		{
			$ext_m = 0;
			$d = $x2[2] - $x1[2];		
		}
		

		$mx =  $x1[1] + $ext_m;
		if($mx > $x2[1])
		{
			$ext_y = 1;
			$m = $x2[1] + 12 - $mx;
		}
		else
		{
			$ext_y = 0;
			$m = $x2[1]  - $mx;
		}
		
		$yx =  $x1[0] + $ext_y;
		$y = $x2[0] - $yx;
	
		$this->date_diff_manual_yrs = $y;
		$this->date_diff_manual_months = $m;
		$this->date_diff_manual_days = $d; 		
	}
	
	
	
	/**
	* $dateClass->day_of_month(02, 2017);
	* return 28
	*/		



	
			
	public function day_of_month($m, $y)
	{
		$d ="";
		if($m ==1 || $m ==3 || $m==5 || $m==7 || $m==8 || $m==10 || $m==12 )
		{
			$d = 31;	
		}
		else if($m ==2)
		{
			if( (0 == $y % 4) and (0 != $y % 100) or (0 == $y % 400) )
			{
				$d = 29;  
			}
			else
			{
				$d = 28;;  
			}
		}
		else
		{
			$d = 30;	
		}
		
		return $d ;
	}
	
	
	
	/**
	* $dateClass->my_age_year("2016-01-01","2017-12-31",1);
	* return 2.00 yrs
	*/
	
	
	
	
	public function my_age_year($dt1,$dt2,$addDays)
	{
		$d1=strtotime($dt1);
		$d2=strtotime($dt2);	
		$d3=($d2-$d1);
		$days=($d3/86400) + $addDays;
		$full_string=number_format(($days/365),2)."yrs";
		return $full_string;
	}	
	
}	

$dateClass = new date_class();
?>