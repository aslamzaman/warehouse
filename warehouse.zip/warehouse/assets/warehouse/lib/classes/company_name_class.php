<?php
class company_name_class
{
	
	public function show_phpexcel($company_id)
	{
		global $mysqldb;
		$com = array();
		$table = "`company`";
		$whereId = "`company_id` = $company_id";
		$com_name = $mysqldb->select_one_row($table, $whereId, $orderBy=false);
		if($com_name['print_show'] > 0)
		{
			
			$com = array($com_name['name'],$com_name['address'],"Mobile: ".$com_name['mobile']);
		}
		else
		{
			$com = array('','','');
		}
		return $com;

	}
	
	public function show_html($company_id)
	{
		global $mysqldb;
		$com = "";
		$table = "`company`";
		$whereId = "`company_id` = $company_id";
		$com_name = $mysqldb->select_one_row($table, $whereId, $orderBy=false);
		if($com_name['print_show'] > 0)
		{
			
			$com = "<h3 class='text-center'>".$com_name['name']."<br><span class='small'>".$com_name['address']."</span></h3><p class='text-center'>Mobile: ".$com_name['mobile']."</p>";
		}
		else
		{
			$com = "";
		}
		return $com;
	}	
	
	
}
$company_name = new company_name_class();
?>	
	
	