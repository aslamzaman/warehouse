<?php
class name_by_id_from_source_class
{
	
	public function get($company_id,$sourceid,$chart_id)
	{
		global $db;
		$table = "";
		if($sourceid == 1)
		{
			$table = "customer";
		}
		else if($sourceid == 2)
		{
			$table = "supplier";
		}
		else
		{
			$table = "account_chart";	
		}

	
		$sql = "SELECT `name` FROM $table WHERE `id` = $chart_id AND `company_id` = $company_id LIMIT 1";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		if($Numrows > 0)
 	 	{
			$rows= mysqli_fetch_array($result);
			$nm = $rows['name'];
			return $nm;
		}

	}
	
	
	
	
}
$name_by_id_from_source = new name_by_id_from_source_class();
?>	
	
	