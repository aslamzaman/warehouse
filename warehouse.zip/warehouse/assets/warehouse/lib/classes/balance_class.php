<?php
class balance_class
{
	
	/** -------------------------------------------------------------------- */	
	/*	$balance->cash($company_id,$d1,$d2);                                 */
	/*	$balance->cheque_value($company_id,$d1,$d2);                         */	
	/*	$balance->cheque_by_bank_id($company_id,$d1,$d2,$id);                */	
	/*	$balance->procuct_by_id($company_id,$d1,$d2,$id);                    */	
	/*	$balance->procuct_by_id_location($company_id,$d1,$d2,$id,$location); */	
	/*	$balance->product_value($company_id,$d1,$d2);                        */		
	/** -------------------------------------------------------------------- */	
	
	
	
	/** ---------------------------------------------------- */	
	/** ---  Balance cash                                 -- */	
	/** ---------------------------------------------------- */
	public function cash($company_id,$d1,$d2)
	{
		global $mysqldb;
		$table = "`cash_in`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";		
		$cas_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */
		$table = "`cash_out`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";	
		$cas_out = $mysqldb->total_amount($table, $field, $where, $limit=false);
		$x = $cas_in - $cas_out;
		return $x;
	}	
	
	
	/** ---------------------------------------------------- */	
	/** ---  Balance cheque value in all bank id          -- */	
	/** ---------------------------------------------------- */
	public function cheque_value($company_id,$d1,$d2)
	{
		global $mysqldb;
		$table = "`cheque_in`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";		
		$chequein = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */
		$table = "`cheque_out`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";	
		$chequeout = $mysqldb->total_amount($table, $field, $where, $limit=false);		
		
		$x = $chequein - $chequeout;
		return $x;
	}	


	
	/** ---------------------------------------------------- */	
	/** ---  Balance cheque by bank id                    -- */	
	/** ---------------------------------------------------- */
	public function cheque_by_bank_id($company_id,$d1,$d2,$id)
	{
		global $mysqldb;
		$table = "`cheque_in`";
		$field = "amount";
		$where = "`bank_account_id`= $id AND `company_id`= $company_id  AND `dt` BETWEEN '$d1' AND '$d2'";		
		$chequein = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */
		$table = "`cheque_out`";
		$field = "amount";
		$where = "`bank_account_id`= $id AND `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";	
		$chequeout = $mysqldb->total_amount($table, $field, $where, $limit=false);		
		
		$x = $chequein - $chequeout;
		return $x;
	}

	
	/** ---------------------------------------------------- */	
	/** ---  Balance product by product id in all location-- */	
	/** ---------------------------------------------------- */	
	public function procuct_by_id($company_id,$d1,$d2,$id)
	{
		global $mysqldb;
		$table = "`product_in`";
		$field = "qty";
		$where = "`product_id` = $id AND `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";		
		$q_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */
		$table = "`product_out`";
		$field = "qty";
		$where = "`product_id` = $id AND `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";	
		$q_out = $mysqldb->total_amount($table, $field, $where, $limit=false);
		
		$x = $q_in - $q_out;
		return $x;	
	
	}
	
	

	/** ---------------------------------------------------- */	
	/** -----  Balance product by product id in a Location-- */	
	/** ---------------------------------------------------- */	
	public function procuct_by_id_location($company_id,$d1,$d2,$id,$location)
	{
		global $mysqldb;
		$table = "`product_in`";
		$field = "qty";
		$where = "`product_id` = $id AND `location_id` = $location AND `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";		
		$q_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */
		$table = "`product_out`";
		$field = "qty";
		$where = "`product_id` = $id AND `location_id` = $location  AND `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";	
		$q_out = $mysqldb->total_amount($table, $field, $where, $limit=false);
		
		$x = $q_in - $q_out;
		return $x;	
	
	}

	
	/** ---------------------------------------------------- */	
	/** -------   Balance Product Value (In - Out) -------- */	
	/** ---------------------------------------------------- */	
	public function product_value($company_id,$d1,$d2)
	{
		$x = $this->taka_product_in($company_id,$d1,$d2);
		$y = $this->taka_product_out($company_id,$d1,$d2);
		$z = $x - $y;
		return $z;
	}	
	

	
	public function taka_product_out($company_id,$d1,$d2)
	{
		global $db;
		$sql = "SELECT `qty` * `sales_value` as total FROM product_out  WHERE `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x = 0;
		if($Numrows > 0)
 	 	{
			$t = 0;
			while($rows= mysqli_fetch_array($result))
			{
				$t = $t + $rows['total'];
			}
			$x = $t;
		}
		else
		{
			$x = 0;	
		}
		return $x;
	}	
	

	Private function taka_product_in($company_id,$d1,$d2)
	{
		global $db;
		$sql = "SELECT `qty` * `unit_value` as total FROM product_in WHERE `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x = 0;
		if($Numrows > 0)
 	 	{
			$t = 0;
			while($rows= mysqli_fetch_array($result))
			{
				$t = $t + $rows['total'];
			}
			$x = $t;
		}
		else
		{
			$x = 0;	
		}
		return $x;
	}	
	
}
$balance = new balance_class();
?>	
	
	