<?php
// mysqldb.php
class mysql_class
{

	/**
	* $table = "xyz";
	* $fields = "`id`,`name`,`fname`";
	* $vars = "$id, '$name', '$fname'";
	* $mysqldb->add($table, $fields, $vars);
	*/	
	public function add($table, $fields, $vars)
	{
 	 	global $db;
 	 	$sql = "INSERT INTO $table($fields) VALUES($vars)";
 	 	$ret=mysqli_query($db,$sql); 
 	 	return $ret;
	}
	
	
	
	
	

	/**
	* $to_table = "ABC";	
	* $from_table = "XYZ";
	* $to_fields = "`id`,`name`,`fname`";
	* $from_fields = "`id`,`name`,`fname`";
	* $from_where = "`id`= $id";
	* $mysqldb->add_from_another($to_table, $from_table, $to_fields, $from_fields, $from_where=false);
	*/	
	public function add_from_another($to_table, $from_table, $to_fields, $from_fields, $from_where)
	{
 	 	global $db;
		
		$whr = false;
		if($from_where)
		{
			$whr = "WHERE $from_where";
		}		
		
 	 	$sql = "INSERT INTO $to_table($to_fields) SELECT $from_fields FROM $from_table $whr";
 	 	$ret=mysqli_query($db,$sql);
 	 	return $ret;
	}
	
			
	
	
	
	/**
	* $table = "xyz";
	* $field_vars = "`name` = '$name', `fname` = '$fname'";
	* $where = "`id` = 12";
	* $mysqldb->edit($table, $field_vars, $where);
	*/
	public function edit($table, $field_vars, $where)
	{
 	 	global $db;
 	 	$sql = "UPDATE $table SET $field_vars WHERE $where";
 	 	$ret=mysqli_query($db,$sql);
 	 	return $ret;
	}
	
	
	
	
	
	
	/**
	* $table = "xyz";
	* $where = "`id` = 12";
	* $mysqldb->remove($table, $where);
	*/
 	public function remove($table, $where)
 	{
 	 	global $db;
 	 	$sql = "DELETE FROM $table WHERE $where";
 	 	$ret=mysqli_query($db,$sql);
 	 	return $ret;
 	}
	
	
	
	
	
	/**
	* $table = "xyz";
	* $where = "`name` = 'Mamun'";	
	* $orderBy = "`name` ASC";
	* $limit = 5;
	* $mysqldb->select_all_row($table, $where=false, $orderBy=false, $limit=false);
	*/	
	public function select_all_row($table, $where, $orderBy, $limit)
	{
		global $db;

		$whr = false;
		$ordr = false;
		$lmt = false;
		if($where)
		{
			$whr = "WHERE $where";
		}		
		if($orderBy)
		{
			$ordr = "ORDER BY $orderBy";
		}
		
		if($limit)
		{
			$lmt = "LIMIT $limit";
		}
		
		$sql = "SELECT *FROM $table $whr $ordr $lmt";
	 	$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
 	 	if($Numrows > 0)
 	 	{
 	 	 	$row = array();
 	 	 	while($rows= mysqli_fetch_array($result))
 	 	 	{
 	 	 	 	$row[]=$rows;
 	 	 	}
 	 	 	return $row;
 	 	}	
	}
	

	
	/**
	* $table = "xyz";
	* $fields = "`name`, `district`";
	* $group_field = "`district`";
	* $where = "`name` = 'Mamun'";	
	* $orderBy = "`district` ASC";
	* $limit = 5;
	* $mysqldb->select_group_by_row($table, $fields, $group_field, $where=false, $orderBy=false, $limit=false);
	*/	
	public function select_group_by_row($table, $fields, $group_field, $where, $orderBy, $limit)
	{
		global $db;

		$whr = false;
		$ordr = false;
		$lmt = false;
		if($where)
		{
			$whr = "WHERE $where";
		}		
		if($orderBy)
		{
			$ordr = "ORDER BY $orderBy";
		}
		
		if($limit)
		{
			$lmt = "LIMIT $limit";
		}
		
		$sql = "SELECT $fields FROM $table $whr GROUP BY $group_field $ordr $lmt";
	 	$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
 	 	if($Numrows > 0)
 	 	{
 	 	 	$row = array();
 	 	 	while($rows= mysqli_fetch_array($result))
 	 	 	{
 	 	 	 	$row[]=$rows;
 	 	 	}
 	 	 	return $row;
 	 	}	
	}
	
	
	
	
	
	
	/**
	* $table = "xyz";
	* $where = "`id` = 101";
	* $orderBy = "`name` ASC";
	* $mysqldb->select_one_row($table, $where=false, $orderBy=false);	
	*/	
	public function select_one_row($table, $where, $orderBy)
	{
		global $db;
		$whr = false;
		$ordr = false;
		if($where)
		{
			$whr = "WHERE $where";
		}
        if($orderBy)
		{
			$ordr = "ORDER BY $orderBy";
		}
		
		$sql = "SELECT *FROM $table $whr $ordr LIMIT 1";
	 	$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
 	 	if($Numrows > 0)
 	 	{
 	 	 	$rows= mysqli_fetch_array($result);
 	 	 	return $rows;
 	 	}	
	}
	





 	/**
	* $sql = "...";
	* $mysqldb->select_all_raw($sql);
	*/
	public function select_all_raw($sql)
 	{
 	 	global $db;
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
 	 	if($Numrows > 0)
 	 	{
 	 	 	$row = array();
 	 	 	while($rows= mysqli_fetch_array($result))
 	 	 	{
 	 	 	 	$row[]=$rows;
 	 	 	}
 	 	 	return $row;
 	 	}			
 	}
 	
 	
 	
 	
	

	
	
	
	/**
	* $table = "xyz";
	* $field = "amount";
	* $where = "`id` = 101 AND `name` = 'Mamun'";	
	* $limit = 5;
	* $mysqldb->total_amount($table, $field, $where=false, $limit=false);	
    */
	public function total_amount($table, $field, $where, $limit)
	{
		global $db;
		$whr = false;
		$lmt = false;
		if($where)
		{
			$whr = "WHERE $where";
		}		
		if($limit)
		{
			$lmt = "LIMIT $limit";
		}
		$sql = "SELECT $field FROM $table $whr $lmt";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x = 0;
		if($Numrows > 0)
 	 	{
			$t = 0;
			while($rows= mysqli_fetch_array($result))
			{
				$t = $t + $rows[$field];
			}
			$x = $t;
		}
		else
		{
			$x = 0;	
		}
		return $x;
	}
	
	
	
	
	
	/**
	* $table = "xyz";
	* $field = "amount";
	* $where = "`id` = 101 AND `name` = 'Mamun'";	
	* $limit = 5;
	* $mysqldb->avg_amount($table, $field, $where=false, $limit=false);	
	*/
	public function avg_amount($table, $field, $where, $limit)
	{
		global $db;
		$whr = false;
		$lmt = false;
		if($where)
		{
			$whr = "WHERE $where";
		}		
		if($limit)
		{
			$lmt = "LIMIT $limit";
		}
		$sql = "SELECT $field FROM $table $whr $lmt";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x = 0;
		if($Numrows > 0)
 	 	{
			$t = 0;
			while($rows= mysqli_fetch_array($result))
			{
				$t = $t + $rows[$field];
			}
			$x = $t / $Numrows;
		}
		else
		{
			$x = 0;	
		}
		return $x;
	}	
	
	
	
	
	/** 
	* $table = "xyz";
	* $field1 = "id";
	* $field2 = "name";
	* $selectedId = "101";
	* $where = "`name` = 'Mamun'";	
	* $orderBy = "`name` ASC";
	* $limit = 5;
	* $mysqldb->drop_down($table, $field1, $field2, $selectedId, $where=false, $orderBy=false, $limit=false);
	*/	
	public function drop_down($table, $field1, $field2, $selectedId, $where, $orderBy, $limit)
	{
		global $db;
		$whr = false;
		$ordr = false;
		$lmt = false;
		if($where)
		{
			$whr = "WHERE $where";
		}		
		if($orderBy)
		{
			$ordr = "ORDER BY $orderBy";
		}
		if($limit)
		{
			$lmt = "LIMIT $limit";
		}
		$sql = "SELECT $field1, $field2 FROM $table $whr $ordr $lmt";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		if($Numrows > 0)
 	 	{
			echo "\n";
			while($rows= mysqli_fetch_array($result))
			{
 	 	 	 	if($rows[$field1]== $selectedId)
 	 	 	 	{
 	 	 	 	 	echo "<option value='".$rows[$field1]."' selected>".$rows[$field2]."</option>\n";
 	 	 	 	}
 	 	 	 	else
 	 	 	 	{
 	 	 	 	 	echo "<option value='".$rows[$field1]."'>".$rows[$field2]."</option>\n";
 	 	 	 	}
			}
		}
	}
	
	
	





	/**
	* $table = "xyz";
	* $name = "name";
	* $idField = "id";
	* $idNum = 1;
	* $mysqldb->name_by_id($table,$name,$idField,$idNum);	
	*/
	public function name_by_id($table,$name,$idField,$idNum)
	{
		global $db;
		$sql = "SELECT $name FROM $table WHERE $idField = $idNum LIMIT 1";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		if($Numrows > 0)
 	 	{
			$rows= mysqli_fetch_array($result);
			$nm = $rows[$name];
			return $nm;
		}
	}	
	


	
	
	
	/**
	* $table = "xyz";
	* $field = "id";
	* $startCode = "10001";
	* $where = "`name` = 'Mamun'";
	* $mysqldb->code_increment($table, $field, $startCode, $where=false);	
    */	
	public function code_increment($table, $field, $startCode, $where)
	{
		global $db;
		$whr = false;
		if($where)
		{
			$whr = "WHERE $where";
		}
	
		$sql = "SELECT $field FROM $table $whr ORDER BY $field DESC LIMIT 1";
	 	$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x=0;
 	 	if($Numrows > 0)
 	 	{
 	 	 	$rows= mysqli_fetch_array($result);
 	 	 	$x  = $rows[$field] + 1;
 	 	}
		else
		{
			$x = $startCode;
		}
		return $x;
	}	
	




	/** 
	<input list='list_1' class='form-control' id='icash_source_id' name='icash_source_id' placeholder='Enter Name' maxlength=100>
	* $table = "xyz";
	* $field = "name";
	* $listId = "list_1";
	* $where = "`company_id`= $company_id";
	* $orderBy = "`name`ASC";
	* $mysqldb->input_list($table, $field, $listId, $where=false, $orderBy=false, $limit=false);	
	*/	
	public function input_list($table, $field, $listId, $where, $orderBy, $limit)
	{
		global $db;
		$whr = false;
		$ordr = false;
		$lmt = false;
		if($where)
		{
			$whr = "WHERE $where";
		}		
		if($orderBy)
		{
			$ordr = "ORDER BY $orderBy";
		}
		
		if($limit)
		{
			$lmt = "LIMIT $limit";
		}
		$sql = "SELECT $field FROM $table $whr $ordr $lmt";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		if($Numrows > 0)
 	 	{
			echo "\n";
			echo "<datalist id='".$listId."'>\n";
			while($rows= mysqli_fetch_array($result))
			{
 	 	 	 	echo "<option value='".$rows[$field]."'>\n";
			}
			echo "</datalist>\n";
		}
	}		






    /** 
    * $mysqldb->getUserIpAddr();	
    */	
    public function getUserIpAddr()
    {
 	 	$ip ="";
 	 	if(!empty($_SERVER['HTTP_CLIENT_IP']))
 	 	{
			//ip from share internet
			$ip = $_SERVER['HTTP_CLIENT_IP'];
 	 	}
 	 	elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
 	 	{
			//ip pass from proxy
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
 	 	}
 	 	else
 	 	{
			$ip = $_SERVER['REMOTE_ADDR'];
 	 	}
 	 	return $ip;
    }


	
	
	
}
$mysqldb = new mysql_class();

?>




