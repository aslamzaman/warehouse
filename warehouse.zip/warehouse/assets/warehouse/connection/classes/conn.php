 <?php
        // conn.php
        class conn
        {
         	public $conn;
         	public function __construct()
         	{
         	 	
         		$this->conn=mysqli_connect('localhost', 'aslamza1_aslam', 'aslam@1968', 'aslamza1_warehouse');
         	//	$this->conn=mysqli_connect('localhost', 'root', '', 'warehouse');
         	 	mysqli_set_charset($this->conn,"utf8");
         	 	if (!$this->conn)
         	 	{
         	 	 	die("Connection failed: " . mysqli_connect_error());
         	 	}
         	}
        }
        $con= new conn();
        $db= $con->conn;
        ?>