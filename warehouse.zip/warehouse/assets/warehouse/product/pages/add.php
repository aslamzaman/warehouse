<?php
session_start();
// add.php
date_default_timezone_set("Asia/Dhaka");
$title ="Product Information";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	$iproduct_code = $_POST['iproduct_code'];
	$iname = $_POST['iname'];
	$idescription = $_POST['idescription'];
	$iproduct_type_id = $_POST['iproduct_type_id'];
	$iunit_id = $_POST['iunit_id'];
	$icompany_id = $company_id;

	
	$table = "`product`";
	$fields = "`product_code`,   `name`,   `description`,   `product_type_id`,   `unit_id`,   `company_id`";
	$vars = "'$iproduct_code', '$iname', '$idescription',   $iproduct_type_id,  $iunit_id, $icompany_id";

		$a = $mysqldb->add($table, $fields, $vars);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Saved Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Saving Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}
function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Product Information</h3>
 	</div>
 	<div class="col-sm-12 text-right">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="add.php" method="post">
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iproduct_code'>Product Code:<small><span id='infoproduct_code' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iproduct_code' name='iproduct_code' value='' placeholder='Enter Product_code' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iname'>Name:<small><span id='infoname' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iname' name='iname' value='' placeholder='Enter Name' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iunit_id'>Unit:<small><span id='infounit_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iunit_id' name='iunit_id'>
							<?php
								$table = "unit";
								$field1 = "id";
								$field2 = "name";
								$selectedId = 1;
								$orderBy = "`name` ASC";
								$mysqldb->drop_down($table, $field1, $field2, $selectedId, $where=false, $orderBy, $limit=false);							
							?>							
							</select>						
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iproduct_type_id'>Product Type:<small><span id='infoproduct_type_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iproduct_type_id' name='iproduct_type_id'>
							<?php
								$table = "product_type";
								$field1 = "id";
								$field2 = "name";
								$selectedId = 1;
								$orderBy = "`name` ASC";
								$mysqldb->drop_down($table, $field1, $field2, $selectedId, $where=false, $orderBy, $limit=false);							
							?>							
							</select>						
						</div>
					</div>

					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idescription'>Description:<small><span id='infodescription' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idescription' name='idescription' value='' placeholder='Enter Description' maxlength=100>
						</div>
					</div>
					
					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	// date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			if($('#iproduct_code').val() == ''){$('#infoproduct_code').html(' ** Please write product_code'); return false;};
			if($('#iname').val() == ''){$('#infoname').html(' ** Please write name'); return false;};
 	 	})
 	 	
 	 $('[data-toggle="tooltip"]').tooltip();	
 	 	
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
