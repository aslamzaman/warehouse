<?php
session_start();
// date_picker.php
date_default_timezone_set("Asia/Dhaka");
$title = "Sign In";
require_once ('../../layout/header/header_sign_in_up.php');
require_once ('../../layout/load/load.php');
require_once("../../default_values/classes/default_values.php");
require_once("../../visitors/classes/visitors_class.php");


function customPageHeader(){?>
<style>
 	#margin_top{
 	 	margin-top:50px;
 	}
</style>
<?php 
}
	$user = $_POST["user"];
	$pw =  $_POST["pw"];
	/** ------------------------------------------------------------------ */
	$table = "pw";
	$where = "`user` = '$user' AND `pw` = '$pw'";
	/** ------------------------------------------------------------------ */	
	$p = $mysqldb->select_one_row($table, $where, $orderBy=false);
	if ($p)		
	{
		$bill_dt = $p['bill_dt'];
		$mo_dt =  strtotime($bill_dt) - strtotime(date("Y-m-d"));
		if($mo_dt < 0)
		{
		?>
			<div class="row" style="margin-top:50px;">
				<div class="col-sm-offset-3 col-sm-6">
					<div class="panel panel-default">
						<div class="panel-heading"><h3>Sign In</h3></div>
						<div class="panel-body">
							<p class="text-center"><b>Billing Period Has Finished !</b><br><br>Please contact with provider.<br>Email: aslamcmes@gmail.com</p>
							<a href ="../../index.php" class="btn btn-default">Close</a>
						</div>
					</div>	
				</div>
			</div>		
		<?php 
		}
		else
		{
			
			$_SESSION["pw_id"] = $p['id'];
			$_SESSION["company_id"] = $p['company_id'];
			$_SESSION["short_name"] = $p['short_name'];
			
			$default_values->chart_of_account($p['company_id']);
			$visitors->add_ip($p['company_id']);
			
			echo "<script>window.location.href ='../../dashboard/pages';</script>";
		}
	}
	else
	{
?>
		<div class="row" style="margin-top:50px;">
			<div class="col-sm-offset-3 col-sm-6">
				<div class="panel panel-default">
					<div class="panel-heading"><h3>Sign In</h3></div>
					<div class="panel-body">
						<p class="text-center">Wrong user id or password !<br>Please try again.</p>
						<a href ="../../index.php" class="btn btn-default">Close</a>
					</div>
				</div>	
			</div>
		</div>		

		<?php 
	}
		include "../../layout/footer/footer.php";
		?>
