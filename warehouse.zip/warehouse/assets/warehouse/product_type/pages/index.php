<?php
session_start();
// index.php
date_default_timezone_set("Asia/Dhaka");
$title ="Product Type";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_GET['id']))
{
	$table = "`product_type`";
	$where = "`id` = ".$_GET['id'];
	
		$a = $mysqldb->remove($table, $where);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Deleted Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Deleting Error!";
 	 	}
}

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
		.hide{display: none;}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Product Type</h3>
 	</div>
 	<div class="col-sm-6" id="display">
		<?php
 	 	 	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
 	 	 	 	echo $_SESSION['msg'];
 	 	 	 	unset($_SESSION['msg']);
 	 	 	}
 	 	?>
 	</div>	
 	<div class="col-sm-6 text-right">
 	    <div class="btn-group btn-group-sm" id="hide">
		    <a href="add.php" class="btn btn-default hide" id="add" data-toggle='tooltip' data-placement='top' title='Add New'><span class='glyphicon glyphicon-plus'></span></a>
 	    </div>
 	</div>
 	<div class="col-sm-12">
 	 	<table class="table table-striped">
 	 	 	<thead>
 	 	 	 	<tr>
					<th>Name</th>
				</tr>
 	 	 	</thead>
 	 	 	<tbody>
 	 	 	<?php
				$table = "`product_type`";
				$orderBy = "`name` ASC";
				$row = $mysqldb->select_all_row($table, $where=false, $orderBy, $limit=false);
				if(count($row) > 0)
 	 	 	 	{
 	 	 	 	 	foreach($row as $rows)
 	 	 	 	 	{	
						echo "<tr>";
						echo "<td>".$rows['name']."</td>";
						echo "<td>";
						echo "<div class='btn-group btn-group-xs hide' id='hide'>";
						echo "<a href='edit.php?id=".$rows['id']."' class='btn btn-default' data-toggle='tooltip' data-placement='top' title='Edit'><span class='glyphicon glyphicon-edit'></span></a>";
						echo "<a href='#' class='btn btn-default' id='".$rows['id']."' onclick='deletefunction(this.id)' data-toggle='tooltip' data-placement='top' title='Delete'><span class='glyphicon glyphicon-remove'></span></a>";
						echo "</div>";
						echo "</td>";
						echo "</tr>";
	
		 	 	 	}
 	 	 	 	}
 	 	 	?>
 	 	 	</tbody>
 	 	</table>
 	</div>
</div>	
<script>
 	function deletefunction(id){
 	 	if (confirm("Are u sure?") == true){
 	 	 	window.location.href="index.php?id=" + id;
 	 	}
 	}
 	$('[data-toggle="tooltip"]').tooltip();
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
