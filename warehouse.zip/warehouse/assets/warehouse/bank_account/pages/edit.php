<?php
session_start();
// edit.php
date_default_timezone_set("Asia/Dhaka");
$title ="Bank Account Information";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	$id = $_POST['id'];
	$iname = $_POST['iname'];
	$iaddress = $_POST['iaddress'];
	
	$table = "`bank_account`";
	$field_vars = "`name` = '$iname', `address` = '$iaddress'";
	$where = "`id` = $id";

		$a = $mysqldb->edit($table, $field_vars, $where);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Update Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Updating Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}

$id = $_GET['id'];
$table = "`bank_account`";
$whereId = "`id` = $id";
$rows = $mysqldb->select_one_row($table, $whereId, $orderBy=false);

	

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Bank Account Information</h3>
 	</div>
 	<div class="col-sm-12 text-right">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="edit.php" method="post">
			<INPUT type="hidden" class="form-control" id="id" name="id" value="<?php echo $id;?>">						
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iname'>Name:<small><span id='infoname' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iname' name='iname' value='<?php echo $rows['name']; ?>' placeholder='Enter Name' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iaddress'>Address:<small><span id='infoaddress' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iaddress' name='iaddress' value='<?php echo $rows['address']; ?>' placeholder='Enter Address' maxlength=100>
						</div>
					</div>

					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	// date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			if($('#iname').val() == ''){$('#infoname').html(' ** Please write name'); return false;};
			if($('#iaddress').val() == ''){$('#infoaddress').html(' ** Please write address'); return false;};
 	 	})
 	 	$('[data-toggle="tooltip"]').tooltip();
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
