-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2019 at 08:17 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `warehouse`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_chart`
--

CREATE TABLE `account_chart` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `account_type_id` int(10) NOT NULL,
  `description` varchar(150) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_chart`
--

INSERT INTO `account_chart` (`id`, `name`, `account_type_id`, `description`, `entry_dt`) VALUES
(1, 'Salary', 5, '', '2018-02-04 16:19:38'),
(2, 'Rent', 5, '', '2018-02-04 20:36:30'),
(3, 'Purchage', 5, '', '2018-02-05 20:08:38'),
(4, 'Gift', 5, 'dd', '2018-03-14 14:05:35'),
(5, 'Electic Bill', 5, '', '2018-02-06 00:01:58'),
(6, 'Income TAX', 5, '', '2018-02-06 00:02:34'),
(7, 'Interest Payment', 5, '', '2018-02-06 00:02:48'),
(8, 'Internet Bill', 5, '', '2018-02-06 00:02:58'),
(9, 'License Renewal Charge', 5, '', '2018-02-06 00:03:22'),
(10, 'New License', 5, '', '2018-02-06 00:03:35'),
(11, 'Service Charge', 5, '', '2018-02-06 00:04:06'),
(12, 'Shipment Cost', 5, '', '2018-02-06 00:04:17'),
(13, 'Travel Cost', 5, '', '2018-02-06 00:04:28'),
(14, 'Gas bill', 5, 'ff', '2018-03-14 14:07:44'),
(20, 'Postage', 5, 'Big size', '2018-02-13 14:06:23'),
(15, 'Entertainment', 5, 'd', '2018-03-14 14:09:12'),
(22, 'Bank Loan', 2, 'dfdsf', '2018-02-18 22:12:42'),
(24, 'Bank Interrest', 4, 'dfsd', '2018-02-20 21:42:03'),
(16, 'Mobile Bill', 5, 'dd', '2018-03-14 14:10:21'),
(17, 'Telephone Bill', 5, 'dd', '2018-03-14 14:10:53'),
(18, 'News Paper Bill', 5, 'dd', '2018-03-14 14:12:02'),
(19, 'Repair And Maintenance', 5, 'dd', '2018-03-14 14:13:28'),
(21, 'Bribe', 5, 'f', '2018-03-14 14:19:13'),
(23, 'Insurance Charge', 5, 'dd', '2018-03-14 14:21:12');

-- --------------------------------------------------------

--
-- Table structure for table `account_type`
--

CREATE TABLE `account_type` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_type`
--

INSERT INTO `account_type` (`id`, `name`, `entry_dt`) VALUES
(1, 'Asset Accounts', '2018-02-04 15:52:03'),
(2, 'Liability Accounts', '2018-02-04 15:52:19'),
(3, 'Owners Equity Accounts', '2018-02-04 15:52:29'),
(4, 'Revenue Accounts', '2018-02-04 15:52:42'),
(5, 'Regular Expense Accounts', '2018-02-04 15:52:52');

-- --------------------------------------------------------

--
-- Table structure for table `bank_account`
--

CREATE TABLE `bank_account` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `ac_no` varchar(100) NOT NULL,
  `address` varchar(150) NOT NULL,
  `company_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_account`
--

INSERT INTO `bank_account` (`id`, `name`, `ac_no`, `address`, `company_id`, `entry_dt`) VALUES
(1, 'XYZ Enterprise Limited', '4568656', 'Agrani Bank, Satmasjid Road Brance', 101, '2018-02-04 22:10:06'),
(2, 'Kusiara Enterprise Limited', '5654656', 'dfdsf', 101, '2018-02-08 12:49:35'),
(3, 'Janata Bank Ltd', '8596789', 'Satmasjid Road', 101, '2018-02-13 11:04:54');

-- --------------------------------------------------------

--
-- Table structure for table `bills_final`
--

CREATE TABLE `bills_final` (
  `id` int(10) NOT NULL,
  `bills_raw_id` int(8) NOT NULL,
  `bill_no` int(8) NOT NULL,
  `dt` date NOT NULL,
  `customer_id` int(8) NOT NULL,
  `product_id` int(8) NOT NULL,
  `qty` double(15,2) NOT NULL,
  `rate` double(15,2) NOT NULL,
  `company_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bills_final`
--

INSERT INTO `bills_final` (`id`, `bills_raw_id`, `bill_no`, `dt`, `customer_id`, `product_id`, `qty`, `rate`, `company_id`, `entry_dt`) VALUES
(11, 3, 10002, '2018-02-19', 3, 7, 500.00, 200.00, 101, '2018-02-19 23:25:52'),
(10, 1, 10001, '2018-02-19', 3, 1, 200.00, 500.00, 101, '2018-02-19 23:06:03'),
(9, 2, 10001, '2018-02-19', 3, 9, 5.00, 5000.00, 101, '2018-02-19 23:06:03'),
(14, 5, 10003, '2018-02-19', 2, 3, 10.00, 100.00, 101, '2018-02-28 14:56:08'),
(15, 4, 10003, '2018-02-19', 2, 7, 60.00, 400.00, 101, '2018-02-28 14:56:08'),
(16, 7, 10004, '2018-03-01', 3, 4, 56.00, 455.00, 101, '2018-03-01 18:42:19'),
(17, 6, 10004, '2018-03-01', 5, 7, 34.00, 244.00, 101, '2018-03-01 18:42:19');

-- --------------------------------------------------------

--
-- Table structure for table `bills_raw`
--

CREATE TABLE `bills_raw` (
  `id` int(10) NOT NULL,
  `dt` date NOT NULL,
  `customer_id` int(8) NOT NULL,
  `product_id` int(8) NOT NULL,
  `qty` double(15,2) NOT NULL,
  `rate` double(15,2) NOT NULL,
  `company_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bills_raw`
--

INSERT INTO `bills_raw` (`id`, `dt`, `customer_id`, `product_id`, `qty`, `rate`, `company_id`, `entry_dt`) VALUES
(1, '2018-02-19', 3, 1, 200.00, 500.00, 101, '2018-02-19 22:24:01'),
(2, '2018-02-19', 3, 9, 5.00, 5000.00, 101, '2018-02-19 22:29:53'),
(3, '2018-02-19', 3, 7, 500.00, 200.00, 101, '2018-02-19 22:30:08'),
(4, '2018-02-19', 2, 7, 60.00, 400.00, 101, '2018-02-19 23:33:32'),
(5, '2018-02-19', 2, 3, 10.00, 100.00, 101, '2018-02-19 23:33:49'),
(6, '2018-03-01', 5, 7, 34.00, 244.00, 101, '2018-03-01 18:41:44'),
(7, '2018-03-01', 3, 4, 56.00, 455.00, 101, '2018-03-01 18:42:01');

-- --------------------------------------------------------

--
-- Table structure for table `cash_in`
--

CREATE TABLE `cash_in` (
  `id` int(10) NOT NULL,
  `dt` date NOT NULL,
  `account_chart_id` int(8) NOT NULL,
  `cause` varchar(50) NOT NULL,
  `amount` double(15,2) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cash_in`
--

INSERT INTO `cash_in` (`id`, `dt`, `account_chart_id`, `cause`, `amount`, `entry_dt`) VALUES
(1, '2018-02-01', 3, 'Store rent', 5500.00, '2018-02-04 21:12:43'),
(2, '2018-02-02', 4, 'From Dhaka University g', 3000.00, '2018-02-04 21:37:59'),
(3, '2018-02-02', 2, 'Furniture', 800.00, '2018-02-05 20:09:26'),
(4, '2018-02-05', 15, 'KJSER WER', 860.00, '2018-02-06 14:58:26'),
(5, '2018-02-06', 4, 'jh hgh hg', 500000.00, '2018-02-08 11:29:14'),
(6, '2018-02-11', 4, 'ghtfjyju  ', 5000.00, '2018-02-11 12:11:51'),
(7, '2018-02-11', 23, 'uyuy', 1000.00, '2018-02-11 16:51:40'),
(8, '2018-02-13', 3, 'Battery Bill', 85000.00, '2018-02-13 11:13:38'),
(10, '2018-02-12', 5, 'hgfhg', 45450.00, '2018-02-14 15:50:13'),
(11, '2018-02-13', 3, 'dfdsf', 23423.00, '2018-02-15 16:47:13'),
(12, '2018-02-17', 2, 'jhgujg', 5000.00, '2018-02-17 19:40:26'),
(13, '2018-02-15', 21, 'rty', 50000.00, '2018-02-18 22:00:02'),
(14, '2018-02-18', 22, '4e5r34', 70000.00, '2018-02-18 22:13:21'),
(16, '2018-02-20', 23, 'dfs', 80000.00, '2018-02-20 21:32:40'),
(17, '2018-02-21', 24, 'hgjhgj', 40000.00, '2018-02-21 16:34:36'),
(18, '2018-03-04', 4, 'ewrr', 150000.00, '2018-03-04 07:09:04'),
(19, '2018-03-14', 5, 'juh', 8000.00, '2018-03-14 23:42:06'),
(21, '2019-01-17', 1, 'dwqe', 4000.00, '2019-01-17 00:02:42');

-- --------------------------------------------------------

--
-- Table structure for table `cash_out`
--

CREATE TABLE `cash_out` (
  `id` int(10) NOT NULL,
  `dt` date NOT NULL,
  `account_chart_id` varchar(8) NOT NULL,
  `cause` varchar(50) NOT NULL,
  `amount` double(15,2) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cash_out`
--

INSERT INTO `cash_out` (`id`, `dt`, `account_chart_id`, `cause`, `amount`, `entry_dt`) VALUES
(6, '2018-02-05', '2', 'hg', 4545.00, '2018-02-14 15:51:03'),
(7, '2018-02-06', '1', 'fsdf', 232.00, '2018-02-15 17:18:55'),
(8, '2018-02-06', '13', 'piouyjuy', 7000.00, '2018-02-15 19:34:55'),
(10, '2018-02-08', '1', 'fdgerg', 457857.00, '2018-02-16 12:51:10'),
(11, '2018-02-09', '2', 'fdtgre', 5200.00, '2018-02-16 17:16:56'),
(12, '2018-02-15', '2', 'ferf', 300.00, '2018-02-16 23:15:21'),
(13, '2018-02-18', '3', 'erewr', 1000.00, '2018-02-17 10:35:40'),
(14, '2018-02-20', '20', 'rtr4', 5.00, '2018-02-20 21:00:06'),
(15, '2018-02-21', '1', 'erwrcfsd', 3000.00, '2018-02-21 16:35:21'),
(16, '2019-01-14', '21', 'hgfuj', 500.00, '2019-01-14 22:00:59');

-- --------------------------------------------------------

--
-- Table structure for table `cash_source`
--

CREATE TABLE `cash_source` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cash_source`
--

INSERT INTO `cash_source` (`id`, `name`, `entry_dt`) VALUES
(1, 'Customer', '2018-02-14 06:49:34'),
(2, 'Supplier', '2018-02-14 06:49:44'),
(3, 'Chart Of Account', '2018-02-14 06:49:54');

-- --------------------------------------------------------

--
-- Table structure for table `cheque_in`
--

CREATE TABLE `cheque_in` (
  `id` int(10) NOT NULL,
  `dt` date NOT NULL,
  `bank_account_id` int(10) NOT NULL,
  `account_chart_id` int(10) NOT NULL,
  `cheque_no` varchar(50) NOT NULL,
  `cheque_dt` date NOT NULL,
  `amount` double(15,2) NOT NULL,
  `cause` varchar(150) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cheque_in`
--

INSERT INTO `cheque_in` (`id`, `dt`, `bank_account_id`, `account_chart_id`, `cheque_no`, `cheque_dt`, `amount`, `cause`, `entry_dt`) VALUES
(11, '2018-02-16', 3, 3, '4854', '2018-02-16', 80000.00, 'sdfd', '2018-02-16 23:22:31'),
(13, '2018-02-17', 1, 3, '45656', '2018-02-17', 120000.00, 'ewr', '2018-02-17 11:03:54'),
(14, '2018-02-20', 1, 19, '879', '2018-02-20', 50000.00, 'rt', '2018-02-20 21:04:07'),
(15, '2018-02-20', 1, 24, '23645', '2018-02-20', 4000.00, 'erew', '2018-02-20 21:42:49'),
(16, '2018-02-21', 2, 21, '489678', '2018-02-21', 3000.00, 'erqwer', '2018-02-21 16:36:23'),
(17, '2018-03-02', 2, 1, '878878', '2018-03-01', 6000.00, 'dfs', '2018-03-02 20:11:31'),
(18, '2018-03-14', 3, 5, '565875', '2018-03-14', 5000.00, 'lj', '2018-03-14 23:42:50'),
(19, '2019-01-10', 3, 1, '2256354', '2019-01-16', 45454.00, '45475', '2019-01-15 03:43:53'),
(20, '2019-01-17', 3, 22, '435', '2019-01-16', 435435.00, 'retretr', '2019-01-15 04:52:14'),
(22, '2019-01-17', 3, 1, '33', '2019-01-25', 55555.00, 'terte', '2019-01-15 08:56:11'),
(23, '2019-01-04', 2, 1, '33', '2019-01-10', 3000.00, 'nnnnnnnnnnnnn', '2019-01-15 08:58:14');

-- --------------------------------------------------------

--
-- Table structure for table `cheque_out`
--

CREATE TABLE `cheque_out` (
  `id` int(10) NOT NULL,
  `dt` date NOT NULL,
  `bank_account_id` int(10) NOT NULL,
  `account_chart_id` int(10) NOT NULL,
  `cheque_no` varchar(50) NOT NULL,
  `cheque_dt` date NOT NULL,
  `amount` double(15,2) NOT NULL,
  `cause` varchar(150) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cheque_out`
--

INSERT INTO `cheque_out` (`id`, `dt`, `bank_account_id`, `account_chart_id`, `cheque_no`, `cheque_dt`, `amount`, `cause`, `entry_dt`) VALUES
(24, '2018-02-17', 3, 3, 'dsfsd45678', '2018-02-17', 26000.00, 'dfgdfg', '2018-02-17 12:20:19'),
(25, '2018-02-17', 3, 3, '574', '2018-02-17', 1000.00, 'gsd', '2018-02-17 12:20:45'),
(26, '2018-02-18', 3, 10, '455', '2018-02-18', 300.00, 'hg', '2018-02-18 13:41:53'),
(27, '2018-02-18', 3, 21, '565656', '2018-02-18', 10000.00, 'adw', '2018-02-18 22:00:30'),
(28, '2018-02-21', 2, 2, '8797', '2018-02-21', 2000.00, 'srfew', '2018-02-21 16:37:05'),
(29, '2018-03-02', 1, 1, '62154', '2018-03-02', 3000.00, 'sdf', '2018-03-02 20:11:58'),
(30, '2018-03-14', 3, 1, '65544', '2018-03-14', 3000.00, 'kj', '2018-03-14 23:43:40'),
(32, '2019-01-15', 1, 1, '100000', '2019-01-15', 100000.00, 'ddddddddddddd', '2019-01-15 11:15:04');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) NOT NULL,
  `comments` varchar(50) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `company_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `comments`, `ip_address`, `company_id`, `entry_dt`) VALUES
(1, '	ertfwerewe rewrwer\r\nwer\r\nwerewr						', '::1', 101, '2018-02-21 13:46:10'),
(2, 'sddwqe							', '::1', 101, '2018-02-21 13:47:42'),
(3, '			ertr				', '', 101, '2018-02-21 13:48:24'),
(4, '		ewrtwe4r					', '::1', 101, '2018-02-21 13:53:17'),
(5, '			retwert				', '::1', 101, '2018-02-21 13:55:49'),
(6, '			retwert				', '::1', 101, '2018-02-21 13:57:26'),
(7, '			erewr				', '103.83.165.17', 101, '2018-02-21 14:01:57'),
(8, 'dfsdfdsf  dfdsf dsfhdfdfdf\r\nsdf\r\ndsf\r\ndsff							', '103.83.165.17', 101, '2018-02-21 14:08:24'),
(9, 'ewrqw3			erewqr				', '103.83.165.17', 101, '2018-02-21 14:10:51'),
(10, '				dffe			', '103.83.165.17', 101, '2018-02-21 14:12:25'),
(11, '			http://aslamzaman.com/warehouse/cash_in/pages/	', '103.60.175.121', 101, '2018-02-28 14:58:15');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `company_id` int(8) NOT NULL,
  `print_show` int(2) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `name`, `address`, `mobile`, `company_id`, `print_show`, `entry_dt`) VALUES
(1, 'ABC Services Information Systems', 'House 71, Road -9/A, Dhanmondi R/A, Dhaka -1209', '01457811', 101, 1, '2018-02-04 16:27:50');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`) VALUES
(1, 'Afghanistan'),
(2, 'Albania'),
(3, 'Algeria'),
(4, 'American Samoa'),
(5, 'Andorra'),
(6, 'Angola'),
(7, 'Anguilla'),
(8, 'Antarctica'),
(9, 'Antigua and Barbuda'),
(10, 'Argentina'),
(11, 'Armenia'),
(12, 'Aruba'),
(13, 'Australia'),
(14, 'Austria'),
(15, 'Azerbaijan'),
(16, 'Bahamas'),
(17, 'Bahrain'),
(18, 'Bangladesh'),
(19, 'Barbados'),
(20, 'Belarus'),
(21, 'Belgium'),
(22, 'Belize'),
(23, 'Benin'),
(24, 'Bermuda'),
(25, 'Bhutan'),
(26, 'Bolivia'),
(27, 'Bosnia and Herzegowina'),
(28, 'Botswana'),
(29, 'Bouvet Island'),
(30, 'Brazil'),
(31, 'British Indian Ocean Territory'),
(32, 'Brunei Darussalam'),
(33, 'Bulgaria'),
(34, 'Burkina Faso'),
(35, 'Burundi'),
(36, 'Cambodia'),
(37, 'Cameroon'),
(38, 'Canada'),
(39, 'Cape Verde'),
(40, 'Cayman Islands'),
(41, 'Central African Republic'),
(42, 'Chad'),
(43, 'Chile'),
(44, 'China'),
(45, 'Christmas Island'),
(46, 'Cocos (Keeling) Islands'),
(47, 'Colombia'),
(48, 'Comoros'),
(49, 'Congo Democratic Republic of'),
(50, 'Cook Islands'),
(51, 'Costa Rica'),
(52, 'Cote D\'Ivoire'),
(53, 'Croatia'),
(54, 'Cuba'),
(55, 'Cyprus'),
(56, 'Czech Republic'),
(57, 'Denmark'),
(58, 'Djibouti'),
(59, 'Dominica'),
(60, 'Dominican Republic'),
(61, 'Timor-Leste'),
(62, 'Ecuador'),
(63, 'Egypt'),
(64, 'El Salvador'),
(65, 'Equatorial Guinea'),
(66, 'Eritrea'),
(67, 'Estonia'),
(68, 'Ethiopia'),
(69, 'Falkland Islands (Malvinas)'),
(70, 'Faroe Islands'),
(71, 'Fiji'),
(72, 'Finland'),
(73, 'France'),
(75, 'French Guiana'),
(76, 'French Polynesia'),
(77, 'French Southern Territories'),
(78, 'Gabon'),
(79, 'Gambia'),
(80, 'Georgia'),
(81, 'Germany'),
(82, 'Ghana'),
(83, 'Gibraltar'),
(84, 'Greece'),
(85, 'Greenland'),
(86, 'Grenada'),
(87, 'Guadeloupe'),
(88, 'Guam'),
(89, 'Guatemala'),
(90, 'Guinea'),
(91, 'Guinea-bissau'),
(92, 'Guyana'),
(93, 'Haiti'),
(94, 'Heard Island and McDonald Islands'),
(95, 'Honduras'),
(96, 'Hong Kong'),
(97, 'Hungary'),
(98, 'Iceland'),
(99, 'India'),
(100, 'Indonesia'),
(101, 'Iran (Islamic Republic of)'),
(102, 'Iraq'),
(103, 'Ireland'),
(104, 'Israel'),
(105, 'Italy'),
(106, 'Jamaica'),
(107, 'Japan'),
(108, 'Jordan'),
(109, 'Kazakhstan'),
(110, 'Kenya'),
(111, 'Kiribati'),
(112, 'Korea, Democratic People\'s Republic of'),
(113, 'South Korea'),
(114, 'Kuwait'),
(115, 'Kyrgyzstan'),
(116, 'Lao People\'s Democratic Republic'),
(117, 'Latvia'),
(118, 'Lebanon'),
(119, 'Lesotho'),
(120, 'Liberia'),
(121, 'Libya'),
(122, 'Liechtenstein'),
(123, 'Lithuania'),
(124, 'Luxembourg'),
(125, 'Macao'),
(126, 'Macedonia, The Former Yugoslav Republic of'),
(127, 'Madagascar'),
(128, 'Malawi'),
(129, 'Malaysia'),
(130, 'Maldives'),
(131, 'Mali'),
(132, 'Malta'),
(133, 'Marshall Islands'),
(134, 'Martinique'),
(135, 'Mauritania'),
(136, 'Mauritius'),
(137, 'Mayotte'),
(138, 'Mexico'),
(139, 'Micronesia, Federated States of'),
(140, 'Moldova'),
(141, 'Monaco'),
(142, 'Mongolia'),
(143, 'Montserrat'),
(144, 'Morocco'),
(145, 'Mozambique'),
(146, 'Myanmar'),
(147, 'Namibia'),
(148, 'Nauru'),
(149, 'Nepal'),
(150, 'Netherlands'),
(151, 'Netherlands Antilles'),
(152, 'New Caledonia'),
(153, 'New Zealand'),
(154, 'Nicaragua'),
(155, 'Niger'),
(156, 'Nigeria'),
(157, 'Niue'),
(158, 'Norfolk Island'),
(159, 'Northern Mariana Islands'),
(160, 'Norway'),
(161, 'Oman'),
(162, 'Pakistan'),
(163, 'Palau'),
(164, 'Panama'),
(165, 'Papua New Guinea'),
(166, 'Paraguay'),
(167, 'Peru'),
(168, 'Philippines'),
(169, 'Pitcairn'),
(170, 'Poland'),
(171, 'Portugal'),
(172, 'Puerto Rico'),
(173, 'Qatar'),
(174, 'Reunion'),
(175, 'Romania'),
(176, 'Russian Federation'),
(177, 'Rwanda'),
(178, 'Saint Kitts and Nevis'),
(179, 'Saint Lucia'),
(180, 'Saint Vincent and the Grenadines'),
(181, 'Samoa'),
(182, 'San Marino'),
(183, 'Sao Tome and Principe'),
(184, 'Saudi Arabia'),
(185, 'Senegal'),
(186, 'Seychelles'),
(187, 'Sierra Leone'),
(188, 'Singapore'),
(189, 'Slovakia (Slovak Republic)'),
(190, 'Slovenia'),
(191, 'Solomon Islands'),
(192, 'Somalia'),
(193, 'South Africa'),
(194, 'South Georgia and the South Sandwich Islands'),
(195, 'Spain'),
(196, 'Sri Lanka'),
(197, 'Saint Helena, Ascension and Tristan da Cunha'),
(198, 'St. Pierre and Miquelon'),
(199, 'Sudan'),
(200, 'Suriname'),
(201, 'Svalbard and Jan Mayen Islands'),
(202, 'Swaziland'),
(203, 'Sweden'),
(204, 'Switzerland'),
(205, 'Syrian Arab Republic'),
(206, 'Taiwan'),
(207, 'Tajikistan'),
(208, 'Tanzania, United Republic of'),
(209, 'Thailand'),
(210, 'Togo'),
(211, 'Tokelau'),
(212, 'Tonga'),
(213, 'Trinidad and Tobago'),
(214, 'Tunisia'),
(215, 'Turkey'),
(216, 'Turkmenistan'),
(217, 'Turks and Caicos Islands'),
(218, 'Tuvalu'),
(219, 'Uganda'),
(220, 'Ukraine'),
(221, 'United Arab Emirates'),
(222, 'United Kingdom'),
(223, 'United States'),
(224, 'United States Minor Outlying Islands'),
(225, 'Uruguay'),
(226, 'Uzbekistan'),
(227, 'Vanuatu'),
(228, 'Vatican City State (Holy See)'),
(229, 'Venezuela'),
(230, 'Vietnam'),
(231, 'Virgin Islands (British)'),
(232, 'Virgin Islands (U.S.)'),
(233, 'Wallis and Futuna Islands'),
(234, 'Western Sahara'),
(235, 'Yemen'),
(236, 'Serbia'),
(238, 'Zambia'),
(239, 'Zimbabwe'),
(240, 'Aaland Islands'),
(241, 'Palestine'),
(242, 'Montenegro'),
(243, 'Guernsey'),
(244, 'Isle of Man'),
(245, 'Jersey'),
(247, 'Curaçao'),
(248, 'Ivory Coast'),
(249, 'Kosovo');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `district_id` varchar(50) NOT NULL,
  `country_id` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `company_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `address`, `district_id`, `country_id`, `mobile`, `company_id`, `entry_dt`) VALUES
(1, 'Jamal Uddin', 'Gandaria', '1', '18', '0245788', 0, '2018-02-14 07:47:20'),
(2, 'Shajahan Mia', 'Gandaria, Shalban', '1', '18', '456', 101, '2018-02-14 07:50:04'),
(3, 'Anuraag Rahaman', 'Dhanmondi', '1', '18', '52654511', 101, '2018-02-16 21:32:05'),
(4, 'Ramesh Paramahamsa', 'Mohakhali DOHS', '1', '18', '88755444', 101, '2018-02-21 20:37:11'),
(5, 'Harsha Huq', 'Mirpur Golchattar', '1', '18', '02488888', 101, '2018-02-21 20:37:58');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int(2) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `name`) VALUES
(1, 'Dhaka'),
(2, 'Faridpur'),
(3, 'Gazipur'),
(4, 'Gopalganj'),
(5, 'Jamalpur'),
(6, 'Kishoreganj'),
(7, 'Madaripur'),
(8, 'Manikganj'),
(9, 'Munshiganj'),
(10, 'Mymensingh'),
(11, 'Narayanganj'),
(12, 'Narsingdi'),
(13, 'Netrokona'),
(14, 'Rajbari'),
(15, 'Shariatpur'),
(16, 'Sherpur'),
(17, 'Tangail'),
(18, 'Bogra'),
(19, 'Joypurhat'),
(20, 'Naogaon'),
(21, 'Natore'),
(22, 'Nawabganj'),
(23, 'Pabna'),
(24, 'Rajshahi'),
(25, 'Sirajgonj'),
(26, 'Dinajpur'),
(27, 'Gaibandha'),
(28, 'Kurigram'),
(29, 'Lalmonirhat'),
(30, 'Nilphamari'),
(31, 'Panchagarh'),
(32, 'Rangpur'),
(33, 'Thakurgaon'),
(34, 'Barguna'),
(35, 'Barisal'),
(36, 'Bhola'),
(37, 'Jhalokati'),
(38, 'Patuakhali'),
(39, 'Pirojpur'),
(40, 'Bandarban'),
(41, 'Brahmanbaria'),
(42, 'Chandpur'),
(43, 'Chittagong'),
(44, 'Comilla'),
(45, 'Coxs Bazar'),
(46, 'Feni'),
(47, 'Khagrachari'),
(48, 'Lakshmipur'),
(49, 'Noakhali'),
(50, 'Rangamati'),
(51, 'Habiganj'),
(52, 'Maulvibazar'),
(53, 'Sunamganj'),
(54, 'Sylhet'),
(55, 'Bagerhat'),
(56, 'Chuadanga'),
(57, 'Jessore'),
(58, 'Jhenaidah'),
(59, 'Khulna'),
(60, 'Kushtia'),
(61, 'Magura'),
(62, 'Meherpur'),
(63, 'Narail'),
(64, 'Satkhira');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `district_id` int(3) NOT NULL,
  `country_id` int(3) NOT NULL,
  `mobile` varchar(80) NOT NULL,
  `birth_dt` date NOT NULL,
  `salary` double(15,2) NOT NULL,
  `join_dt` date NOT NULL,
  `company_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `address`, `district_id`, `country_id`, `mobile`, `birth_dt`, `salary`, `join_dt`, `company_id`, `entry_dt`) VALUES
(1, 'Jamal Uddin', 'House 71, Road -9/A, Dhanmondi R/A, Dhaka -1209', 0, 0, '', '1990-01-01', 25000.00, '2000-01-01', 101, '2018-02-06 21:08:42'),
(2, 'Gopaal Bhonda', 'Rangpur Town House', 0, 0, '', '2003-02-07', 4545811.00, '2017-02-08', 101, '2018-02-06 21:39:01');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `mobile` varchar(150) NOT NULL,
  `company_id` int(10) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `name`, `address`, `mobile`, `company_id`, `entry_dt`) VALUES
(1, 'Ashulia', 'Ashulia', '0125877', 101, '2018-02-01 23:31:47'),
(2, 'Merul Badda', 'Uttar Badd', '02547888', 101, '2018-02-03 00:16:57'),
(3, 'UttarKhan', 'Badda', '0125877', 101, '2018-02-03 00:23:22'),
(5, 'Kaytpara', 'Gazipur', '01717050311', 101, '2018-02-13 11:01:55');

-- --------------------------------------------------------

--
-- Table structure for table `money_receipt`
--

CREATE TABLE `money_receipt` (
  `id` int(10) NOT NULL,
  `receipt_no` int(10) NOT NULL,
  `dt` date NOT NULL,
  `cash_from` varchar(50) NOT NULL,
  `description` varchar(150) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `amount` double(15,2) NOT NULL,
  `company_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `money_receipt`
--

INSERT INTO `money_receipt` (`id`, `receipt_no`, `dt`, `cash_from`, `description`, `employee_id`, `amount`, `company_id`, `entry_dt`) VALUES
(1, 10001, '2018-02-01', 'Habibullah Hawladar', 'ty ertreterte4tret  tret yy', 1, 8000.00, 101, '2018-02-07 01:04:16'),
(2, 10002, '2018-02-02', 'Jasim Uddin', 'df sdfjsdf', 2, 7000.00, 101, '2018-02-07 01:33:45');

-- --------------------------------------------------------

--
-- Stand-in structure for view `out_list`
-- (See below for the actual view)
--
CREATE TABLE `out_list` (
`id` int(10)
,`dt` date
,`qty` int(8)
,`rate` double(15,2)
,`vat` double(15,2)
,`tax` double(15,2)
,`total` double(19,2)
,`name` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `out_total`
-- (See below for the actual view)
--
CREATE TABLE `out_total` (
`total` decimal(32,0)
,`product_in_id` int(8)
);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(10) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `product_type_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_code`, `name`, `description`, `product_type_id`, `entry_dt`) VALUES
(1, 'SRT_2012', 'Shirt', 'Dandy', 1, '2018-02-02 00:26:36'),
(3, 'SRT_2016', 'T-Shirt', 'Pakija print', 1, '2018-02-02 12:06:33'),
(4, 'TW-20015', 'Towel', 'dfs', 1, '2018-02-05 20:02:48'),
(5, 'CH-2012', 'Chelower', 'sdfdsf', 1, '2018-02-05 20:03:18'),
(6, 'TV-24587', 'Televation', 'jdf sdjfhdsf', 8, '2018-02-06 20:23:23'),
(7, 'JKT-1254', 'Jaket', 'vhfxchc', 3, '2018-02-10 15:20:29'),
(8, 'P-12', 'Paracitamol', 'rgret', 9, '2018-02-11 15:09:44'),
(9, 'B-100', 'Battery', '12V', 6, '2018-02-13 11:00:37'),
(10, 'C-525', 'ABC', 'erw', 4, '2018-02-16 21:43:14');

-- --------------------------------------------------------

--
-- Table structure for table `product_in`
--

CREATE TABLE `product_in` (
  `id` int(10) NOT NULL,
  `dt` date NOT NULL,
  `product_id` int(5) NOT NULL,
  `qty` int(8) NOT NULL,
  `unit_value` double(15,2) NOT NULL,
  `sales_value` double(15,2) NOT NULL,
  `description` varchar(150) NOT NULL,
  `account_chart_id` int(5) NOT NULL,
  `employee_id` int(8) NOT NULL,
  `location_id` int(5) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_in`
--

INSERT INTO `product_in` (`id`, `dt`, `product_id`, `qty`, `unit_value`, `sales_value`, `description`, `account_chart_id`, `employee_id`, `location_id`, `entry_dt`) VALUES
(4, '2018-02-02', 3, 800, 350.00, 430.00, 'Pakija print', 1, 1, 1, '2018-02-02 13:13:12'),
(5, '2018-02-03', 3, 800, 400.00, 430.00, 'Ashoka Printing Co.', 1, 1, 1, '0000-00-00 00:00:00'),
(6, '2018-02-04', 1, 120, 500.00, 550.00, 'hghfg ', 2, 1, 2, '2018-02-04 09:48:26'),
(8, '2018-02-05', 4, 600, 500.00, 650.00, 'dsf', 2, 1, 2, '2018-02-05 20:05:25'),
(9, '2018-02-08', 3, 700, 400.00, 800.00, 'sdjrw rewr', 14, 1, 3, '2018-02-06 14:44:40'),
(13, '2018-02-09', 1, 500, 450.00, 500.00, 'Dandy dying', 2, 1, 1, '2018-02-08 11:32:30'),
(14, '2018-02-10', 7, 2000, 20.00, 25.00, 'vvg gf', 16, 1, 2, '2018-02-10 15:21:54'),
(15, '2018-02-11', 8, 5000, 2.00, 2.25, 'rt', 16, 1, 2, '2018-02-11 15:10:59'),
(16, '2018-02-13', 9, 85, 10000.00, 11500.00, 'ygf', 19, 1, 5, '2018-02-13 11:07:15'),
(17, '2018-02-13', 8, 50, 300.00, 350.00, 'dsflsdf', 1, 1, 5, '2018-02-13 21:44:46'),
(19, '2018-02-15', 7, 500, 600.00, 800.00, 'ioijiuj', 2, 2, 1, '2018-02-17 19:36:50'),
(20, '2018-02-19', 10, 5000, 100.00, 1000.00, 'dsaewfg', 2, 2, 2, '2018-02-19 15:55:33'),
(23, '2018-02-21', 1, 500, 10.00, 15.00, '', 1, 1, 1, '2018-02-21 16:30:39'),
(24, '2018-03-01', 5, 233, 300.00, 350.00, 'ffdfg', 2, 2, 1, '2018-03-01 18:46:56'),
(25, '2018-03-04', 9, 350, 250.00, 300.00, 'erwr', 6, 1, 5, '2018-03-04 07:50:46'),
(26, '2018-03-13', 5, 500, 250.00, 300.00, 'kjhnk', 1, 2, 5, '2018-03-14 23:40:47');

-- --------------------------------------------------------

--
-- Table structure for table `product_out`
--

CREATE TABLE `product_out` (
  `id` int(10) NOT NULL,
  `dt` date NOT NULL,
  `qty` int(8) NOT NULL,
  `rate` double(15,2) NOT NULL,
  `vat` double(15,2) NOT NULL,
  `tax` double(15,2) NOT NULL,
  `description` varchar(150) NOT NULL,
  `employee_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `product_in_id` int(8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_out`
--

INSERT INTO `product_out` (`id`, `dt`, `qty`, `rate`, `vat`, `tax`, `description`, `employee_id`, `entry_dt`, `product_in_id`) VALUES
(106, '2019-01-08', 15000, 5463856.00, 586876.00, 8769.00, '3wqeq', 2, '2019-01-17 01:12:46', 26),
(92, '2018-02-21', 200, 1500.00, 15.00, 1.00, 'ioijiuj', 2, '2018-02-21 22:54:35', 19),
(78, '2018-02-17', 5, 350.00, 15.00, 1.00, 'dsflsdf', 1, '2018-02-17 10:07:52', 17),
(77, '2018-02-16', 6, 11500.00, 15.00, 1.00, 'ygf', 1, '2018-02-16 22:46:38', 16),
(63, '2018-02-13', 55, 11500.00, 15.00, 1.00, 'ygf', 1, '2018-02-13 11:08:19', 16),
(65, '2018-02-13', 10, 11500.00, 15.00, 1.00, 'ygf', 1, '2018-02-13 14:17:49', 16),
(66, '2018-02-13', 20, 350.00, 15.00, 1.00, 'dsflsdf', 1, '2018-02-13 21:50:30', 17),
(67, '2018-02-13', 20, 350.00, 15.00, 1.00, 'dsflsdf', 1, '2018-02-13 22:11:27', 17),
(72, '2018-02-14', 3000, 2.25, 15.00, 1.00, 'rt', 1, '2018-02-14 15:55:29', 15),
(75, '2018-02-15', 50, 2.25, 15.00, 1.00, 'rt', 1, '2018-02-15 12:38:33', 15),
(74, '2018-02-15', 5, 11500.00, 15.00, 1.00, 'ygf', 1, '2018-02-15 11:08:32', 16),
(79, '2018-02-17', 4, 350.00, 15.00, 1.00, 'dsflsdf', 1, '2018-02-17 15:27:41', 17),
(80, '2018-02-17', 4, 350.00, 15.00, 1.00, 'dsflsdf', 1, '2018-02-17 15:27:42', 17),
(82, '2018-02-17', 4, 11500.00, 15.00, 1.00, 'ygf', 1, '2018-02-17 15:35:59', 16),
(83, '2018-02-17', 300, 800.00, 15.00, 1.00, 'ioijiuj', 2, '2018-02-17 19:37:57', 19),
(84, '2018-02-18', 4, 11500.00, 15.00, 1.00, 'ygf', 1, '2018-02-18 22:21:53', 16),
(85, '2018-02-18', 90, 550.00, 15.00, 1.00, 'hghfg ', 1, '2018-02-18 22:22:19', 6),
(86, '2018-02-20', 1, 11500.00, 15.00, 1.00, 'ygf', 1, '2018-02-20 14:41:25', 16),
(88, '2018-02-21', 50, 15.00, 15.00, 1.00, '', 1, '2018-02-21 16:32:03', 23),
(91, '2018-02-21', 450, 1500.00, 15.00, 1.00, '', 1, '2018-02-21 22:54:03', 23),
(93, '2018-02-21', 1000, 100.00, 15.00, 1.00, 'vvg gf', 1, '2018-02-21 22:55:14', 14),
(94, '2018-02-21', 1000, 200.00, 15.00, 1.00, 'rt', 1, '2018-02-21 22:55:58', 15),
(95, '2018-01-01', 200, 2500.00, 15.00, 1.00, 'vvg gf', 1, '2018-02-28 00:27:14', 14),
(96, '2018-03-01', 200, 350.00, 15.00, 1.00, 'ffdfg', 2, '2018-03-01 18:49:23', 24),
(97, '2018-03-04', 10, 300.00, 15.00, 1.00, 'erwr', 1, '2018-03-04 11:38:16', 25),
(98, '2018-03-04', 20, 30.00, 15.00, 1.00, 'erwr', 1, '2018-03-04 11:39:03', 25),
(99, '2018-03-04', 20, 300.00, 15.00, 1.00, 'erwr', 1, '2018-03-04 11:43:07', 25),
(100, '2018-03-14', 150, 300.00, 15.00, 1.00, 'kjhnk', 2, '2018-03-14 23:41:27', 26),
(101, '2018-05-17', 10, 300.00, 15.00, 1.00, 'kjhnk', 2, '2018-05-17 16:38:27', 26),
(103, '2019-01-02', 40, 522.00, 20.00, 10.00, 'rtwer', 1, '2019-01-16 11:15:39', 26),
(104, '2019-01-16', 50, 500.00, 50.00, 5.00, 'gdfgdfg', 1, '2019-01-16 12:02:57', 26);

-- --------------------------------------------------------

--
-- Table structure for table `product_type`
--

CREATE TABLE `product_type` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_type`
--

INSERT INTO `product_type` (`id`, `name`, `entry_dt`) VALUES
(1, 'Garments', '2018-02-06 19:31:29'),
(2, 'Stationaries', '2018-02-06 19:32:18'),
(3, 'Constructions', '2018-02-06 19:33:29'),
(4, 'Sanitaries', '2018-02-06 19:33:41'),
(5, 'Computers', '2018-02-06 19:34:32'),
(6, 'Electrical', '2018-02-06 19:34:50'),
(7, 'Solar Systems', '2018-02-06 19:35:04'),
(8, 'Electronics', '2018-02-06 20:22:58'),
(9, 'Medicine', '2018-02-11 11:22:50'),
(10, 'Agriculture', '2018-02-11 11:25:42'),
(11, 'Forestry', '2018-02-11 11:25:58'),
(12, 'Food & Hospitality', '2018-02-11 11:26:33'),
(13, 'Gaming', '2018-02-11 11:26:45'),
(14, 'Health Services', '2018-02-11 11:26:56'),
(15, 'Motor Vehicle', '2018-02-11 11:27:11'),
(16, 'Real Estate & Housing', '2018-02-11 11:27:30'),
(17, 'Transportation', '2018-02-11 11:27:46');

-- --------------------------------------------------------

--
-- Table structure for table `pw`
--

CREATE TABLE `pw` (
  `id` int(8) NOT NULL,
  `user` varchar(50) NOT NULL,
  `pw` varchar(50) NOT NULL,
  `company_id` int(5) NOT NULL,
  `short_name` varchar(50) NOT NULL,
  `bill_dt` date NOT NULL,
  `bill_amount` double(13,2) NOT NULL,
  `user_ip` varchar(50) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pw`
--

INSERT INTO `pw` (`id`, `user`, `pw`, `company_id`, `short_name`, `bill_dt`, `bill_amount`, `user_ip`, `entry_dt`) VALUES
(1, 'admin', 'admin', 101, 'ABC', '2020-01-10', 0.00, '', '2018-02-01 22:47:57'),
(2, '12345', '12345', 102, 'BMS', '2018-06-21', 0.00, '', '2018-02-21 11:20:53'),
(3, 'yy', 'yy', 103, 'yy', '2018-04-13', 0.00, '::1', '2018-03-14 11:03:56'),
(4, 'kk', 'kk', 104, 'kk', '2018-04-13', 0.00, '103.83.166.129', '2018-03-14 22:56:18');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `dt` date NOT NULL,
  `company_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `name`, `description`, `dt`, `company_id`, `entry_dt`) VALUES
(1, 'Meeting', 'At NGO Foram for election for new commitee  ', '2018-02-10', 0, '0000-00-00 00:00:00'),
(2, 'Micro bus Registration', 'BRTA', '2018-03-18', 101, '2018-02-06 00:32:24'),
(3, 'Meeting', 'Sonargaon', '2018-03-26', 101, '2018-02-17 12:24:24');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `district_id` varchar(50) NOT NULL,
  `country_id` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `company_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `name`, `address`, `district_id`, `country_id`, `mobile`, `company_id`, `entry_dt`) VALUES
(1, 'Nrayan Babu', 'Dinajpur', '26', '18', '416347', 101, '2018-02-14 08:00:10'),
(2, 'Elias Kanchan', 'Mirpur', '1', '18', '45422', 101, '2018-02-16 21:38:28');

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `name`, `entry_dt`) VALUES
(1, 'kg', '2018-02-06 19:57:17'),
(2, 'pc', '2018-02-06 19:57:54'),
(3, 'ltr', '2018-02-06 19:58:05'),
(4, 'gm', '2018-02-06 19:58:15'),
(5, 'gm', '2018-02-06 19:58:26'),
(6, 'ton', '2018-02-06 19:58:37'),
(7, 'ft', '2018-02-06 19:58:48'),
(8, 'mtr', '2018-02-06 19:58:56'),
(9, 'no', '2018-02-06 19:59:06'),
(10, 'yds', '2018-02-06 19:59:19');

-- --------------------------------------------------------

--
-- Table structure for table `vat_tax`
--

CREATE TABLE `vat_tax` (
  `id` int(10) NOT NULL,
  `vat` double(15,2) NOT NULL,
  `tax` double(15,2) NOT NULL,
  `company_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vat_tax`
--

INSERT INTO `vat_tax` (`id`, `vat`, `tax`, `company_id`, `entry_dt`) VALUES
(2, 15.00, 1.00, 101, '2018-02-09 18:53:24');

-- --------------------------------------------------------

--
-- Table structure for table `views`
--

CREATE TABLE `views` (
  `id` int(10) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `company_id` int(8) NOT NULL,
  `entry_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `views`
--

INSERT INTO `views` (`id`, `ip_address`, `company_id`, `entry_dt`) VALUES
(1, '::1', 101, '2018-03-12 16:18:23'),
(2, '::1', 101, '2018-03-12 16:18:40'),
(3, '103.83.166.129', 101, '2018-03-14 22:51:32'),
(4, '103.83.166.129', 104, '2018-03-14 22:56:31'),
(5, '103.83.166.129', 101, '2018-03-14 23:39:54'),
(6, '103.83.166.129', 101, '2018-03-15 00:08:43'),
(7, '103.60.175.121', 101, '2018-03-15 12:09:33'),
(8, '103.60.175.121', 101, '2018-03-15 12:31:28'),
(9, '103.60.175.121', 101, '2018-03-15 14:03:39'),
(10, '103.60.175.121', 101, '2018-03-15 14:03:59'),
(11, '103.60.175.121', 101, '2018-03-15 15:58:23'),
(12, '103.60.175.121', 101, '2018-03-15 16:21:29'),
(13, '103.83.166.129', 101, '2018-03-15 21:11:30'),
(14, '103.83.166.129', 101, '2018-03-15 21:16:25'),
(15, '103.83.166.129', 101, '2018-03-15 21:16:38'),
(16, '103.83.166.129', 101, '2018-03-15 21:19:28'),
(17, '103.83.166.129', 101, '2018-03-16 08:49:01'),
(18, '103.83.166.129', 101, '2018-03-16 13:28:34'),
(19, '103.60.175.121', 101, '2018-03-27 12:08:12'),
(20, '103.60.175.121', 101, '2018-03-27 14:42:15'),
(21, '103.83.164.147', 101, '2018-03-31 22:03:25'),
(22, '103.83.164.147', 101, '2018-04-01 00:34:53'),
(23, '103.60.175.121', 101, '2018-04-02 14:18:08'),
(24, '103.60.175.121', 101, '2018-04-04 10:17:52'),
(25, '103.83.164.147', 101, '2018-04-06 21:37:07'),
(26, '103.83.164.147', 101, '2018-04-08 21:02:23'),
(27, '103.83.164.147', 101, '2018-04-08 21:03:56'),
(28, '103.83.164.147', 101, '2018-04-08 21:04:23'),
(29, '103.83.164.147', 101, '2018-04-08 21:04:24'),
(30, '103.83.164.147', 101, '2018-04-08 21:31:45'),
(31, '103.60.175.121', 101, '2018-05-17 16:23:49'),
(32, '103.60.175.121', 101, '2018-05-17 16:35:55'),
(33, '103.83.164.147', 101, '2019-01-14 21:55:15');

-- --------------------------------------------------------

--
-- Structure for view `out_list`
--
DROP TABLE IF EXISTS `out_list`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `out_list`  AS  select `product_out`.`id` AS `id`,`product_out`.`dt` AS `dt`,`product_out`.`qty` AS `qty`,`product_out`.`rate` AS `rate`,`product_out`.`vat` AS `vat`,`product_out`.`tax` AS `tax`,(((`product_out`.`qty` * `product_out`.`rate`) + `product_out`.`vat`) + `product_out`.`tax`) AS `total`,`product`.`name` AS `name` from ((`product_out` left join `product_in` on((`product_out`.`product_in_id` = `product_in`.`id`))) left join `product` on((`product_in`.`product_id` = `product`.`id`))) order by `product_out`.`id` desc ;

-- --------------------------------------------------------

--
-- Structure for view `out_total`
--
DROP TABLE IF EXISTS `out_total`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `out_total`  AS  select sum(`product_out`.`qty`) AS `total`,`product_out`.`product_in_id` AS `product_in_id` from `product_out` group by `product_out`.`product_in_id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_chart`
--
ALTER TABLE `account_chart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `account_type`
--
ALTER TABLE `account_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank_account`
--
ALTER TABLE `bank_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bills_final`
--
ALTER TABLE `bills_final`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bills_raw`
--
ALTER TABLE `bills_raw`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cash_in`
--
ALTER TABLE `cash_in`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cash_out`
--
ALTER TABLE `cash_out`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cash_source`
--
ALTER TABLE `cash_source`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cheque_in`
--
ALTER TABLE `cheque_in`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cheque_out`
--
ALTER TABLE `cheque_out`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `money_receipt`
--
ALTER TABLE `money_receipt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_in`
--
ALTER TABLE `product_in`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_out`
--
ALTER TABLE `product_out`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_type`
--
ALTER TABLE `product_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pw`
--
ALTER TABLE `pw`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vat_tax`
--
ALTER TABLE `vat_tax`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `views`
--
ALTER TABLE `views`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_chart`
--
ALTER TABLE `account_chart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `account_type`
--
ALTER TABLE `account_type`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `bank_account`
--
ALTER TABLE `bank_account`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bills_final`
--
ALTER TABLE `bills_final`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `bills_raw`
--
ALTER TABLE `bills_raw`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cash_in`
--
ALTER TABLE `cash_in`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `cash_out`
--
ALTER TABLE `cash_out`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `cash_source`
--
ALTER TABLE `cash_source`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cheque_in`
--
ALTER TABLE `cheque_in`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `cheque_out`
--
ALTER TABLE `cheque_out`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=250;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` int(2) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `money_receipt`
--
ALTER TABLE `money_receipt`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `product_in`
--
ALTER TABLE `product_in`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `product_out`
--
ALTER TABLE `product_out`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `product_type`
--
ALTER TABLE `product_type`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `pw`
--
ALTER TABLE `pw`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `vat_tax`
--
ALTER TABLE `vat_tax`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `views`
--
ALTER TABLE `views`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
