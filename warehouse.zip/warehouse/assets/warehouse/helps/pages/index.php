<?php
session_start();
// index.php
date_default_timezone_set("Asia/Dhaka");
$title ="Helps";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Helps</h3>
 	</div>
 	<div class="col-sm-12">
		<div class="well">
			<ul class="list-group">
				<li class="list-group-item"><span class="glyphicon glyphicon-play"></span> Sign Up > Sign In</li>
				<li class="list-group-item"><span class="glyphicon glyphicon-play"></span> Setup all information on <b>Settings</b> menu.</li>
				<li class="list-group-item"><span class="glyphicon glyphicon-play"></span> Entered regular transections on <b>Transection</b> menu.</li>
				<li class="list-group-item"><span class="glyphicon glyphicon-play"></span> Get a lot of results/reports from <b>Views</b> menu and download by clicking on <b>Download</b> link as a microsoft excel file.</li>
				<li class="list-group-item"><span class="glyphicon glyphicon-play"></span> Write your valuable comments or suggestion on <b>Comments</b> box.</li>				
				<li class="list-group-item"><b><span class="glyphicon glyphicon-play"></span><b> Enjoy!</b></li>
			</ul>
		
		</div>	
 	</div>	

</div>	
<script>
 	function deletefunction(id){
 	 	if (confirm("Are u sure?") == true){
 	 	 	window.location.href="index.php?id=" + id;
 	 	}
 	}
 	
 	$('[data-toggle="tooltip"]').tooltip();
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
