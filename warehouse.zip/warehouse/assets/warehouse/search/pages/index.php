<?php
session_start();
// reports.php
date_default_timezone_set("Asia/Dhaka");
$title ="Search";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">&nbsp;</h3>
 	</div>
 	<div class="col-sm-6" id="display">
	
 	</div>	
 	<div class="col-sm-6 text-right">
 	</div>
	<div class="col-sm-8 col-sm-offset-2">     
		<div class="panel panel-default">
                <div class="panel-heading"><h3>Search</h3></div>
                <div class="panel-body">
                    <p class="text-warning" id="info"> </p>
						<div class="list-group">
							<a href="#" class="list-group-item">Stock</a>
							<a href="#" class="list-group-item">Bills</a>
							<a href="#" class="list-group-item">Customers</a>
							<a href="#" class="list-group-item">Supplier</a>
							<a href="#" class="list-group-item">Employee</a>
						</div>
                </div>
        </div>
	</div>

</div>	
<script>
 	$(document).ready(function(){
 	    $('[data-toggle="tooltip"]').tooltip();
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>
