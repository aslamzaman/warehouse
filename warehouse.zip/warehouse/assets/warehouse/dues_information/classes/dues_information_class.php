<?php
class dues_information_class
{

	public function balcne_create($company_id,$d1,$d2, $id)
	{
		global $db;
		global $mysqldb;
		$this->tbl_create($company_id,$d1,$d2,$id);
		
		
		
		$table = "`temp_table`";
		$orderBy ="`dt` ASC";
		$p = $mysqldb->select_all_row($table, $where=false, $orderBy, $limit=false);
		if(count($p) > 0) 
		{
			$b = $this->previous_balance($company_id,$d1,$id);
			echo "<tr>\n";
			echo "<td>Previous Balance</td>\n";			
			echo "<td></td>\n";
			echo "<td></td>\n";
			echo "<td class='text-right'>$b</td>\n";
			echo "<tr>\n";			
			foreach ($p as $q)
			{
				$b = $b + $q['c_out'] - $q['c_in'] ;
				echo "<tr>\n";
				echo "<td>".$q['dt']."</td>\n";

				if($q['c_out'] > 0)
				{
					echo "<td class='text-right'>".number_format($q['c_out'],2)."</td>\n";
				}
				else
				{
					echo "<td class='text-right'>-</td>\n";
				}
				
				
				if($q['c_in'] > 0)
				{
					echo "<td class='text-right'>".number_format($q['c_in'],2)."</td>\n";
				}
				else
				{
					echo "<td class='text-right'>-</td>\n";
				}
				
				echo "<td class='text-right'>".number_format($b,2)."</td>\n";
				echo "<tr>\n";				
			}
		}
		
	}




//=============================================================
	public function tbl_create($company_id, $d1, $d2, $id)
	{
		global $db;
		global $mysqldb;
		$sql_create = "CREATE TEMPORARY TABLE `temp_table`(
		`dt` date NOT NULL,
		`c_in` double(15,2) NOT NULL,
		`c_out` double(15,2) NOT NULL
		) ENGINE=MyISAM DEFAULT CHARSET=latin1";
		mysqli_query($db, $sql_create);
		
		
		$table = "`cash_in`";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2' AND `cash_source_id` = 1 AND `account_chart_id` = $id";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);

		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				$table = "`temp_table`";
				$fields =          "`dt`,            `c_in`, `c_out`";
				$vars = "'". $q['dt']."', ". $q['amount'].",       0";
				$mysqldb->add($table, $fields, $vars);
			}
		}
		
		$table = "`cheque_in`";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2' AND `cash_source_id` = 1 AND `account_chart_id` = $id";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	

				$table = "`temp_table`";
				$fields =          "`dt`,            `c_in`, `c_out`";
				$vars = "'". $q['dt']."', ". $q['amount'].",       0";
				$mysqldb->add($table, $fields, $vars);
			}
		}



		$table = "`product_out`";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2' AND `cash_source_id` = 1 AND `account_chart_id` = $id";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				$value = ($q['qty'] * $q['sales_value']);
				$v = $value * ($q['vat']/100);
				$t = $value * ($q['tax']/100);
				$total_value = $value + $v + $t;
				$b = $total_value;	
				

				$table = "`temp_table`";
				$fields =          "`dt`, `c_in`, `c_out`";
				$vars = "'". $q['dt']."',      0,      $b";
				$mysqldb->add($table, $fields, $vars);
			}
		}

		
			
	}	
//============================================================
	public function previous_balance($company_id,$d1,$id)
	{
		global $mysqldb;
		
		$d2 = date("Y-m-d",(strtotime($d1) - 86400));
		$table = "`cash_in`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '1970-01-01' AND '$d2' AND `cash_source_id` = 1 AND `account_chart_id` = $id";		
		$cash = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */
		
		
		$table = "`cheque_in`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '1970-01-01' AND '$d2' AND `cash_source_id` = 1 AND `account_chart_id` = $id";		
		$cheque = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */		
	
		
		$table = "product_out";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '1970-01-01' AND '$d2' AND `cash_source_id` = 1 AND `account_chart_id` = $id";	
		// $orderBy = "`name` ASC";
		//$limit = 5;
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);		
		$x = 0;
		if($p)
		{
			foreach ($p as $q)
			{
				
				$value = ($q['qty'] * $q['sales_value']);
				$v = $value * ($q['vat']/100);
				$t = $value * ($q['tax']/100);
				$total_value = $value + $v + $t;
				$x = $x + $total_value;	
			}
		}
		
		
		$balance = ($x - $cash - $cheque);
		return $balance; 
	}
	
}
$dues_information = new dues_information_class();
?>	
	
	