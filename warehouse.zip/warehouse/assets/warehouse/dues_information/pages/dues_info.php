<?php

/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('Asia/Dhaka');

/** PHPExcel_IOFactory */
require_once dirname(__FILE__) . '/../../../plugins/phpexcel/Classes/PHPExcel/IOFactory.php';


// echo date('H:i:s') , " Load from Excel5 template" , EOL;

$objReader = PHPExcel_IOFactory::createReader('Excel5');
/* ------------    Border   ---------------- */
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);

/*  ================ Customize section ================  */
/* ------------------------------------------------------------------ */
$objPHPExcel = $objReader->load("../excel/x.xls"); /** Load Excel File */
//=========Statement Updae End======================= 
	
	
	/** Company Name and Address */
	$company = $company_name->show_phpexcel($company_id);
	$objPHPExcel->getActiveSheet()->setCellValue('A1',$company[0]);
	$objPHPExcel->getActiveSheet()->setCellValue('A2',$company[1]);
	$objPHPExcel->getActiveSheet()->setCellValue('A3',$company[2]);
	
	
	/** Cutomer Name and Address */
	$objPHPExcel->getActiveSheet()->setCellValue('A5',$p['name']);
	$objPHPExcel->getActiveSheet()->setCellValue('A6',$p['address'].", Mobile: ".$p['mobile']);
	
	
	/** Period */
	$objPHPExcel->getActiveSheet()->setCellValue('A7',"Period: ".$d1." to ". $d2);	
	
	
	/** Date Today */
	$objPHPExcel->getActiveSheet()->setCellValue('C7',"Date: ".date("Y-m-d"));
	
	
	/** Temporary Table Data  */	
		$table = "`temp_table`";
		$orderBy ="`dt` ASC";
		$p = $mysqldb->select_all_row($table, $where=false, $orderBy, $limit=false);
			$i = 10;
			$r =array();		
		if(count($p) > 0) 
		{
			
			/** Previous Balance */
			$b = $dues_information->previous_balance($company_id,$d1,$id);
			$objPHPExcel->getActiveSheet()->setCellValue('A9',$d1);
			$objPHPExcel->getActiveSheet()->setCellValue('B9',"Previous Balance");
			$objPHPExcel->getActiveSheet()->setCellValue('D9',$b);
			/** Previous Balance Border */
			$objPHPExcel->getActiveSheet()->getStyle('A9:A9')->applyFromArray($styleThinBlackBorderOutline);
			$objPHPExcel->getActiveSheet()->getStyle('B9:B9')->applyFromArray($styleThinBlackBorderOutline);
			$objPHPExcel->getActiveSheet()->getStyle('D9:D9')->applyFromArray($styleThinBlackBorderOutline);
			
			foreach ($p as $q)
			{
				$b = $b + $q['c_out'] - $q['c_in'];
				
				
				$r =array("A$i","B$i","C$i","D$i");
				$objPHPExcel->getActiveSheet()->setCellValue($r[0],$q['dt']);
				if($q['c_out'] > 0)
				{
					$objPHPExcel->getActiveSheet()->setCellValue($r[1],number_format($q['c_out'],2,'.',''));
				}
				else
				{
					$objPHPExcel->getActiveSheet()->setCellValue($r[1],"-");					
					$objPHPExcel->getActiveSheet()->getStyle($r[1])->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);

				}
				
				if($q['c_in'] > 0)
				{
					$objPHPExcel->getActiveSheet()->setCellValue($r[2],number_format($q['c_in'],2,'.',''));
				}
				else
				{
					$objPHPExcel->getActiveSheet()->setCellValue($r[2],"-");
					$objPHPExcel->getActiveSheet()->getStyle($r[2])->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
				}				
					$objPHPExcel->getActiveSheet()->setCellValue($r[3],number_format($b,2,'.',''));

					$x = "";
					$n =0;	
					while($n < 4)
					{								
						$x = "$r[$n]:$r[$n]";
						$objPHPExcel->getActiveSheet()->getStyle($x)->applyFromArray($styleThinBlackBorderOutline);
						$n++;
					}
			
				
				$i++;
					
			}
		}
echo "<a href='dues_info.xlsx' class='btn btn-primary btn-xs'>Download <i class='fa fa-file-excel-o '></i> </a>";


$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save(str_replace('.php', '.xlsx', __FILE__));

?>