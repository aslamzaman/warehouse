<?php
class cheque_out_class
{
	
	public function chart_ac_drop_down($company_id,$sourceid,$selectedId)
	{
		global $db;
		global $mysqldb;
		if($sourceid == 1)
		{
			$mysqldb->drop_down("customer", "id", "name", $selectedId,"`company_id` = $company_id","`name` ASC", $limit=false);
		}
		else if($sourceid == 2)
		{
			$mysqldb->drop_down("supplier", "id", "name", $selectedId, "`company_id` = $company_id", "`name` ASC", $limit=false);
		}
		else
		{
			$sql = "SELECT `id`, `name`, `account_type_id` FROM `account_chart` WHERE `company_id` = $company_id ORDER BY `account_type_id` ASC";
			$result=mysqli_query($db, $sql); 
			$Numrows=mysqli_num_rows($result);
			if($Numrows > 0)
			{
				echo "\n";
				while($rows= mysqli_fetch_array($result))
				{
					$nm = $mysqldb->name_by_id("account_type","name","id",$rows['account_type_id']);
					if($rows['id']== $selectedId)
					{
						echo "<option value='".$rows['id']."' selected>".$rows['name']." - $nm</option>\n";
					}
					else
					{
						echo "<option value='".$rows['id']."'>".$rows['name']." - $nm</option>\n";
					}
				}
			}
		}
	
	}	


	public function name_by_source_id($company_id,$sourceid,$chartId)
	{
		global $db;
		$table = "";
		if($sourceid == 1)
		{
			$table = "customer";
		}
		else if($sourceid == 2)
		{
			$table = "supplier";
		}
		else
		{
			$table = "account_chart";	
		}

		$sql = "SELECT `name` FROM $table WHERE `id` = $chartId  AND `company_id` = $company_id LIMIT 1";
		$result=mysqli_query($db, $sql);
		$Numrows=mysqli_num_rows($result);
		if($Numrows > 0)
		{
			$rows = mysqli_fetch_array($result);
			$x = $rows['name'];
			return $x;
		}
	}	
	
}
$cheque_out = new cheque_out_class();

 ?>






	
