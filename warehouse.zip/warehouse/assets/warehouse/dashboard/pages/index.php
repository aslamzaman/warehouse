<?php
session_start();
$title ="Dashboard";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
require_once ('../classes/dashboard.php');
require_once ('../classes/top_10_dues_class.php');
require_once ('../classes/loss_profit_line_chart_class.php');
require_once ('../classes/product_sale_chart_class.php');


// index.php
$company_id = $_SESSION["company_id"];
function customPageHeader(){?>

 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	#provider_msg
 	{
 	  background-color:#339933;
 	  padding-top:10px;
 	  padding-bottom:10px;
 	  padding-left:5px;
 	  padding-right:5px;
 	  font-size: 18px;
 	  color:#ffffff;
 	  text-align:center;
 	    
 	}
 	 	
 	</style>
	

	
<?php }?>
<div class="row">
 	<div class="col-sm-12">
 	    <div id="provider_msg">
          welcome to small business warehouse
        </div> 
 	</div>    
 	<div class="col-sm-12">
 	 	<h3 class="text-primary">Dashboard</h3>
 	</div>
	
	<div class="col-sm-8">
	
		<div class="col-sm-12">	
			<div class="well">
					<!--    --------------------------------   Sale Column Chart  -------------------------------- -->

					<script>
						google.charts.load('current', {packages: ['corechart', 'bar']});
						google.charts.setOnLoadCallback(drawBasic);

						function drawBasic() {

							  var data = new google.visualization.DataTable();
							  data.addColumn('timeofday', 'Time of Day');
							  data.addColumn('number', 'Taka ');

							  data.addRows([
							   <?php
							   
							   $product_sale_chart->chartRow($company_id);
							   ?>
							  ]);

							  var options = {
								title: 'Sales Level On 12 Months',
								hAxis: {
								  title: 'Months',
								  viewWindow: {
									min: [0, 0, 0],
									max: [14, 0, 0]
								  }
								},
								vAxis: {
								  title: 'Sales in Taka'
								}
							  };

							  var chart = new google.visualization.ColumnChart(
								document.getElementById('chart_div_col'));

							  chart.draw(data, options);
							}				
										
					</script>
					<div id="chart_div_col"></div>
				</div>
		</div>				
				
				<div class="col-sm-12">
					<div class="well">
						<!--    --------------------------------   Profit Line Chart  -------------------------------- -->
						<script>
							google.charts.load('current', {packages: ['corechart', 'line']});
							google.charts.setOnLoadCallback(drawBackgroundColor);			
							function drawBackgroundColor() {
								  var data = new google.visualization.DataTable();
								  data.addColumn('number', 'X');
								  data.addColumn('number', 'Profit');

								  data.addRows([
									<?php 

										$loss_profit_line_chart->chartRow($_SESSION["company_id"]);
									?>
								  ]);

								  var options = {
									title: 'Profit or loss on 26 weeks',
									hAxis: {
									  title: '26 Weeks'
									},
									vAxis: {
									  title: 'Profit / Loss (%)'
									},
									backgroundColor: '#f1f8e9'
								  };

								  var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
								  chart.draw(data, options);
								}			
						
						</script>	
						<div id="chart_div"></div>
					</div>	
				</div>	

				
				<div class="col-sm-6">
					 <div class="well">
						<div class="table-responsive">
							<table class="table table-striped">
								<thead>
									<tr>
										<th colspan=3 class='bg-primary'>Cash Balance</th>
									</tr>
								</thead>
								<tbody>		 
							<?php
									$b=$dashboard->cash_balance($company_id);
									echo "<tr class='warning'>";
									echo "<td colspan=2>Cash In Hand</td>";
									echo "<td class='text-right'>".$b."</td>";
									echo "</tr>";				
							?>
								</tbody>
							</table>			
						</div>
					</div>
					
				<!--    --------------------------------   Bank Balance -------------------------------- -->
					 <div class="well">
						<div class="table-responsive">	
							<table class="table table-striped">
								<thead>
									<tr>
										<th colspan=3 class='bg-primary'>Bank Balance</th>
									</tr>
								</thead>
								<tbody>
							<?php

								$table = "bank_account";
								$where = "`company_id` = $company_id AND `id` IN(SELECT `bank_account_id` FROM `cheque_in` WHERE `company_id` = $company_id)";	
								$orderBy = "`name` ASC";
								$p= $mysqldb->select_all_row($table, $where, $orderBy, $limit=false);			
									if(count($p) > 0)
									{
										$a = array("class='warning'", "class='success'");
										$i = 0;
										foreach($p as $rows)
										{	
											$b=$dashboard->bank_balance($company_id,$rows['id']);
											echo "<tr ".$a[$i].">";
											echo "<td colspan=2>".$rows['name']."</td>";
											echo "<td class='text-right'>".$b."</td>";
											echo "</tr>";
											$i++;
											if(	$i >= 2)
											{
											  $i= 0;
											}
											
											
										}
									}		
							?>
								</tbody>
							</table>
						</div>	
					</div>	


				</div>
				<div class="col-sm-6">
					
				<!--    --------------------------------   Top 10 Deues -------------------------------- -->	
					 <div class="well">
					 	<div class="table-responsive">
							<table class="table table-striped">
								<thead>
									<tr>
										<th colspan=3 class='bg-primary'>Top 10 Deues</th>
									</tr>
								</thead>
								<tbody>
									<?php
										$top_10_dues->show_table($company_id);
									?>
								</tbody>
							</table>
						</div>	
					</div>			
				
				
				
				</div>
	</div>			
  	<div class="col-sm-4">
	<!--    --------------------------------   Stock Balance -------------------------------- -->	
		 <div class="well">
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th colspan=3 class='bg-primary'>Stock Balance</th>
						</tr>
					</thead>
					<tbody>
				<?php

					$table = "product";
					$where = "`company_id` = $company_id AND `id` IN(SELECT `product_id` FROM `product_in` WHERE `company_id` = $company_id)";	
					$orderBy = "`name` ASC";
					$p= $mysqldb->select_all_row($table, $where, $orderBy, $limit=false);			
						if(count($p) > 0)
						{
							$a = array("class='warning'", "class='success'");
							$i = 0;						
							foreach($p as $rows)
							{	
								$b=$dashboard->stock_balance($company_id,$rows['id']);
								echo "<tr ".$a[$i].">";
								echo "<td>".$rows['product_code']."</td>";
								echo "<td>".$rows['name']."</td>";
								echo "<td class='text-right'>".$b."</td>";
								echo "</tr>";
								$i++;
								if(	$i >= 2)
								{
								  $i= 0;
								}							
								
							}
						}		
				?>
					</tbody>
				</table>
			</div>	
		</div>		
	
	
	
		<!--    --------------------------------   Warehouse Location -------------------------------- -->	
		 <div class="well">
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th colspan=3 class='bg-primary'>Warehouse Location</th>
						</tr>
					</thead>
					<tbody>
				<?php

					$table = "location";
					$where = "`company_id` = $company_id";	
					$orderBy = "`name` ASC";
					$p= $mysqldb->select_all_row($table, $where, $orderBy, $limit=false);			
						if(count($p) > 0)
						{
							$a = array("class='warning'", "class='success'");
							$i = 0;							
							foreach($p as $rows)
							{	
								$b=$dashboard->stock_balance($company_id,$rows['id']);
								echo "<tr ".$a[$i].">";
								echo "<td colspan=2>".$rows['name']."</td>";
								echo "<td class='text-right'>".$rows['mobile']."</td>";
								echo "</tr>";
								$i++;
								if(	$i >= 2)
								{
								  $i= 0;
								}								
							}
						}		
				?>
					</tbody>
				</table>
			</div>	
		</div>			
	
	
	
	
	
		 <div class="well">
<!--    --------------------------------   Work Schedule  -------------------------------- -->	
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th colspan=2 class='bg-primary'>Work Schedule</th>
						</tr>
					</thead>
					<tbody>
				<?php
					$sc_d = strtotime(date("Y-m-d"));
					$sc_d1 = date("Y-m-d"); 
					$sc_d2 = date("Y-m-d",($sc_d + (86400 * 10))); 
					$table = "schedule";
					$where = "`dt` BETWEEN '$sc_d1' AND '$sc_d2' AND `company_id` = $company_id";	
					$orderBy = "`dt` ASC";
					$p= $mysqldb->select_all_row($table, $where, $orderBy, $limit=false);			
						if(count($p) > 0)
						{
							$a = array("class='warning'", "class='success'");
							$i = 0;								
							foreach($p as $rows)
							{	
								echo "<tr ".$a[$i].">";
								echo "<td>".$rows['dt']."</td>";
								echo "<td>".$rows['name']."</td>";
								echo "</tr>";
								$i++;
								if(	$i >= 2)
								{
								  $i= 0;
								}							
							}
						}		
				?>
					</tbody>
				</table>
			</div>
		</div>		
 	</div>	
</div>



<?php
 	include "../../layout/footer/footer.php";
?>