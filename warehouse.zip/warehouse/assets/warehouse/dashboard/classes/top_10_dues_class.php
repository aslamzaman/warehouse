<?php
class top_10_dues_class
{

	public function show_table($company_id)
	{
		global $mysqldb;
		$this->tbl_create($company_id);
		
		$table = "`temp_table`";
		$orderBy ="`cash` DESC";
		$limit = 10;
		$p = $mysqldb->select_all_row($table, $where=false, $orderBy, $limit);
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{			
				echo "<tr>\n";
				echo "<td>".$q['name']."</td>\n";
				echo "<td class='text-right'>".number_format($q['cash'],0)."</td>\n";
				echo "</tr>\n";
			}
			
		}
	}




//=============================================================
	public function tbl_create($company_id)
	{
		global $db;
		global $mysqldb;
		$sql_create = "CREATE TEMPORARY TABLE `temp_table`(
		`name` varchar(50) NOT NULL,
		`cash` double(15,2) NOT NULL
		) ENGINE=MyISAM DEFAULT CHARSET=latin1";
		mysqli_query($db, $sql_create);
		
		$table = "customer";
		$where = "`company_id`= $company_id";	
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);

		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	

				$nm = $q['name'];
				$tk = $this->balance($company_id,$q['id']);
				
				$table = "`temp_table`";
				$fields = "`name`,`cash`";
				$vars = "'$nm', $tk";
				$mysqldb->add($table, $fields, $vars);
			}
		}
			
	}



	
//============================================================
	public function balance($company_id,$id)
	{
		global $mysqldb;

		$table = "`cash_in`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `cash_source_id` = 1 AND `account_chart_id` = $id";		
		$cash = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */
		
		
		$table = "`cheque_in`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `cash_source_id` = 1 AND `account_chart_id` = $id";		
		$cheque = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */		
	
		
		$table = "product_out";
		$where = "`company_id`= $company_id AND `cash_source_id` = 1 AND `account_chart_id` = $id";	
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);		
		$x = 0;
		if($p)
		{
			foreach ($p as $q)
			{
				$value = ($q['qty'] * $q['sales_value']);
				$v = $value * ($q['vat']/100);
				$t = $value * ($q['tax']/100);
				$total_value = $value + $v + $t;
				
				$x = $x + $total_value;
			}
		}		
		
		$balance = ($x - $cash - $cheque);
		return $balance; 
	}
	

	
	
}
$top_10_dues = new top_10_dues_class();
?>	
	
	