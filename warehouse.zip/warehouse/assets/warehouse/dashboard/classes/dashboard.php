<?php
class dashboard_class
{

//============================================================
/** --------------------------------------------------------------- */
/* Bank Balance ---------------------------------------------------
/** --------------------------------------------------------------- */

	public function ware_house_location($company_id)
	{
		global $mysqldb;

		$table = "`cheque_in`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `bank_account_id` = $id";		
		$p_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	

		/** -------------------------------------- */
		$table = "`cheque_out`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `bank_account_id` = $id";		
		$p_out = $mysqldb->total_amount($table, $field, $where, $limit=false);		

		$balance = ($p_in - $p_out);
		
		return $balance; 
	}
	


/** --------------------------------------------------------------- */
/* Bank Balance ---------------------------------------------------
/** --------------------------------------------------------------- */

	public function bank_balance($company_id,$id)
	{
		global $mysqldb;

		$table = "`cheque_in`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `bank_account_id` = $id";		
		$p_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	

		/** -------------------------------------- */
		$table = "`cheque_out`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `bank_account_id` = $id";		
		$p_out = $mysqldb->total_amount($table, $field, $where, $limit=false);		

		$balance = ($p_in - $p_out);
		
		return $balance; 
	}
	




/** --------------------------------------------------------------- */
/* Cash Balance ---------------------------------------------------
/** --------------------------------------------------------------- */

	public function cash_balance($company_id)
	{
		global $mysqldb;

		$table = "`cash_in`";
		$field = "amount";
		$where = "`company_id`= $company_id";		
		$p_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
        
       
	
		/** -------------------------------------- */
		$table = "`cash_out`";
		$field = "amount";
		$where = "`company_id`= $company_id";		
		$p_out = $mysqldb->total_amount($table, $field, $where, $limit=false);		


		$balance = ($p_in - $p_out);
		
		return $balance; 
	}
	
	

/** --------------------------------------------------------------- */
/* Stock Balance ---------------------------------------------------
/** --------------------------------------------------------------- */

	public function stock_balance($company_id,$id)
	{
		global $mysqldb;

		$table = "`product_in`";
		$field = "qty";
		$where = "`company_id`= $company_id AND `product_id` = $id";		
		$p_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */
		$table = "`product_out`";
		$field = "qty";
		$where = "`company_id`= $company_id AND `product_id` = $id";		
		$p_out = $mysqldb->total_amount($table, $field, $where, $limit=false);		
		
		$balance = ($p_in - $p_out);
		
		return $balance; 
	}
	
}
$dashboard = new dashboard_class();
?>	
	
	