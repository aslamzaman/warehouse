<?php
class loss_profit_line_chart_class
{

	public function chartRow($company_id)
	{

		
		/* --- times of last 6 months ago  ---- */
		$first_dt = strtotime(date("Y-m-d"))-(180*86400);
		
		$x = "";
		$i = 0;
		$n = 0;
		while($i < 27)
		{
			/* --- 7 days increement  ---- */
			$n = $i * 7;
			
			/* --- after 7 days a new date  ---- */
			$new_dt1 = $first_dt + ($n * 86400);
			$new_dt2 = date("Y-m-d",$new_dt1);
			
		
			 $loss_profit =  $this->lossProfit($company_id, $new_dt2);
			$x = $x . "[". $i.", ". number_format($loss_profit,2)."], ";

			$i++;
		}
		$y = substr($x,0,strlen($x)-2);
		echo $y;
		
	}
	
	
	
	public function lossProfit($company_id, $last_dt)
	{
		$exp = $this->expance($company_id, $last_dt);
		$rev = $this->revenue($company_id, $last_dt);	
		
		$pIn = $this->product_in($company_id, $last_dt);
		$pOut = $this->product_out($company_id, $last_dt);

		$cp = $pIn + $exp;
		$sp = $pOut+ $rev;
		$profit = $sp - $cp;
		
		$percnt = 0;
		if($cp < 1)
		{
			$percnt = 0;
		}
		else
		{
			$percnt = ($profit / $cp)*100;
		}
		
		return $percnt;
		
	}

		


	public function revenue($company_id, $last_dt)
	{
		global $mysqldb;
		
		
		$first_dt = strtotime($last_dt)-(180*86400);
		$first_dt1 = date("Y-m-d",$first_dt);
		
		$balance = 0;
		$row = $mysqldb->select_all_row("account_chart","`company_id`= $company_id AND `account_type_id` = 4", $orderBy=false, $limit=false);
		if(count($row) > 0) 
		{
			foreach ($row as $rows)
			{

				$table = "`cash_in`";
				$field = "amount";
				$where = "`company_id`= $company_id AND `dt` BETWEEN '$first_dt1' AND '$last_dt' AND `account_chart_id` = ".$rows['id'];	
				$ca_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
				/** -------------------------------------- */
				
				
				$table = "`cheque_in`";
				$field = "amount";
				$where = "`company_id`= $company_id AND `dt` BETWEEN '$first_dt1' AND '$last_dt' AND `account_chart_id` = ".$rows['id'];		
				$ch_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
			
				$x = $ch_in + $ca_in;
			
			$balance = $balance + $x ;
			
			}
		}
		return $balance; 
	}


	public function expance($company_id, $last_dt)
	{
		global $mysqldb;
		
		
		$first_dt = strtotime($last_dt)-(180*86400);
		$first_dt1 = date("Y-m-d",$first_dt);		
		
		$balance = 0;
		$row = $mysqldb->select_all_row("account_chart","`company_id`= $company_id AND `account_type_id` = 5", $orderBy=false, $limit=false);
		if(count($row) > 0) 
		{
			foreach ($row as $rows)
			{
				$table = "`cash_out`";
				$field = "amount";
				$where = "`company_id`= $company_id AND `dt` BETWEEN '$first_dt1' AND '$last_dt' AND `account_chart_id` = ".$rows['id'];	
				$ca_out = $mysqldb->total_amount($table, $field, $where, $limit=false);	
				/** -------------------------------------- */
				
				
				$table = "`cheque_out`";
				$field = "amount";
				$where = "`company_id`= $company_id AND `dt` BETWEEN '$first_dt1' AND '$last_dt' AND `account_chart_id` = ".$rows['id'];		
				$ch_out = $mysqldb->total_amount($table, $field, $where, $limit=false);	
			
			
				$x = $ch_out + $ca_out;
			
			$balance = $balance + $x ;
			
			}
		}
		return $balance; 
	}


	public function product_out($company_id, $last_dt)
	{
		global $db;
	
		$first_dt = strtotime($last_dt)-(180*86400);
		$first_dt1 = date("Y-m-d",$first_dt);
		
		$sql = "SELECT `qty` * `sales_value` as total FROM product_out  WHERE `company_id`= $company_id AND `dt` BETWEEN '$first_dt1' AND '$last_dt'";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x = 0;
		if($Numrows > 0)
 	 	{
			$t = 0;
			while($rows= mysqli_fetch_array($result))
			{
				$t = $t + $rows['total'];
			}
			$x = $t;
		}
		else
		{
			$x = 0;	
		}
		return $x;
	}	
	

	public function product_in($company_id, $last_dt)
	{
		global $db;
		
		$first_dt = strtotime($last_dt)-(180*86400);
		$first_dt1 = date("Y-m-d",$first_dt);
		
		$sql = "SELECT `qty` * `unit_value` as total FROM product_in WHERE `company_id`= $company_id AND `dt` BETWEEN '$first_dt1' AND '$last_dt'";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x = 0;
		if($Numrows > 0)
 	 	{
			$t = 0;
			while($rows= mysqli_fetch_array($result))
			{
				$t = $t + $rows['total'];
			}
			$x = $t;
		}
		else
		{
			$x = 0;	
		}
		return $x;
	}


	
}
$loss_profit_line_chart = new loss_profit_line_chart_class();
?>	
	
	