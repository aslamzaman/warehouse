<?php
class product_sale_chart_class
{

	public function chartRow($company_id)
	{

		
		/* --- times of last 1 year ago  ---- */
		$first_dt = strtotime(date("Y-m-d"))-(365*86400);
		
		$x = "";
		$i = 1;
		$n = 0;
		while($i < 13)
		{
			/* --- 30 days increement  ---- */
			$n = $i * 30;
			
			/* --- after 30 days a new date  ---- */
			$new_dt1 = $first_dt + ($n * 86400);
			$new_dt2 = date("Y-m-d",$new_dt1);
			
		//echo $new_dt2."<br>";
			 $sale =  $this->product_out($company_id, $new_dt2);
			 
			 //[{v: [8, 0, 0], f: '8 am'}, 1],
			 
			$x = $x . "[{v: [". $i . ", 0, 0], f: 'Month-". $i ."'}, ". $sale."], ";
			$i++;
			
		}
		$y = substr($x,0,strlen($x)-2);
		echo $y;
		
	}
	
	
	


	public function product_out($company_id, $last_dt)
	{
		global $db;
	
		$first_dt = strtotime($last_dt)-(365*86400);
		$first_dt1 = date("Y-m-d",$first_dt);
		
		$sql = "SELECT `qty` * `sales_value` as total FROM product_out  WHERE `company_id`= $company_id AND `dt` BETWEEN '$first_dt1' AND '$last_dt'";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x = 0;
		if($Numrows > 0)
 	 	{
			$t = 0;
			while($rows= mysqli_fetch_array($result))
			{
				$t = $t + $rows['total'];
			}
			$x = $t;
		}
		else
		{
			$x = 0;	
		}
		return $x;
	}	
	

	
}
$product_sale_chart = new product_sale_chart_class();
?>	
	
	