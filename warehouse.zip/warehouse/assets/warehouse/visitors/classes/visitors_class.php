<?php
class visitors_class
{
	public function add_ip($company_id)
	{
		global $mysqldb;		
		$iip_address = $mysqldb->getUserIpAddr();
		$company_id = $company_id;
		$table = "`views`";
		$fields = "`ip_address`,   `company_id`";
		$vars = "'$iip_address',  $company_id";
		$ret = $mysqldb->add($table, $fields, $vars);
		return $ret;
	}
}
$visitors = new visitors_class();
?>	
	
	