<?php
session_start();
// add.php
date_default_timezone_set("Asia/Dhaka");
$title ="VAT & TAX";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	$ivat = $_POST['ivat'];
	$itax = $_POST['itax'];
	$icompany_id = $company_id;
	
	$table = "`vat_tax`";
	$fields = "`vat`,   `tax`, `company_id`";
	$vars = "$ivat, $itax, $icompany_id";

		$a = $mysqldb->add($table, $fields, $vars);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Saved Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Saving Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}
function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">VAT & TAX</h3>
 	</div>
 	<div class="col-sm-12 text-right">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="add.php" method="post">
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='ivat'>VAT(%):<small><span id='infovat' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='ivat' name='ivat' value='' placeholder='Enter VAT' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='itax'>TAX (%):<small><span id='infotax' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='itax' name='itax' value='' placeholder='Enter TAX' maxlength=100>
						</div>
					</div>

					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	// date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			if($('#ivat').val() == ''){$('#infovat').html(' ** Please write vat'); return false;};
			if($.isNumeric($('#ivat').val())==false){$('#infovat').html(' ** Please write vat in numeric'); return false;};
			if($('#itax').val() == ''){$('#infotax').html(' ** Please write tax'); return false;};
			if($.isNumeric($('#itax').val())==false){$('#infotax').html(' ** Please write tax in numeric'); return false;};
 	 	})
 	 	
 	 $('[data-toggle="tooltip"]').tooltip();	
 	 	
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
