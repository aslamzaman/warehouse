<?php
session_start();
// edit.php
date_default_timezone_set("Asia/Dhaka");
$title ="Money Receipt";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	$id = $_POST['id'];
	$ireceipt_no = $_POST['ireceipt_no'];
	$idt = $_POST['idt'];
	$icash_from = $_POST['icash_from'];
	$idescription = $_POST['idescription'];
	$iemployee_id = $_POST['iemployee_id'];
	$iamount = $_POST['iamount'];
	
	$table = "`money_receipt`";
	$field_vars = "`receipt_no` = $ireceipt_no, `dt` = '$idt', `cash_from` = '$icash_from', `description` = '$idescription', `employee_id` = $iemployee_id, `amount` = $iamount";
	$where = "`id` = $id";

		$a = $mysqldb->edit($table, $field_vars, $where);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Update Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Updating Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}

$id = $_GET['id'];
$table = "`money_receipt`";
$whereId = "`id` = $id";
$rows = $mysqldb->select_one_row($table, $whereId, $orderBy=false);

	

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Money Receipt</h3>
 	</div>
 	<div class="col-sm-12 text-right">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="edit.php" method="post">
			<INPUT type="hidden" class="form-control" id="id" name="id" value="<?php echo $id;?>">						
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idt'>Date:<small><span id='infodt' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idt' name='idt' value='<?php echo $rows['dt']; ?>' placeholder='Enter Date' maxlength=100>
						</div>
					</div>				
					<input type='hidden' class='form-control' id='ireceipt_no' name='ireceipt_no' value='<?php echo $rows['receipt_no']; ?>' placeholder='Enter Receipt No' maxlength=100>

					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icash_from'>To:<small><span id='infocash_from' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='icash_from' name='icash_from' value='<?php echo $rows['cash_from']; ?>' placeholder='Enter To' maxlength=100>
						</div>
					</div>

					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iamount'>Amount:<small><span id='infoamount' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iamount' name='iamount' value='<?php echo $rows['amount']; ?>' placeholder='Enter Amount' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icash_from'>Details:<small><span id='infocash_from' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idescription' name='idescription' value='<?php echo $rows['description']; ?>' placeholder='Details' maxlength=100>
						</div>
					</div>						
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iemployee_id'>Employee:<small><span id='infoemployee_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iemployee_id' name='iemployee_id'>
							<?php
								$table = "employee";
								$field1 = "id";
								$field2 = "name";
								$selectedId = $rows['employee_id'];
								$where = "`company_id`= $company_id";
								$orderBy = "`name` ASC";
								/* $limit = 5; */
								$mysqldb->drop_down($table, $field1, $field2, $selectedId, $where, $orderBy, $limit=false);							
							?>							
							</select>							
							
						</div>
					</div>
					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			
			if($('#ireceipt_no').val() == ''){$('#inforeceipt_no').html(' ** Please write receipt_no'); return false;};
			if($.isNumeric($('#ireceipt_no').val())==false){$('#inforeceipt_no').html(' ** Please write receipt_no in numeric'); return false;};
			if($('#idt').val() == ''){$('#infodt').html(' ** Please write dt'); return false;};
			if($('#icash_from').val() == ''){$('#infocash_from').html(' ** Please write cash_from'); return false;};
			if($('#iamount').val() == ''){$('#infoamount').html(' ** Please write amount'); return false;};
			if($.isNumeric($('#iamount').val())==false){$('#infoamount').html(' ** Please write amount in numeric'); return false;};
 	 	})
 	 	$('[data-toggle="tooltip"]').tooltip();
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
