<?php
session_start();
// date_picker.php
date_default_timezone_set("Asia/Dhaka");
$title = "Money Receipt";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$dt_before = $dateClass->dateadd(date("Y-m-d"),-180);

$id = $_GET['id'];
$table = "`money_receipt`";
$whereId = "`id` = $id";
$rows = $mysqldb->select_one_row($table, $whereId, $orderBy=false);


$comId = "";
$table = "`company`";
$whereId = "`company_id` = $company_id";
$com_name = $mysqldb->select_one_row($table, $whereId, $orderBy=false);
if($com_name['print_show'] > 0)
{
	
	$comId = "<h3 class='text-center'>".$com_name['name']."<br><span class='small'>".$com_name['address']."</span></h3><p class='text-center'>Mobile: ".$com_name['mobile']."</p>";
}
else
{
	$comId = "<h3 class='text-center'>&nbsp;<br><span class='small'>&nbsp;</span></h3><p class='text-center'>&nbsp;</p>";
}

function customPageHeader(){?>	
<style>
	@media print
	{
		#com_name{display: none;}
		#hide{display: none;}
		#add{display: none;}
		#close{display: none;}
		#print{display: none;}
		
		@page{margin-top:72px;}
		@page{margin-left:72px;}
		@page{margin-right:72px;}
		@page{margin-bottom:54px;}
		
		body{margin: 0px;}

		#tbl tbody td{border: 1px solid black;}
		#tbl thead th{border: 1px solid black;}
	}
</style>
<?php };?>
	

<div class="row" id="page">
	<div class="col-sm-12">
		<?php echo $comId;?>
 	</div> 
 	<div class="col-sm-6" id="display">
	
 	</div>	
 	<div class="col-sm-6 text-right" id="hide">
	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
  	 	<a href="JavaScript:window.print();" class="btn btn-default" id="hide" data-toggle='tooltip' data-placement='top' title='Print Preview'><span class='glyphicon glyphicon-print'></span></a>
	</div>
 	<div class="col-sm-offset-2 col-sm-8">
		<div class="panel panel-default">
			<div class="panel-heading">
				<div class="row">
					<div class="col-xs-8">
						<h3 class="text-center">Money Receipt</h3>
					</div>
					<div class="col-xs-4">
						<p class="text-left">Receipt Number:<strong> <i><?php echo $rows['receipt_no'];?></i></strong> <br>Date:--- <strong><i><?php echo $rows['dt'];?></i></strong> --- </p>
					</div>
				</div>	
			</div>		
			<div class="panel-body">
			
				<p class="text-left">
				Received from ------<strong><i><?php echo $rows['cash_from'];?></i></strong>------ the amount of tk. <strong><i>------<?php echo $rows['amount'];?></i></strong>------
				</p>
				<p class="text-left">
					for ------ <strong><i><?php echo $rows['description'];?></i></strong>------
				</p>				
				<p class="text-left"><strong>
					<i><?php 
					$x = $rows['amount'];
					echo $inword->number($x);
				?>
				------ </i></strong>
				<br><br>
				</p>				
				<div class="row">
					<div class="col-xs-8">
						<p class="text-left">
							&#10004; Cash<br>&#10005; Cheque<br>&#10005; Money Order
						</p>
					</div>
					<div class="col-xs-4">
						<p class="text-left">
						</p>
					</div>
				</div>				
				
				<br>
				<p class="text-right">
				Received by <strong><i><?php 
				
					$table = "employee";
					$whereId = "`id` = ".$rows['employee_id'];
					$orderBy = "`name` ASC";
					$p= $mysqldb->select_one_row($table, $whereId, $orderBy);
					echo $p['name'];	
				?>
				</i></strong></p><br><br><br><br><br><br>			
			</div>
		</div>
 	</div>
</div>
<script>
 	$(document).ready(function(){
 	 	date_picker('dt1');
 	 	date_picker('dt2');
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>
  
  
