<?php
session_start();
// add.php
date_default_timezone_set("Asia/Dhaka");
$title ="Money Receipt";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	$ireceipt_no = $_POST['ireceipt_no'];
	$idt = $_POST['idt'];
	$icash_from = $_POST['icash_from'];
	$idescription = $_POST['idescription'];
	$iemployee_id = $_POST['iemployee_id'];
	$iamount = $_POST['iamount'];
	$icompany_id = $company_id;
	
	$table = "`money_receipt`";
	$fields = "`receipt_no`,   `dt`,   `cash_from`, `description`,  `employee_id`,   `amount`,   `company_id`";
	$vars = "$ireceipt_no, '$idt', '$icash_from',  '$idescription', $iemployee_id, $iamount, $icompany_id";

		$a = $mysqldb->add($table, $fields, $vars);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Saved Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Saving Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}
function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Money Receipt</h3>
 	</div>
 	<div class="col-sm-12 text-right">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="add.php" method="post">
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idt'>Date:<small><span id='infodt' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idt' name='idt' value='' placeholder='Enter Date' maxlength=100>
						</div>
					</div>				
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='ireceipt_no'>Receipt No:<small><span id='inforeceipt_no' class='text-warning'></span></small></label>
							<?php
								$table = "money_receipt";
								$field = "receipt_no";
								$startCode = 10001;
								$whereId = "`company_id` = $company_id";
								$code = $mysqldb->code_increment($table, $field, $startCode, $whereId);	
							?>
							
							<input type='text' class='form-control' id='ireceipt_no' name='ireceipt_no' value='<?php echo $code;?>' placeholder='Enter Receipt No' maxlength=100 readonly>
						</div>
					</div>

					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icash_from'>To:<small><span id='infocash_from' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='icash_from' name='icash_from' value='' placeholder='To' maxlength=100>
						</div>
					</div>
					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iamount'>Amount:<small><span id='infoamount' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iamount' name='iamount' value='' placeholder='Enter Amount' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icash_from'>Details:<small><span id='infocash_from' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idescription' name='idescription' value='' placeholder='Details' maxlength=100>
						</div>
					</div>					
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iemployee_id'>Employee:<small><span id='infoemployee_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iemployee_id' name='iemployee_id'>
							<?php
								$table = "employee";
								$field1 = "id";
								$field2 = "name";
								$selectedId = 1;
								$where = "`company_id`= $company_id";
								$orderBy = "`name` ASC";
								/* $limit = 5; */
								$mysqldb->drop_down($table, $field1, $field2, $selectedId, $where, $orderBy, $limit=false);							
							?>							
							</select>						
						</div>
					</div>
					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			
			if($('#ireceipt_no').val() == ''){$('#inforeceipt_no').html(' ** Please write receipt_no'); return false;};
			if($.isNumeric($('#ireceipt_no').val())==false){$('#inforeceipt_no').html(' ** Please write receipt_no in numeric'); return false;};
			if($('#idt').val() == ''){$('#infodt').html(' ** Please write dt'); return false;};
			if($('#icash_from').val() == ''){$('#infocash_from').html(' ** Please write cash_from'); return false;};
			if($('#iamount').val() == ''){$('#infoamount').html(' ** Please write amount'); return false;};
			if($.isNumeric($('#iamount').val())==false){$('#infoamount').html(' ** Please write amount in numeric'); return false;};
 	 		if($('#iemployee_id').val() == null){$('#infoemployee_id').html(' ** Please select employee'); return false;};
		})
 	 	
 	 $('[data-toggle="tooltip"]').tooltip();	
 	 	
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
