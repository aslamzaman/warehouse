<?php
class cheque_balance_class
{

	public function balcne_create($company_id,$d1,$d2,$id)
	{
		global $db;
		global $mysqldb;
		$this->tbl_create($company_id,$d1,$d2,$id);
		
		$table = "`cash_balance`";
		$orderBy ="`dt` ASC";
		
		$p = $mysqldb->select_all_row($table, $where=false, $orderBy, $limit=false);
		if(count($p) > 0) 
		{
			$b = $this->previous_balance($company_id,$d1,$d2,$id);
			echo "<tr>\n";
			echo "<td>Previous Balance</td>\n";			
			echo "<td></td>\n";
			echo "<td></td>\n";
			echo "<td class='text-right'>$b</td>\n";
			echo "<tr>\n";			
			foreach ($p as $q)
			{
				$b = $b + $q['c_in'] - $q['c_out'];
				echo "<tr>\n";
				echo "<td>".$q['dt']."</td>\n";			
				echo "<td class='text-right'>".$q['c_in']."</td>\n";
				echo "<td class='text-right'>".$q['c_out']."</td>\n";				
				echo "<td class='text-right'>$b</td>\n";
				echo "<tr>\n";				
			}
		}
		
	}




//=============================================================
	public function tbl_create($company_id,$d1,$d2,$id)
	{
		global $db;
		global $mysqldb;
		$sql_create = "CREATE TEMPORARY TABLE `cash_balance`(
		`dt` date NOT NULL,
		`c_in` double(15,2) NOT NULL,
		`c_out` double(15,2) NOT NULL
		) ENGINE=MyISAM DEFAULT CHARSET=latin1";
		mysqli_query($db, $sql_create);
		
		
		$table = "`cheque_in`";
		$where = "`bank_account_id` = $id  AND `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);

		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				$table = "`cash_balance`";
				$fields = "`dt`,   `c_in`,   `c_out`";
				$vars = "'". $q['dt']."', ". $q['amount'].", 0";
				$mysqldb->add($table, $fields, $vars);
			}
		}
		
		$table = "`cheque_out`";
		$where = "`bank_account_id` = $id  AND `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
				
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				$table = "`cash_balance`";
				$fields = "`dt`,   `c_in`,   `c_out`";
				$vars = "'". $q['dt']."', 0,". $q['amount'];
				$mysqldb->add($table, $fields, $vars);
			}
		}		
			
	}	
//============================================================
	public function previous_balance($company_id,$d1,$d2,$id)
	{
		global $db;
		global $mysqldb;
		
		$pdt = date("Y-m-d",(strtotime($d1) - 86400));
		$table = "`cheque_in`";
		$field = "amount";
		$where = "`bank_account_id` = $id  AND `company_id`= $company_id AND `dt` BETWEEN '1970-01-01' AND '$pdt'";		
		$cas_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */
		$table = "`cheque_out`";
		$field = "amount";
		$where = "`bank_account_id` = $id  AND `company_id`= $company_id AND `dt` BETWEEN '1970-01-01' AND '$pdt'";		
		$cas_out = $mysqldb->total_amount($table, $field, $where, $limit=false);		
		$balance = ($cas_in - $cas_out);

		
		return $balance; 
	}
	
}
$cheque_balance = new cheque_balance_class();
?>	
	
	