<?php
class default_values_class
{
	public function chart_of_account($company_id)
	{
		global $mysqldb;

		$table = "account_chart";
		$where = "`company_id`= $company_id";	
		$row = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);		
		if(count($row) < 1)
		{
			$to_table = "account_chart";	
			$from_table = "account_chart_x";
			$to_fields = "`name`, `account_type_id`, `description`, `company_id`";
			$from_fields = "`name`, `account_type_id`, `description`, $company_id";
			$ret = $mysqldb->add_from_another($to_table, $from_table, $to_fields, $from_fields, $from_where=false);			
			return $ret;		
		}
		
	}
	
}
$default_values = new default_values_class();
?>	
	
	