<?php
session_start();
// add.php
date_default_timezone_set("Asia/Dhaka");
$title ="Employee Information";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	$iname = $_POST['iname'];
	$iaddress = $_POST['iaddress'];
	$ibirth_dt = $_POST['ibirth_dt'];
	$isalary = $_POST['isalary'];
	$ijoin_dt = $_POST['ijoin_dt'];
	$icompany_id = $company_id;
	
	$table = "`employee`";
	$fields = "`name`,   `address`,   `birth_dt`,   `salary`,   `join_dt`,   `company_id`";
	$vars = "'$iname', '$iaddress', '$ibirth_dt', $isalary, '$ijoin_dt',     $icompany_id";

		$a = $mysqldb->add($table, $fields, $vars);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Saved Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Saving Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}
function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Employee Information</h3>
 	</div>
 	<div class="col-sm-12 text-right">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="add.php" method="post">
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iname'>Name:<small><span id='infoname' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iname' name='iname' value='' placeholder='Enter Name' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iaddress'>Address:<small><span id='infoaddress' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iaddress' name='iaddress' value='' placeholder='Enter Address' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='ibirth_dt'>Birth Date:<small><span id='infobirth_dt' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='ibirth_dt' name='ibirth_dt' value='' placeholder='Enter Birth Date' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='isalary'>Salary:<small><span id='infosalary' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='isalary' name='isalary' value='' placeholder='Enter Salary' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='ijoin_dt'>Joining Date:<small><span id='infojoin_dt' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='ijoin_dt' name='ijoin_dt' value='' placeholder='Enter Join_dt' maxlength=100>
						</div>
					</div>

					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	date_picker('ibirth_dt');
	date_picker('ijoin_dt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			if($('#iname').val() == ''){$('#infoname').html(' ** Please write name'); return false;};
			if($('#iaddress').val() == ''){$('#infoaddress').html(' ** Please write address'); return false;};
			if($('#ibirth_dt').val() == ''){$('#infobirth_dt').html(' ** Please write birth_dt'); return false;};
			if($('#isalary').val() == ''){$('#infosalary').html(' ** Please write salary'); return false;};
			if($.isNumeric($('#isalary').val())==false){$('#infosalary').html(' ** Please write salary in numeric'); return false;};
			if($('#ijoin_dt').val() == ''){$('#infojoin_dt').html(' ** Please write join_dt'); return false;};
 	 	})
 	 	$('[data-toggle="tooltip"]').tooltip();
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
