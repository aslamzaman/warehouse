<?php
session_start();
// add.php
date_default_timezone_set("Asia/Dhaka");
$title ="Bill/Invoice";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	$idt = $_POST['idt'];
	$icustomer_id = $_POST['icustomer_id'];
	$iproduct_id = $_POST['iproduct_id'];
	$iqty = $_POST['iqty'];
	$irate = $_POST['irate'];
	$icompany_id = $company_id;
	
	$table = "`bills_raw`";
	$fields = "`dt`,   `customer_id`,   `product_id`,   `qty`,   `rate`,   `company_id`";
	$vars = "'$idt',   $icustomer_id,   $iproduct_id,   $iqty,   $irate,   $icompany_id";

		$a = $mysqldb->add($table, $fields, $vars);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Saved Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Saving Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}
function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Bill/Invoice</h3>
 	</div>
 	<div class="col-sm-12 text-right">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="add.php" method="post">
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idt'>Date:<small><span id='infodt' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idt' name='idt' value='<?php echo date("Y-m-d");?>' placeholder='Enter Date' maxlength=10>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icustomer_id'>Customer Name:<small><span id='infocustomer_id' class='text-warning'></span></small></label>
							<select class='form-control' id='icustomer_id' name='icustomer_id'>
								<?php
									$mysqldb->drop_down("customer","id", "name",1,"`company_id`= $company_id", "name ASC", $limit=false);
								?>
							</select>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iproduct_id'>Product Name:<small><span id='infoproduct_id' class='text-warning'></span></small></label>
							<select class='form-control' id='iproduct_id' name='iproduct_id'>
								<?php
									$mysqldb->drop_down("product","id", "name",1,"`company_id`= $company_id", "name ASC", $limit=false);
								?>
							</select>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iqty'>Quantity:<small><span id='infoqty' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iqty' name='iqty' value='' placeholder='Enter Quantity' maxlength=8>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='irate'>Rate:<small><span id='inforate' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='irate' name='irate' value='' placeholder='Enter Rate' maxlength=8>
						</div>
					</div>
					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			
			if($('#idt').val() == ''){$('#infodt').html(' ** Please write dt'); return false;};
			if($('#icustomer_id').val() == null){$('#infocustomer_id').html(' ** Please select customer'); return false;};
			if($('#iproduct_id').val() == null){$('#infoproduct_id').html(' ** Please select customer'); return false;};
			
			if($('#iqty').val() == ''){$('#infoqty').html(' ** Please write qty'); return false;};
			if($.isNumeric($('#iqty').val())==false){$('#infoqty').html(' ** Please write qty in numeric'); return false;};
			if($('#irate').val() == ''){$('#inforate').html(' ** Please write rate'); return false;};
			if($.isNumeric($('#irate').val())==false){$('#inforate').html(' ** Please write rate in numeric'); return false;};
 	 	})
 	 	
 	 $('[data-toggle="tooltip"]').tooltip();	
 	 	
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
