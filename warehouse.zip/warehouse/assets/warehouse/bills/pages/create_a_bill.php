<?php
session_start();
date_default_timezone_set("Asia/Dhaka");
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];

$bills =  $_POST['bills'];
$ibills_no =  $mysqldb->code_increment("`bills_final`", "bill_no", 10001, "`company_id`= $company_id");	
	
	$i = 0;
	while($i < count($bills))
	{
		$to_table = "bills_final";	
		$from_table = "bills_raw";
		$to_fields = "`bills_raw_id`, `bill_no`, `dt`, `customer_id`, `product_id`, `qty`, `rate`, `company_id`";
		$from_fields =  $bills[$i].",$ibills_no, `dt`, `customer_id`, `product_id`, `qty`, `rate`, `company_id`";
		$from_where = "`id`= ".$bills[$i];
		$ret=$mysqldb->add_from_another($to_table, $from_table, $to_fields, $from_fields, $from_where);		

		$i++;
	}
	
	if($ret)
	{
		$_SESSION["msg"] = "Bill Created Successfully";
	}
	else
	{
		$_SESSION["msg"] = "Bill Creating Error!.";
	}
	
  echo "<script>window.location.href='index.php';</script>";
?>






	
