<?php
session_start();
// index.php
date_default_timezone_set("Asia/Dhaka");
$title ="Bill/Invoice";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_GET['id']))
{
	$table = "bills_final";
	$where = "`bill_no` = ".$_GET['id']." AND `company_id`= $company_id";
	
		$a = $mysqldb->remove($table, $where);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Deleted Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Deleting Error!";
 	 	}
	echo "<script>window.location.href='index.php';</script>";	
}
function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Bill/Invoice</h3>
 	</div>
 	<div class="col-sm-6" id="display">
		<?php
 	 	 	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
 	 	 	 	echo $_SESSION['msg'];
 	 	 	 	unset($_SESSION['msg']);
 	 	 	}
 	 	?>
 	</div>	
 	<div class="col-sm-6 text-right">
 	    <div class="btn-group btn-group-sm" id="hide">
			<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span> Close</a>
 	    </div>
 	</div>
 	<div class="col-sm-12">
 	 	<table class="table table-striped">
 	 	 	<thead>
 	 	 	 	<tr>
					<th>Date</th>
					<th>Bill No</th>
					<th>Customer</th>
					<th class='text-right'>Amount</th>
				    <th></th>
				</tr>
 	 	 	</thead>
 	 	 	<tbody>
 	 	 	<?php

	$table = "bills_final";
	$fields = "`dt`, `bill_no`, `customer_id`, sum(`qty`*`rate`) as `total`";
	$group_field = "`bill_no`";
	$where = "`company_id`= $company_id";	
	$orderBy = "`bill_no` DESC";
	$limit = false;
	$row =$mysqldb->select_group_by_row($table, $fields, $group_field, $where, $orderBy, $limit);
				
				
				
				if(count($row) > 0)
 	 	 	 	{
 	 	 	 	 	foreach($row as $rows)
 	 	 	 	 	{	
						echo "<tr>";
						echo "<td>".$rows['dt']."</td>";
						echo "<td>".$rows['bill_no']."</td>";
						$customer = $mysqldb->name_by_id("customer","name","id",$rows['customer_id']);	
						echo "<td>$customer</td>";
						echo "<td class='text-right'>".$rows['total']."</td>";
						echo "<td class='text-right'>";
						echo "<div class='btn-group btn-group-xs' id='hide'>";						
						echo "<a href='#' class='btn btn-default' id='".$rows['bill_no']."' onclick='deletefunction(this.id)' data-toggle='tooltip' data-placement='top' title='Delete'><span class='glyphicon glyphicon-remove'></span></a>";
						echo "<a href='bill_for_print.php?id=".$rows['bill_no']."' class='btn btn-default' data-toggle='tooltip' data-placement='top' title='Bill Preview'><span class='glyphicon glyphicon-print'></span> Preview</a>";
						echo "</div>";
						echo "</td>";
						echo "</tr>";
		 	 	 	}
 	 	 	 	}
 	 	 	?>
 	 	 	</tbody>
 	 	</table>
 	</div>
</div>	
<script>
 	function deletefunction(id){
 	 	if (confirm("Are u sure?") == true){
 	 	 	window.location.href="show_bills.php?id=" + id;
 	 	}
 	}
 	
 	$('[data-toggle="tooltip"]').tooltip();
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
