<?php
session_start();
// index.php
date_default_timezone_set("Asia/Dhaka");
$title ="Bill/Invoice";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];

$billNo= $_GET['id'];

$comId = "";
$table = "`company`";
$whereId = "`company_id` = $company_id";
$com_name = $mysqldb->select_one_row($table, $whereId, $orderBy=false);
if($com_name['print_show'] > 0)
{
	
	$comId = "<h3 class='text-center'>".$com_name['name']."<br><span class='small'>".$com_name['address']."</span></h3><p class='text-center'>Mobile: ".$com_name['mobile']."</p>";
}
else
{
	$comId = "<h3 class='text-center'>&nbsp;<br><span class='small'>&nbsp;</span></h3><p class='text-center'>&nbsp;</p>";
}

function customPageHeader(){?>	
<style>
	@media print
	{
		#com_name{display: none;}
		#hide{display: none;}
		#add{display: none;}
		#close{display: none;}
		#print{display: none;}
		
		@page{margin-top:72px;}
		@page{margin-left:72px;}
		@page{margin-right:72px;}
		@page{margin-bottom:54px;}
		
		body{margin: 0px;}

		#tbl tbody td{border: 1px solid black;}
		#tbl thead th{border: 1px solid black;}
	}
</style>
<?php };?>
	

<div class="row" id="page">
	<div class="col-sm-12">
		<?php echo $comId;?>
 	</div> 
	<div class="col-sm-12">
		<h3 class="text-primary text-center"><u>BILL/INVOICE</u></h3>
 	</div>
 	<div class="col-sm-6" id="display">
	
 	</div>	
 	<div class="col-sm-6 text-right" id="hide">
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
  	 	<a href="JavaScript:window.print();" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Print Preview'><span class='glyphicon glyphicon-print'></span></a>
	
	</div>
 	<div class="col-sm-12">
		<table class="table table-striped" id="tb2">
			<tbody>
				<tr>
					<td>
					<?php
					
						$table = "bills_final";
						$where = "`bill_no`= ".$billNo ."  AND `company_id`= $company_id";
						$orderBy = "`dt` ASC";
						$p = $mysqldb->select_one_row($table, $where, $orderBy, $orderBy=false);					
					//----------------------------------------------------------------
						$table = "customer";
						$where = "`id`= ".$p['customer_id'];
						$orderBy = false;
						$c = $mysqldb->select_one_row($table, $where, $orderBy,$orderBy=false);
						echo "<strong>To: " .$c['name']."</strong>";
						$dist = $mysqldb->name_by_id("districts","name","id",$c['district_id']);
						$desh = $mysqldb->name_by_id("countries","name","id",$c['country_id']);
						echo "<p>" .$c['address']."<br>$dist, $desh<br>".$c['mobile']."</p>";
					?>
					</td>
					<td style="text-align:right;">
					<?php
						echo "<strong>Bill No: " .$billNo."</strong><br>"."Date : " .$p['dt'];
					?>
					</td>
				</tr>
			</tbody>
		</table>
 	 	<table class="table table-striped" id="tbl">
 	 	 	<thead>
 	 	 	 	<tr>
					<th>ITEM</th>
					<th class='text-right'>QUANTITY</th>
					<th class='text-right'>RATE</th>					
					<th class='text-right'>TOTAL</th>
				</tr>
 	 	 	</thead>
 	 	 	<tbody>
				<?php
					
					$table = "bills_final";
					$where = "`bill_no`= ".$billNo ."  AND `company_id`= $company_id";
					$orderBy = "`dt` ASC";
					$limit = false;
					$row = $mysqldb->select_all_row($table, $where, $orderBy, $limit=false);

					if(count($row) > 0)
					{

						$to_value=0;
						foreach($row as $rows)
						{	
							echo "<tr>";
							$item = $mysqldb->name_by_id("product","name","id",$rows['product_id']);	
							echo "<td>$item</td>";
							echo "<td class='text-right'>".$rows['qty']."</td>";
							echo "<td class='text-right'>".$rows['rate']."</td>";
							$s_total = $rows['qty'] * $rows['rate'];
							echo "<td class='text-right'>".number_format($s_total,0)."</td>";							
							echo "</tr>";
							$to_value= $to_value + $s_total;
						}
						
					}
					echo "<tr>";
					echo "<td colspan=3><strong>Total</strong></td>";
					echo "<td class='text-right'><strong>".number_format($to_value,0)."</strong></td>";
					echo "</tr>";
					
				?>
				
 	 	 	</tbody>
 	 	</table>
 	</div>
 	<div class="col-sm-12">
		<p><?php echo $inword->number($to_value);?></p>
	</div>	

	
</div>	
<script>
 	$(document).ready(function(){
 	    $('[data-toggle="tooltip"]').tooltip();
 	})
	
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
