<?php
session_start();
// index.php
date_default_timezone_set("Asia/Dhaka");
$title ="Bill/Invoice";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_GET['id']))
{
	$table = "`bills_raw`";
	$where = "`id` = ".$_GET['id'];
	
		$a = $mysqldb->remove($table, $where);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Deleted Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Deleting Error!";
 	 	}
}

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Bill/Invoice</h3>
 	</div>
 	<div class="col-sm-6" id="display">
		<?php
 	 	 	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
 	 	 	 	echo $_SESSION['msg'];
 	 	 	 	unset($_SESSION['msg']);
 	 	 	}
 	 	?>
 	</div>	
 	<div class="col-sm-6 text-right">
 	    <div class="btn-group btn-group-sm" id="hide">
		    <a href="add.php" class="btn btn-default" id="add" data-toggle='tooltip' data-placement='top' title='Add New'><span class='glyphicon glyphicon-plus'></span> Add New</a>
		    <a href="#" class="btn btn-default" onclick="create_bill()" data-toggle='tooltip' data-placement='top' title='Create a bill'><span class='glyphicon glyphicon-share-alt'></span> Create a bill</a> 	    
			<a href="show_bills.php" class="btn btn-default" id="reports" data-toggle='tooltip' data-placement='top' title='Show bills'><span class='glyphicon glyphicon-calendar'></span> Show bills</a>
	   </div>
 	</div>
 	<div class="col-sm-12">
 	    <div class="table-responsive">
			<form class="form-horizontal" id="gotoBills" role="form" action="create_a_bill.php" method="post">
				<table class="table table-striped">
					<thead>
						<tr>
							<th></th>
							<th>Date</th>
							<th>Customer</th>
							<th>Item</th>
							<th class='text-right'>Value</th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php
						$table = "`bills_raw`";
						$where = "`company_id`= $company_id AND `id` NOT IN(SELECT `bills_raw_id` FROM `bills_final` WHERE `company_id`= $company_id)";
						$orderBy = "`id` DESC";
						$limit = 50;
						$row = $mysqldb->select_all_row($table, $where, $orderBy, $limit);
						if(count($row) > 0)
						{
							foreach($row as $rows)
							{	
								echo "<tr>";
								echo "<td><input type='checkbox' name='bills[]' value='".$rows['id']."'></td>\n";
								echo "<td>".$rows['dt']."</td>";
								$customer= $mysqldb->name_by_id("customer","name","id",$rows['customer_id']);
								echo "<td>$customer</td>";
								$product= $mysqldb->name_by_id("product","name","id",$rows['product_id']);
								echo "<td>$product</td>";
								$total = $rows['qty'] * $rows['rate'];
								echo "<td class='text-right'>$total</td>";
								echo "<td class='text-right'>";
								echo "<div class='btn-group btn-group-xs' id='hide'>";
								echo "<a href='edit.php?id=".$rows['id']."' class='btn btn-default' data-toggle='tooltip' data-placement='top' title='Edit'><span class='glyphicon glyphicon-edit'></span></a>";
								echo "<a href='#' class='btn btn-default' id='".$rows['id']."' onclick='deletefunction(this.id)' data-toggle='tooltip' data-placement='top' title='Delete'><span class='glyphicon glyphicon-remove'></span></a>";
								echo "</div>";
								echo "</td>";
								echo "</tr>";	
							}
						}
						?>
					</tbody>
				</table>
			</form>	
 	 	</div>
 	</div>
</div>	
<script>
 	function deletefunction(id){
 	 	if (confirm("Are u sure?") == true){
 	 	 	window.location.href="index.php?id=" + id;
 	 	}
 	}
 	
 	$('[data-toggle="tooltip"]').tooltip();
	
</script>
<script>
		function create_bill()
		{
			check=false;
			var aCheckbox = document.getElementById('gotoBills').elements;
			for(i=0;i<aCheckbox.length;++i)
			{
				if(aCheckbox[i].type=='checkbox' && aCheckbox[i].checked)
				{
					check=true;
				}
			}
			 
			 
			if(check==true)
			{
				 document.getElementById("gotoBills").submit();
			}
			else
			{
				alert("you haven't selected any of the checkboxex");
				return false;
			}

		}

</script>


<?php include "../../layout/footer/footer.php"; ?>






	
