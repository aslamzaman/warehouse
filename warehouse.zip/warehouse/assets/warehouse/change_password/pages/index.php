<?php
session_start();
// edit.php
date_default_timezone_set("Asia/Dhaka");
$title ="Change Password";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_POST['submit']))
{
	$ipw = $_POST['ipw'];
	$inpw = $_POST['inpw'];
	
	$m = $mysqldb->select_one_row("pw", "id = $pw_id", $orderBy=false);
	if($ipw == $m['pw'])
	{
		
		$table = "`pw`";
		$field_vars = " `pw` = '$inpw'";
		$where = "`id` = $pw_id";

			$a = $mysqldb->edit($table, $field_vars, $where);
			if($a)
			{
				$_SESSION["msg"] = "Update Successfully";
			}
			else
			{
				$_SESSION["msg"] = "Updating Error!.";
			}
		
	}
	else
	{
		$_SESSION["msg"] = "Old password do not match !<br>Please try again.";
	}
}

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Change Password</h3>
 	</div>
	 <div class="col-sm-12 text-warning" id="display">
		<?php
 	 	 	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
 	 	 	 	echo $_SESSION['msg'];
 	 	 	 	unset($_SESSION['msg']);
 	 	 	}
 	 	?>
 	 	<br><br>
 	</div>
 	<div class="col-sm-12 text-right">
 	</div>
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="index.php" method="post">
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='ipw'>Old Password:<small><span id='infopw' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='ipw' name='ipw' value='' placeholder='Enter Old Password' maxlength=30>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='inpw'>New Password:<small><span id='infonpw' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='inpw' name='inpw' value='' placeholder='Enter New Password' maxlength=30>
						</div>
					</div>	
					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	// date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			
			if($('#iuser').val() == ''){$('#infouser').html(' ** Please write user name'); return false;};
			if($('#ipw').val() == ''){$('#infopw').html(' ** Please write old password'); return false;};
			if($('#inpw').val() == ''){$('#infonpw').html(' ** Please write new password'); return false;};
		})
 	 	$('[data-toggle="tooltip"]').tooltip();
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
