<?php
class stock_balance_class
{

	public function balcne_create($company_id,$d1,$d2,$id)
	{
		global $db;
		global $mysqldb;
		$this->tbl_create($company_id,$d1,$d2,$id);
		$table = "`temp_table`";
		$orderBy ="`dt` ASC";
		$p = $mysqldb->select_all_row($table, $where=false, $orderBy, $limit=false);
		if(count($p) > 0) 
		{
			$b = $this->previous_balance($company_id,$d1,$id);
			echo "<tr>\n";
			echo "<td>$d1</td>\n";	
			echo "<td colspan='3'>Previous Balance</td>\n";
			echo "<td class='text-right'>$b</td>\n";
			echo "<tr>\n";			
			foreach ($p as $q)
			{
				$b = $b + $q['p_in'] - $q['p_out'];
				echo "<tr>\n";
				echo "<td>".$q['dt']."</td>\n";	
				echo "<td>".$q['name']."</td>\n";
				if($q['p_in'] > 0)
				{
					echo "<td class='text-right'>".$q['p_in']."</td>\n";
				}
				else
				{
					echo "<td class='text-right'>-</td>\n";
				}
				
				if($q['p_out'] > 0)
				{
					echo "<td class='text-right'>".$q['p_out']."</td>\n";
				}
				else
				{
					echo "<td class='text-right'>-</td>\n";
				}				
				
				echo "<td class='text-right'>$b</td>\n";
				echo "<tr>\n";				
			}
		}
		
	}




//=============================================================
	public function tbl_create($company_id,$d1,$d2, $id)
	{
		global $db;
		global $mysqldb;
		global $name_by_id_from_source;
		
		$sql_create = "CREATE TEMPORARY TABLE `temp_table`(
		`dt` date NOT NULL,
		`name` varchar(50) NOT NULL,
		`p_in` double(15,2) NOT NULL,
		`p_out` double(15,2) NOT NULL
		) ENGINE=MyISAM DEFAULT CHARSET=latin1";
		mysqli_query($db, $sql_create);
		
		
		$table = "`product_in`";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2' AND `product_id` = $id";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);

		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				$a = $name_by_id_from_source->get($company_id,$q['cash_source_id'],$q['account_chart_id']);
				$nm = "From: $a";
				
				$table = "`temp_table`";
				$fields =          "`dt`,  `name`,         `p_in`,`p_out`";
				$vars = "'". $q['dt']."',   '$nm', ". $q['qty'].", 0";
				$mysqldb->add($table, $fields, $vars);
			}
		}
		
		$table = "`product_out`";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2' AND `product_id` = $id";
		$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{	 	
				$a = $name_by_id_from_source->get($company_id,$q['cash_source_id'],$q['account_chart_id']);
				$nm = "To: $a";
				
				$table = "`temp_table`";
				$fields =          "`dt`,  `name`,`p_in`,`p_out`";
				$vars = "'". $q['dt']."',   '$nm',     0,". $q['qty'];
				$mysqldb->add($table, $fields, $vars);
			}
		}		
			
	}	
//============================================================
	public function previous_balance($company_id,$d1,$id)
	{
		global $balance;
		$pd = date("Y-m-d",(strtotime($d1) - 86400));
		$x = $balance->procuct_by_id($company_id,"1970-01-01",$pd,$id); 
		return $x; 
	
	}


	
}
$stock_balance = new stock_balance_class();
?>	
	
	