<?php
class account_chart_information_class
{
	public function balcne_create($company_id,$d1,$d2)
	{
		global $db;
		global $mysqldb;
		
		$this->tbl_create($company_id);		
		$p = $mysqldb->select_all_row("`temp_table`", "`dt` BETWEEN '$d1' AND '$d2'", "`dt` ASC", $limit=false);
		$b=0;	
		if(count($p) > 0) 
		{
			
			$b = $this->previous_expance($company_id,$d1);;
			echo "<tr>\n";
			echo "<td>$d1</td>\n";	
			echo "<td colspan=3>Bring Forword</td>\n";			
			echo "<td class='text-right'>$b</td>\n";
			echo "</tr>\n";	
			
			foreach ($p as $q)
			{
					
					$b = $b + $q['c_in'] - $q['c_out'];
					echo "<tr>\n";
					echo "<td>".$q['dt']."</td>\n";	
					echo "<td>".$q['name']."</td>\n";
					if($q['c_in'] > 0)
					{
						echo "<td class='text-right'>".number_format($q['c_in'],2)."</td>\n";
					}
					else
					{
						echo "<td class='text-right'>-</td>\n";
					}
					
					
					if($q['c_out'] > 0)
					{
					echo "<td class='text-right'>".number_format($q['c_out'],2)."</td>\n";
					}
					else
					{
						echo "<td class='text-right'>-</td>\n";
					}	
					echo "<td class='text-right'>$b</td>\n";
					echo "</tr>\n";						
			}
		}
	}




//=============================================================
	public function tbl_create($company_id)
	{
		global $db;
		global $mysqldb;
		global $name_by_id_from_source;
		$sql_create = "CREATE TEMPORARY TABLE `temp_table`(
		`dt` date NOT NULL,
		`id` int(5) NOT NULL,
		`name` varchar(50) NOT NULL,
		`c_in` double(15,2) NOT NULL,
		`c_out` double(15,2) NOT NULL
		) ENGINE=MyISAM DEFAULT CHARSET=latin1";
		mysqli_query($db, $sql_create);
		
		
		$row = $mysqldb->select_all_row("account_chart","`company_id`= $company_id AND `account_type_id` = 2", $orderBy=false, $limit=false);
		if(count($row) > 0) 
		{
			foreach ($row as $rows)
			{		
				$table = "`cash_out`";
				$where = "`company_id`= $company_id AND `account_chart_id` = ".$rows['id']." AND `cash_source_id` = 3";
				$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);

				if(count($p) > 0) 
				{
					foreach ($p as $q)
					{	 	
						$nm = $name_by_id_from_source->get($company_id,$q['cash_source_id'],$q['account_chart_id']);
						$table = "`temp_table`";
						$fields =          "`dt`,            `id`, `name`, `c_in`, `c_out`";
						$vars = "'". $q['dt']."', ".$rows['id'].",  '$nm -By Cash',          0 ,". $q['amount'];
						$mysqldb->add($table, $fields, $vars);
					}
				}
				
				$table = "`cheque_out`";
				$where = "`company_id`= $company_id AND `account_chart_id` = ".$rows['id']." AND `cash_source_id` = 3";
				$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
				if(count($p) > 0) 
				{
					foreach ($p as $q)
					{	 	
						$nm = $name_by_id_from_source->get($company_id,$q['cash_source_id'],$q['account_chart_id']);
						$nm1 = "(".$q['cheque_no'].", ".$q['cheque_dt'].")";
						$nm2 = "$nm -By Cheque $nm1";						
						$table = "`temp_table`";
						$fields =          "`dt`,            `id`,`name`, `c_in`, `c_out`";
						$vars = "'". $q['dt']."', ".$rows['id'].", '$nm2',          0 ,". $q['amount'];
						$mysqldb->add($table, $fields, $vars);
					}
				}
			
			//-------------------------------------------------------------
			
				$table = "`cash_in`";
				$where = "`company_id`= $company_id AND `account_chart_id` = ".$rows['id']." AND `cash_source_id` = 3";
				$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);

				if(count($p) > 0) 
				{
					foreach ($p as $q)
					{	 	
						$nm = $name_by_id_from_source->get($company_id,$q['cash_source_id'],$q['account_chart_id']);
						$table = "`temp_table`";
						$fields =          "`dt`,            `id`, `name`,      `c_in`, `c_out`";
						$vars = "'". $q['dt']."', ".$rows['id'].",  '$nm -To Cash',". $q['amount'].",            0";
						$mysqldb->add($table, $fields, $vars);
					}
				}
				
				$table = "`cheque_in`";
				$where = "`company_id`= $company_id AND `account_chart_id` = ".$rows['id']." AND `cash_source_id` = 3";
				$p = $mysqldb->select_all_row($table, $where, $orderBy=false, $limit=false);
				if(count($p) > 0) 
				{
					foreach ($p as $q)
					{	 	
						$nm = $name_by_id_from_source->get($company_id,$q['cash_source_id'],$q['account_chart_id']);
						$nm1 = "(".$q['cheque_no'].", ".$q['cheque_dt'].")";
						$nm2 = "$nm -To Cheque $nm1";							
						$table = "`temp_table`";
						$fields =          "`dt`,            `id`,`name`,      `c_in`, `c_out`";
						$vars = "'". $q['dt']."', ".$rows['id'].", '$nm2',". $q['amount'].",            0";
						$mysqldb->add($table, $fields, $vars);
					}
				}			
			
				
			}
		}
	}	
//============================================================
	public function previous_expance($company_id,$d1)
	{
		global $mysqldb;
		
		$d2 = date("Y-m-d",(strtotime($d1) - 86400));

		$table = "`temp_table`";
		$field = "c_in";
		$where = "`dt` BETWEEN '1970-01-01' AND '$d2'";	
		$ca_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		
		$table = "`temp_table`";
		$field = "c_out";
		$where = "`dt` BETWEEN '1970-01-01' AND '$d2'";	
		$ca_out = $mysqldb->total_amount($table, $field, $where, $limit=false);		
		
		$x = $ca_in - $ca_out;
		return $x; 
	}
	
}
$account_chart_information = new account_chart_information_class();
?>	
	
	