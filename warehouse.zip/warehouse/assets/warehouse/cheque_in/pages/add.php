<?php
session_start();
// add.php
date_default_timezone_set("Asia/Dhaka");
$title ="Cheque In (Deposit)";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
require_once ('../classes/cheque_in_class.php');

$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];

if(isset($_POST['submit']))
{
	$idt = $_POST['idt'];
	$ibank_account_id = $_POST['ibank_account_id'];
	$iaccount_chart_id = $_POST['iaccount_chart_id'];
	$icash_source_id = $_POST['icash_source_id'];
	$icheque_no = $_POST['icheque_no'];
	$icheque_dt = $_POST['icheque_dt'];
	$iamount = $_POST['iamount'];
	$icause = $_POST['icause'];
	$icompany_id = $company_id;
	
	$table = "`cheque_in`";
	$fields = "`dt`,   `bank_account_id`,   `account_chart_id`,   `cash_source_id`,   `cheque_no`,   `cheque_dt`,   `amount`,   `cause`,   `company_id`";
	$vars = "'$idt',   $ibank_account_id,  $iaccount_chart_id,    $icash_source_id, '$icheque_no', '$icheque_dt',   $iamount, '$icause',   $icompany_id";

		$a = $mysqldb->add($table, $fields, $vars);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Saved Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Saving Error!.";
 	 	}

 	echo "<script>window.location.href='index.php';</script>";
}

// for the name and accounts numbers ===============================
$id = $_GET['id'];
$table = "bank_account";
$where = "`id` = $id";
$bank_ac_name = $mysqldb->select_one_row($table, $where, $orderBy=false);


function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-xs-10">
		<h3 class="text-primary">Cheque In (Deposit)</h3>
		<p class="text-warning">Name: <?php echo $bank_ac_name['name'];?><br>Account Name: <?php echo $bank_ac_name['ac_no'];?></p>
 	</div>
 	<div class="col-xs-2 text-right">
		<br>
 	 	<a href="index.php" class="btn btn-default" id="close" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span></a>
 	</div>
</div>	
<div class="row">
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="add.php" method="post">
 	 	 	<input type='hidden' class='form-control' id='ibank_account_id' name='ibank_account_id' value='<?php echo $id;?>'>

			<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='idt'>Date:<small><span id='infodt' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='idt' name='idt' value='<?php echo date("Y-m-d");?>' placeholder='Enter Date' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icash_source_id'>Source Type:<small><span id='infocash_source_id' class='text-warning'></span></small></label>
							<select class='form-control' id='icash_source_id' name='icash_source_id'>
							<?php
								$mysqldb->drop_down("cash_source", "id", "name",1, $where=false, "`name` ASC", $limit=false);
							?>
							</select>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iaccount_chart_id'>Chart Of Account:<small><span id='infoaccount_chart_id' class='text-warning'></span></small></label>
							
							<select class='form-control' id='iaccount_chart_id' name='iaccount_chart_id'>
							<?php
								$cheque_in->chart_ac_drop_down($company_id,1,1);
							?>
							</select>							
							
						</div>
					</div>

					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icheque_no'>Cheque No:<small><span id='infocheque_no' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='icheque_no' name='icheque_no' value='' placeholder='Enter Cheque No' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icheque_dt'>Cheque Date:<small><span id='infocheque_dt' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='icheque_dt' name='icheque_dt' value='<?php echo date("Y-m-d");?>' placeholder='Enter Cheque Date' maxlength=100>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='iamount'>Amount:<small><span id='infoamount' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='iamount' name='iamount' value='' placeholder='Enter Amount' maxlength=13>
						</div>
					</div>
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icause'>Cause:<small><span id='infocause' class='text-warning'></span></small></label>
							<input type='text' class='form-control' id='icause' name='icause' value='' placeholder='Enter Cause' maxlength=100>
						</div>
					</div>

					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Save">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
	<div class="col-sm-6">
	</div>
</div>	
<script>
 	$(document).ready(function(){
 	date_picker('idt');
	date_picker('icheque_dt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			if($('#idt').val() == ''){$('#infodt').html(' ** Please write dt'); return false;};
			if($('#icheque_no').val() == ''){$('#infocheque_no').html(' ** Please write cheque_no'); return false;};
			if($('#icheque_dt').val() == ''){$('#infocheque_dt').html(' ** Please write cheque_dt'); return false;};
			if($('#iamount').val() == ''){$('#infoamount').html(' ** Please write amount'); return false;};
			if($.isNumeric($('#iamount').val())==false){$('#infoamount').html(' ** Please write amount in numeric'); return false;};
			if($('#icause').val() == ''){$('#infocause').html(' ** Please write cause'); return false;};
 	 	
		
			var a = $("#balancetaka").val();
			var b = $('#iamount').val();
			var c = eval(a) - eval(b);
			var msg = " ** Balance not available ! (" + a + ")";
			if(c < 0)
			{
				$('#infoamount').html(msg);
				return false;
			}		
		
		})
 	 	
 	 $('[data-toggle="tooltip"]').tooltip();	
 
//--------------------Chart of Account Dropdown----------------------------------------------------------------
		$("#icash_source_id").click(function(){
			
			var cash_source_id = $('#icash_source_id').val();
			$.post("drop_down.php",
			{
				cash_source_id: cash_source_id,
				chart_id:1
				
			}, 
			function(result){

				$("#iaccount_chart_id").html(result);
			});

		})	 

 
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
