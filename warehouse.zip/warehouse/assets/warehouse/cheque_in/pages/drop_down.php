<?php
session_start();
require_once ('../../layout/load/load.php');
require_once ('../classes/cheque_in_class.php');

$company_id = $_SESSION["company_id"];
$sourceid = $_POST['cash_source_id'];
$selectedId = $_POST['chart_id'];

$cheque_in->chart_ac_drop_down($company_id,$sourceid,$selectedId);
?>






	
