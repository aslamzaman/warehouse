<?php
session_start();
// index.php
date_default_timezone_set("Asia/Dhaka");
$title ="Cheque In (Deposit)";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
require_once ('../classes/cheque_in_class.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];
if(isset($_GET['id']))
{
	$table = "`cheque_in`";
	$where = "`id` = ".$_GET['id'];
	
		$a = $mysqldb->remove($table, $where);
 	 	if($a)
 	 	{
 	 	 	$_SESSION["msg"] = "Deleted Successfully";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Deleting Error!";
 	 	}
		echo "<script>window.location.href='index.php';</script>";
}

function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary">Cheque In (Deposit)</h3>
 	</div>
 	<div class="col-sm-6" id="display">
		<?php
 	 	 	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
 	 	 	 	echo $_SESSION['msg'];
 	 	 	 	unset($_SESSION['msg']);
 	 	 	}
 	 	?>
 	</div>	
 	<div class="col-sm-6 text-right">
 	    <div class="btn-group btn-group-sm" id="hide">
		    <a href="index.php" class="btn btn-default" id="add" data-toggle='tooltip' data-placement='top' title='Close'><span class='glyphicon glyphicon-remove'></span> Close</a>
 	    </div>
 	</div>
 	<div class="col-sm-12">
		<div class="table-responsive">	
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Date</th>
						<th>Account Name</th>
						<th>From</th>
						<th>Cheque No</th>
						<th>Cheque Date</th>
						<th class='text-right'>Amount</th>
						<th>Cause</th>

						<th></th>
		
					</tr>
				</thead>
				<tbody>
				<?php
					$row = $mysqldb->select_all_row("`cheque_in`","`company_id`= $company_id", "`id` DESC", $limit=false);
					if(count($row) > 0)
					{
						foreach($row as $rows)
						{	
							echo "<tr>";
							echo "<td>".$rows['dt']."</td>";
							echo "<td>".$mysqldb->name_by_id("bank_account","name","id",$rows['bank_account_id'])."</td>";
							echo "<td>".$cheque_in->name_by_source_id($company_id,$rows['cash_source_id'],$rows['account_chart_id'])."</td>";
							echo "<td>".$rows['cheque_no']."</td>";
							echo "<td>".$rows['cheque_dt']."</td>";
							echo "<td class='text-right'>".$rows['amount']."</td>";
							echo "<td>".$rows['cause']."</td>";
							echo "<td>";
							echo "<div class='btn-group btn-group-xs' id='hide'>";
							echo "<a href='#' class='btn btn-default' id='".$rows['id']."' onclick='deletefunction(this.id)' data-toggle='tooltip' data-placement='top' title='Delete'><span class='glyphicon glyphicon-remove'></span></a>";						
							echo "</div>";
							echo "</td>";
							echo "</tr>";
		
						}
					}
				?>
				</tbody>
			</table>
		</div>	
 	</div>
</div>	
<script>
 	function deletefunction(id){
 	 	if (confirm("Are u sure?") == true){
 	 	 	window.location.href="show_list.php?id=" + id;
 	 	}
 	}
 	
 	$('[data-toggle="tooltip"]').tooltip();
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
