<?php

/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('Asia/Dhaka');

/** PHPExcel_IOFactory */
require_once dirname(__FILE__) . '/../../../plugins/phpexcel/Classes/PHPExcel/IOFactory.php';


// echo date('H:i:s') , " Load from Excel5 template" , EOL;

$objReader = PHPExcel_IOFactory::createReader('Excel5');
/* ------------    Border   ---------------- */
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);

/*  ================ Customize section ================  */
/* ------------------------------------------------------------------ */
$objPHPExcel = $objReader->load("../excel/x.xls"); /** Load Excel File */
//=========Statement Updae End======================= 

				
	$comId = "";
	$table = "`company`";
	$whereId = "`company_id` = $company_id";
	$com_name = $mysqldb->select_one_row($table, $whereId, $orderBy=false);

	if($com_name['print_show'] > 0)
	{
		$objPHPExcel->getActiveSheet()->setCellValue('A1',$com_name['name']);
		$objPHPExcel->getActiveSheet()->setCellValue('A2',$com_name['address'].", Mobile: ".$com_name['mobile']);
	}
	$objPHPExcel->getActiveSheet()->setCellValue('D4',date("Y-m-d"));
	
	/** -----------------------------------------------------------  */	
		
	$table = "`product`";
	$where = "`company_id`= $company_id AND id IN(SELECT `product_id` FROM product_in)";
	$orderBy = "`name` ASC";
	$p = $row = $mysqldb->select_all_row($table, $where, $orderBy, $limit=false);
	$i = 7;
	$r =array();
	if(count($p) > 0) 
	{
		foreach ($p as $q)
		{
			$avr = $stock->avg_rate_product_in($company_id,$q['id']);
			$t = $stock->balance_product($company_id,$q['id']);							
			
			$cd = $q['product_code']; 
			$nm = $q['name']; 
			
			$r =array("A$i","B$i","C$i","D$i");
			$objPHPExcel->getActiveSheet()->setCellValue($r[0],$nm);
			$objPHPExcel->getActiveSheet()->setCellValue($r[1],$cd);
			$objPHPExcel->getActiveSheet()->setCellValue($r[2],number_format($avr,2,'.',''));
			$objPHPExcel->getActiveSheet()->setCellValue($r[3],number_format($t,2,'.',''));
				$x = "$r[0]:$r[0]";
			$n =0;	
			while($n < 4)
			{								
				$x = "$r[$n]:$r[$n]";
				$objPHPExcel->getActiveSheet()->getStyle($x)->applyFromArray($styleThinBlackBorderOutline);
				$n++;
			}
			$i++;
			
		}
		
	}

echo "<a href='stock_balance_all_location.xlsx' class='btn btn-primary btn-xs'>Download <i class='fa fa-file-excel-o '></i> </a>";

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save(str_replace('.php', '.xlsx', __FILE__));

?>