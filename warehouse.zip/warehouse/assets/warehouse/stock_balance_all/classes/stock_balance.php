<?php
class stock_balance
{
	
	public function avg_rate_product_in($company_id,$id)
	{
		global $mysqldb;		
		$table = "product_in";
		$field = "sales_value";
		$where = "`product_id`= $id AND `company_id` = $company_id";	
		$x = $mysqldb->avg_amount($table, $field, $where, $limit=false);
		return $x;
	}
	
	
	public function balance_product($company_id,$id)
	{
		global $balance;
		$d2 = date("Y-m-d");
		$x = $balance->procuct_by_id($company_id,"1970-01-01",$d2,$id);
		return $x;
	}

	
}
$stock = new stock_balance();
?>	
	
	