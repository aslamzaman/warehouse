<?php

/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('Asia/Dhaka');

/** PHPExcel_IOFactory */
require_once dirname(__FILE__) . '/../../../plugins/phpexcel/Classes/PHPExcel/IOFactory.php';


// echo date('H:i:s') , " Load from Excel5 template" , EOL;

$objReader = PHPExcel_IOFactory::createReader('Excel5');
/* ------------    Border   ---------------- */
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);

/*  ================ Customize section ================  */
/* ------------------------------------------------------------------ */
$objPHPExcel = $objReader->load("../excel/x.xls"); /** Load Excel File */
//=========Statement Updae End======================= 
	
	
	/** Company Name and Address */
	$company = $company_name->show_phpexcel($company_id);
	$objPHPExcel->getActiveSheet()->setCellValue('A1',$company[0]);
	$objPHPExcel->getActiveSheet()->setCellValue('A2',$company[1]);
	$objPHPExcel->getActiveSheet()->setCellValue('A3',$company[2]);
	
	
	/** Date Today */
	$objPHPExcel->getActiveSheet()->setCellValue('B5',"Date: ".date("Y-m-d"));
	
	
	/** Temporary Table Data  */	
		$table = "`temp_table`";
		$orderBy ="`cash` DESC";
		$p = $mysqldb->select_all_row($table, $where=false, $orderBy, $limit=false);
			$i = 7;
			$r =array();		
		if(count($p) > 0) 
		{
			foreach ($p as $q)
			{
				
				$r =array("A$i","B$i");
				$objPHPExcel->getActiveSheet()->setCellValue($r[0],$q['name']);
				$objPHPExcel->getActiveSheet()->setCellValue($r[1],number_format($q['cash'],2,'.',''));
					$x = "";
					$n =0;	
					while($n < 2)
					{								
						$x = "$r[$n]:$r[$n]";
						$objPHPExcel->getActiveSheet()->getStyle($x)->applyFromArray($styleThinBlackBorderOutline);
						$n++;
					}
				$i++;
			}
				
				$total = $dues_information_all->total_duses;
				$objPHPExcel->getActiveSheet()->setCellValue($r[0],"Total Dues");
				$objPHPExcel->getActiveSheet()->getStyle($r[0])->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->setCellValue($r[1],number_format($total,2,'.',''));
				$objPHPExcel->getActiveSheet()->getStyle($r[1])->getFont()->setBold(true);

					$x = "";
					$n =0;	
					while($n < 2)
					{								
						$x = "$r[$n]:$r[$n]";
						$objPHPExcel->getActiveSheet()->getStyle($x)->applyFromArray($styleThinBlackBorderOutline);
						$n++;
					}		
		
		
		}
echo "<a href='dues_all.xlsx' class='btn btn-primary btn-xs'>Download <i class='fa fa-file-excel-o '></i> </a>";


$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save(str_replace('.php', '.xlsx', __FILE__));

?>