<?php
class days_summary_class
{
	
	public $tota=0;
	public function show_table($company_id,$d1,$d2)
	{	
		$this->product_in_out_balance($company_id,$d1,$d2);
		$this->cash_in_out_balance($company_id,$d1,$d2);
		$this->cheque_in_out_balance($company_id,$d1,$d2);
		
		$pIn = $this->producthIn;
		$pOut = $this->producthOut;
		$pB = $this->producthBalance;
		
		$cIn = $this->cashIn;
		$cOut = $this->cashOut;
		$cB = $this->cashBalance;
		
		$chIn = $this->chequehIn;
		$chOut = $this->chequehOut;
		$chB = $this->chequeBalance;

		
		echo "<tr>\n";		
		echo "<td>Product in</td>\n";
		echo "<td class='text-right'>".number_format($pIn,2)."</td>\n";				
		echo "</tr>\n";
		
		echo "<tr>\n";		
		echo "<td>Product out</td>\n";
		echo "<td class='text-right'>".number_format($pOut,2)."</td>\n";				
		echo "</tr>\n";	
		
		echo "<tr>\n";		
		echo "<td>Product balance (up to date)</td>\n";
		echo "<td class='text-right'>".number_format($pB,2)."</td>\n";				
		echo "</tr>\n";	

		echo "<tr>\n";		
		echo "<td colspan=2>&nbsp;</td>\n";
		echo "</tr>\n";			

		echo "<tr>\n";		
		echo "<td>Cash in</td>\n";
		echo "<td class='text-right'>".number_format($cIn,2)."</td>\n";				
		echo "</tr>\n";
		
		echo "<tr>\n";		
		echo "<td>Cash out</td>\n";
		echo "<td class='text-right'>".number_format($cOut,2)."</td>\n";				
		echo "</tr>\n";	
		
		echo "<tr>\n";		
		echo "<td>Cash balance (up to date)</td>\n";
		echo "<td class='text-right'>".number_format($cB,2)."</td>\n";				
		echo "</tr>\n";
		

		echo "<tr>\n";		
		echo "<td colspan=2>&nbsp;</td>\n";
		echo "</tr>\n";			
		
		
		echo "<tr>\n";		
		echo "<td>Cheque in</td>\n";
		echo "<td class='text-right'>".number_format($chIn,2)."</td>\n";				
		echo "</tr>\n";
		
		echo "<tr>\n";		
		echo "<td>Cheque out</td>\n";
		echo "<td class='text-right'>".number_format($chOut,2)."</td>\n";				
		echo "</tr>\n";	
		
		echo "<tr>\n";		
		echo "<td>Cheque balance (up to date)</td>\n";
		echo "<td class='text-right'>".number_format($chB,2)."</td>\n";				
		echo "</tr>\n";	


		echo "<tr>\n";		
		echo "<td colspan=2>&nbsp;</td>\n";
		echo "</tr>\n";			
		
		
		$z = $pB + $cB + $chB;
		echo "<tr>\n";		
		echo "<td><strong>Overall balance (up to date)</strong></td>\n";
		echo "<td class='text-right'><strong>".number_format($z,2)."</strong></td>\n";				
		echo "</tr>\n";

		$this->tota = $z;		
		
	}

	
	public $producthIn=0;
	public $producthOut=0;
	public $producthBalance=0;	
	public function product_in_out_balance($company_id,$d1,$d2)
	{
		global $balance;
		$a = $this->product_in($company_id,$d1,$d2);
		$b = $this->product_out($company_id,$d1,$d2);
		
		$e = $balance->product_value($company_id,"1970-01-01",$d2);
		
		$this->producthIn = $a;
		$this->producthOut = $b;
		$this->producthBalance =$e ;	
	}
	
	
	
/** ---------------------------------------------------- */	
	
	public function product_out($company_id,$d1,$d2)
	{
		global $db;
		$sql = "SELECT `qty` * `sales_value` as total FROM product_out  WHERE `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x = 0;
		if($Numrows > 0)
 	 	{
			$t = 0;
			while($rows= mysqli_fetch_array($result))
			{
				$t = $t + $rows['total'];
			}
			$x = $t;
		}
		else
		{
			$x = 0;	
		}
		return $x;
	}	
	

	public function product_in($company_id,$d1,$d2)
	{
		global $db;
		$sql = "SELECT `qty` * `unit_value` as total FROM product_in WHERE `company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";
		$result=mysqli_query($db, $sql);
 	 	$Numrows=mysqli_num_rows($result);
		$x = 0;
		if($Numrows > 0)
 	 	{
			$t = 0;
			while($rows= mysqli_fetch_array($result))
			{
				$t = $t + $rows['total'];
			}
			$x = $t;
		}
		else
		{
			$x = 0;	
		}
		return $x;
	}	


	

//============================================================
//============================================================

	
	
	public $cashIn=0;
	public $cashOut=0;
	public $cashBalance=0;
	public function cash_in_out_balance($company_id,$d1,$d2)
	{
		global $mysqldb;
		global $balance;
		$table = "`cash_in`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";		
		$cas_in = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */
		$table = "`cash_out`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";	
		$cas_out = $mysqldb->total_amount($table, $field, $where, $limit=false);		
		/** ---------------------------------------------------  */
		
		$x = $balance->cash($company_id,"1970-01-01",$d2);
		
		$this->cashIn=$cas_in ;
		$this->cashOut=$cas_out;
		$this->cashBalance=$x;
	}	


	public $chequehIn=0;
	public $chequehOut=0;
	public $chequeBalance=0;
	public function cheque_in_out_balance($company_id,$d1,$d2)
	{
		global $mysqldb;
		global $balance;
		$table = "`cheque_in`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";		
		$chequein = $mysqldb->total_amount($table, $field, $where, $limit=false);	
		/** -------------------------------------- */
		$table = "`cheque_out`";
		$field = "amount";
		$where = "`company_id`= $company_id AND `dt` BETWEEN '$d1' AND '$d2'";	
		$chequeout = $mysqldb->total_amount($table, $field, $where, $limit=false);		
		/** ---------------------------------------------------  */
		
		$x=$balance->cheque_value($company_id,"1970-01-01",$d2);
		
		$this->chequehIn=$chequein ;
		$this->chequehOut=$chequeout;
		$this->chequeBalance=$x;
	}	
	
}
$days_summary = new days_summary_class();
?>	
	
	