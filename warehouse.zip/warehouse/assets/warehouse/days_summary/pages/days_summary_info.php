<?php

/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('Asia/Dhaka');

/** PHPExcel_IOFactory */
require_once dirname(__FILE__) . '/../../../plugins/phpexcel/Classes/PHPExcel/IOFactory.php';


// echo date('H:i:s') , " Load from Excel5 template" , EOL;

$objReader = PHPExcel_IOFactory::createReader('Excel5');
/* ------------    Border   ---------------- */
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);

/*  ================ Customize section ================  */
/* ------------------------------------------------------------------ */
$objPHPExcel = $objReader->load("../excel/x.xls"); /** Load Excel File */
//=========Statement Updae End======================= 
	
	
	/** Company Name and Address */
	$company = $company_name->show_phpexcel($company_id);
	$objPHPExcel->getActiveSheet()->setCellValue('A1',$company[0]);
	$objPHPExcel->getActiveSheet()->setCellValue('A2',$company[1]);
	$objPHPExcel->getActiveSheet()->setCellValue('A3',$company[2]);
	
	
	/** Period */
	$objPHPExcel->getActiveSheet()->setCellValue('A5',"Period: ".$d1." to ". $d2);	
	
	
	/** Date Today */
	$objPHPExcel->getActiveSheet()->setCellValue('B5',"Date: ".date("Y-m-d"));
	
	
	/** Data  */
		$pIn = $days_summary->producthIn;
		$pOut = $days_summary->producthOut;
		$pB = $days_summary->producthBalance;
		
		$cIn = $days_summary->cashIn;
		$cOut = $days_summary->cashOut;
		$cB = $days_summary->cashBalance;
		
		$chIn = $days_summary->chequehIn;
		$chOut = $days_summary->chequehOut;
		$chB = $days_summary->chequeBalance;
		
		$g_total = $days_summary->tota;
		

		$objPHPExcel->getActiveSheet()->setCellValue('B7',$pIn);
		$objPHPExcel->getActiveSheet()->setCellValue('B8',$pOut);
		$objPHPExcel->getActiveSheet()->setCellValue('B9',$pB);
		
		$objPHPExcel->getActiveSheet()->setCellValue('B11',$cIn);
		$objPHPExcel->getActiveSheet()->setCellValue('B12',$cOut);
		$objPHPExcel->getActiveSheet()->setCellValue('B13',$cB);

		$objPHPExcel->getActiveSheet()->setCellValue('B15',$chIn);
		$objPHPExcel->getActiveSheet()->setCellValue('B16',$chOut);
		$objPHPExcel->getActiveSheet()->setCellValue('B17',$chB);

		$objPHPExcel->getActiveSheet()->setCellValue('B19',$g_total);		
		
echo "<a href='days_summary_info.xlsx' class='btn btn-primary btn-xs'>Download <i class='fa fa-file-excel-o '></i> </a>";


$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save(str_replace('.php', '.xlsx', __FILE__));

?>