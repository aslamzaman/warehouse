<?php
session_start();
// add.php
date_default_timezone_set("Asia/Dhaka");
$title ="Comments";
require_once ('../../layout/header/header.php');
require_once ('../../layout/load/load.php');
$company_id = $_SESSION["company_id"];
$pw_id = $_SESSION["pw_id"];

if(isset($_POST['submit']))
{
	$icomments = $_POST['icomments'];
	$iip_address = $mysqldb->getUserIpAddr();
	$icompany_id = $company_id;
	
	$table = "`comments`";
	$fields = "`comments`,   `ip_address`,   `company_id`";
	$vars = "'$icomments', '$iip_address',  $icompany_id";

		$a = $mysqldb->add($table, $fields, $vars);
 	 	if($a)
 	 	{
 	 	  $_SESSION["msg"] = "Messages successfully sent.";
 	 	}
 	 	else
 	 	{
 	 	 	$_SESSION["msg"] = "Error sending messages!";
 	 	}
 	 	
   //	 echo "<script>window.location.href='index.php';</script>";	

}
function customPageHeader(){?>	
 	<style>
 	 	@media print {
 	 	 	#hide{display: none;}
 	 	 	#add{display: none;}
 	 	 	@page{margin: 0;}
 	 	 	body{margin: 1.6cm;}
 	 	}
 	</style>
<?php };?>
	

<div class="row">
	<div class="col-sm-12">
		<h3 class="text-primary"></h3>
 	</div>
 	<div class="col-sm-12 text-info">
		&nbsp;
		<?php
 	 	 	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
 	 	 	 	echo $_SESSION['msg'];
 	 	 	 	unset($_SESSION['msg']);
 	 	 	}
 	 	?>
 	</div>	
	
	
 	<div class="col-sm-6">
 	 	<form class="form-horizontal" role="form" action="index.php" method="post">
 	 	 	<div class="row">
				<div class="col-sm-12">
					<div class='form-group'>
						<div class='col-sm-12'>
							<label for='icomments'>Please write your valuable comments or suggestion:<small><span id='infocomments' class='text-warning'></span></small></label>
							<textarea  class='form-control' id='icomments' name='icomments' rows="5" cols="100">
							</textarea>						
						</div>
					</div>
					<br>
					<input type="submit" class="btn btn-default" name="submit" id="submit" value="Send">
 	 	 	 	</div>
 	 	 	</div>
 	 	</form>	
 	</div>
</div>	
<script>
 	$(document).ready(function(){
 	// date_picker('idt');
 	 	$("#submit").click(function(){
 	 	 	$("form span").each(function(){
 	 	 	 	$(this).html("");
 	 	 	})
			
			if($("#icomments").val().trim().length < 1){$('#infocomments').html(' ** Please write your comments'); return false;};

 	 	})
 	 	
 	 $('[data-toggle="tooltip"]').tooltip();	
 	 	
 	})
</script>
<?php include "../../layout/footer/footer.php"; ?>






	
