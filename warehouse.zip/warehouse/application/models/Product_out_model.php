<?php 
    class Product_out_model extends  CI_Model{

        public function __construct()
        {
            parent::__construct();
            $this->db = $this->load->database("default",TRUE);
        }
    

    /**
    --------------------------------------------------------
    ========================================================
    --------------------------------------------------------
    */    
    
 
       public function product_in_select_all()
        {
			$this->db->select('`product_in`.`id`, `product_in`.`dt`, `product_in`.`product_id`, `product_in`.`qty`, `product_in`.`sales_value`');
            $this->db->select('`product`.`name` as `product`');
			$this->db->from('product_in`');
			
			$this->db->join('`product`','`product_in`.`product_id` = `product`.`id`','left');
			
			$this->db->order_by('product_in`.`id`','DESC');
            $query = $this->db->get();
			
            if($query->num_rows() > 0){
                return $query->result_array();
            }else{
                return FALSE;
            }
        }  

       public function out_all($id)
        {
			$this->db->select('sum(`qty`) as `out_total`');
			$this->db->group_by('`product_in_id`');			
			$this->db->where('`product_in_id`',$id);
            $query = $this->db->get('product_out`');
			
			//echo $this->db->last_query();exit();
            if($query->num_rows() > 0){
                return $query->row_array();
            }else{
                return FALSE;
            }
        }  
   
 

   
 
    /**
    --------------------------------------------------------
    ========================================================
    --------------------------------------------------------
    */
    
    
        public function add($data=array())
        {
			return $this->db->insert('product_out', $data);
        } 



    
    /**
    --------------------------------------------------------
    ========================================================
    --------------------------------------------------------
    */

    
    

        public function remove($id)
        {
            $this->db->where('id', $id);
            return $this->db->delete('product_out');
        }
    
    
    
    
    /**
    --------------------------------------------------------
    ========================================================
    --------------------------------------------------------
    */
    
    

      public function out_list()
        {
			$this->db->select('`product_out`.`id`, `product_out`.`dt`,`product_out`.`qty`,`product_out`.`rate`,`product_out`.`vat`,`product_out`.`tax`,((`product_out`.`qty`*`product_out`.`rate`) +`product_out`.`vat` + `product_out`.`tax`) as `total`');
            $this->db->select('`product`.`name`');
			$this->db->from('`product_out`');
			$this->db->join('`product_in`','`product_out`.`product_in_id` = `product_in`.`id`','left');
			$this->db->join('`product`','`product_in`.`product_id` = `product`.`id`','left');
			
			$this->db->order_by('`product_out`.`id`','DESC');
            $query = $this->db->get();
			//echo $this->db->last_query();exit();
			
            if($query->num_rows() > 0){
                return $query->result_array();
            }else{
                return FALSE;
            }
        }  

		
  

  
    
    
    /**
    --------------------------------------------------------
    ========================================================
    --------------------------------------------------------
    */
    
    

 

        public function drop_down_option($table,$selected_id)
        {
            $dropdown	= '';
            $this->db->select('`id`,`name`');
            $this->db->order_by('name','ASC');
            $query 		= $this->db->get($table);
            $result 	= $query->result_array();
            $dropdown .="\n";			
            foreach($result as $row)
            {
                if($selected_id == $row['id'])
                {
                    $dropdown .= "<option value=".$row['id']." selected>".$row['name']."</option>\n";
                }
                else
                {
                    $dropdown .= "<option value=".$row['id'].">".$row['name']."</option>\n";
                }
            }			
            return $dropdown;
        } 

    
    /**
    --------------------------------------------------------
    ========================================================
    --------------------------------------------------------
    */

      public function in_product($id)
        {
			$this->db->select('`qty`');
			$this->db->from('`product_in`');
			$this->db->where('id',$id);
            $query = $this->db->get();
            if($query->num_rows() > 0){
                return $query->row_array();
            }else{
                return FALSE;
            }
        } 
      public function balance_check($id)
        {
			$x = $this->in_product($id);
			$y = $this->out_all($id);
			$z = $x['qty'] - $y['out_total'];
            return $z;
        } 		



}

?>
 



