<?php 
    class Cheque_out_model extends  CI_Model{

        public function __construct()
        {
            parent::__construct();
            $this->db = $this->load->database("default",TRUE);
        }
    
    
    
    
    /**
    --------------------------------------------------------
    On load bank information and bank balance
    --------------------------------------------------------
    */
      public function select_bank()
        {
            $this->db->select('*');
            $this->db->order_by('name','ASC');
            $query = $this->db->get('bank_account');
            if($query->num_rows() > 0){
                return $query->result_array();
            }else{
                return FALSE;
            }
        }  
	
	
		public function cheque_in($id)
        {
            $this->db->select('sum(amount) as `in_total`');
            $this->db->group_by('bank_account_id');
			$this->db->where('bank_account_id',$id);
            $query = $this->db->get('cheque_in');
            if($query->num_rows() > 0){
                return $query->row_array();
            }else{
                return FALSE;
            }
        }  		
		
		public function cheque_out($id)
        {
            $this->db->select('sum(amount) as `out_total`');
            $this->db->group_by('bank_account_id');
			$this->db->where('bank_account_id',$id);
            $query = $this->db->get('cheque_out');
            if($query->num_rows() > 0){
                return $query->row_array();
            }else{
                return FALSE;
            }
        }  		

		
    /**
    --------------------------------------------------------
    Show add form
    --------------------------------------------------------
    */
       public function select_one_bank($id)
        {
            $this->db->where('id',$id);			
            $query = $this->db->get('bank_account');
           // echo $this->db->last_query();
			if($query->num_rows() > 0){
                return $query->row_array();
            }else{
                return FALSE;
            }
        }  
    
	
        public function drop_down_option($table,$selected_id)
        {
            $dropdown	= '';
            $this->db->select('`id`,`name`');
            $this->db->order_by('name','ASC');
            $query 		= $this->db->get($table);
            $result 	= $query->result_array();
            $dropdown .="\n";			
            foreach($result as $row)
            {
                if($selected_id == $row['id'])
                {
                    $dropdown .= "<option value=".$row['id']." selected>".$row['name']."</option>\n";
                }
                else
                {
                    $dropdown .= "<option value=".$row['id'].">".$row['name']."</option>\n";
                }
            }			
            return $dropdown;
        } 
 
        public function add($data=array())
        {
			return $this->db->insert('cheque_out', $data);
        } 

		
		

    /**
    --------------------------------------------------------
    view bank information
    --------------------------------------------------------
    */
       public function select_bank_info($id)
        {
			
			
			$this->db->select('`cheque_out`.`id`, `cheque_out`.`dt`,`cheque_out`.`cheque_no`,`cheque_out`.`cheque_dt`,`cheque_out`.`amount`');
			$this->db->select('`account_chart`.`name` as `bank`');
			$this->db->from('`cheque_out`');
			$this->db->join('`account_chart`','`cheque_out`.`account_chart_id` = `account_chart`.`id`', 'left');
			$this->db->where('`cheque_out`.`bank_account_id`',$id);
			$this->db->order_by('`cheque_out`.`id`','DESC');
			$this->db->limit('20');			
            $query = $this->db->get();
			
           // echo $this->db->last_query();exit();
			if($query->num_rows() > 0){
                return $query->result_array();
            }else{
                return FALSE;
            }
        }  
    	
	
    
	
	
    /**
    --------------------------------------------------------
    Remove data from cheque_in table
    --------------------------------------------------------
    */
        public function remove($id)
        {
            $this->db->where('id', $id);
            return $this->db->delete('cheque_out');
        }
    



}

?>
 



