<?php 
    class Product_in_model extends  CI_Model{

        public function __construct()
        {
            parent::__construct();
            $this->db = $this->load->database("default",TRUE);
        }
    
    
    
    
    /**
    --------------------------------------------------------
    ========================================================
    --------------------------------------------------------
    */
    
    
        public function add($data=array())
        {
			return $this->db->insert('product_in', $data);
        } 



    
    /**
    --------------------------------------------------------
    ========================================================
    --------------------------------------------------------
    */
    
        public function edit($data=array(), $id)
        {    
			$this->db->where('id', $id);
			return $this->db->update('product_in', $data);
        } 

    
    
    
    
    /**
    --------------------------------------------------------
    ========================================================
    --------------------------------------------------------
    */
    
    

        public function remove($id)
        {
            $this->db->where('id', $id);
            return $this->db->delete('product_in');
        }
    
    
    
    
    /**
    --------------------------------------------------------
    ========================================================
    --------------------------------------------------------
    */
    
    

      public function select_all()
        {
			$this->db->select('`product_in`.`id`, `product_in`.`dt`, `product_in`.`product_id`, `product_in`.`qty`, `product_in`.`unit_value`, `product_in`.`sales_value`, `product_in`.`description`, `product_in`.`account_chart_id`, `product_in`.`employee_id`, `product_in`.`location_id`');
            $this->db->select('`product`.`name` as `product`');
			$this->db->from('product_in`');
			$this->db->join('product`','`product_in`.`product_id` = `product`.`id`','left');
			$this->db->order_by('product_in`.`id`','DESC');
			$this->db->limit(20);
            $query = $this->db->get();
            if($query->num_rows() > 0){
                return $query->result_array();
            }else{
                return FALSE;
            }
        }  
    

       
  
    
    
    /**
    --------------------------------------------------------
    ========================================================
    --------------------------------------------------------
    */
    
    


       public function select_one($id)
        {
			$this->db->select('`product_in`.`id`, `product_in`.`dt`, `product_in`.`qty`, `product_in`.`unit_value`, `product_in`.`sales_value`, `product_in`.`description`');
            $this->db->select('`product`.`name` as `product`');
			$this->db->select('`account_chart`.`name` as `chart`');
			$this->db->select('`employee`.`name` as `employee`');
			$this->db->select('`location`.`name` as `location`');
			
			$this->db->from('product_in`');
			
			$this->db->join('product`','`product_in`.`product_id` = `product`.`id`','left');
			$this->db->join('account_chart`','`product_in`.`account_chart_id` = `account_chart`.`id`','left');
			$this->db->join('employee`','`product_in`.`employee_id` = `employee`.`id`','left');
			$this->db->join('location`','`product_in`.`location_id` = `location`.`id`','left');
			
			$this->db->where('product_in`.`id`',$id);

            $query = $this->db->get();
            if($query->num_rows() > 0){
                return $query->row_array();
            }else{
                return FALSE;
            }
        }  
    
   
    

        
        
        
        /**
        --------------------------------------------------------
        ========================================================
        --------------------------------------------------------
        */
        

 
 

        public function drop_down_option($table,$selected_id)
        {
            $dropdown	= '';
            $this->db->select('`id`,`name`');
            $this->db->order_by('name','ASC');
            $query 		= $this->db->get($table);
            $result 	= $query->result_array();
            $dropdown .="\n";			
            foreach($result as $row)
            {
                if($selected_id == $row['id'])
                {
                    $dropdown .= "<option value=".$row['id']." selected>".$row['name']."</option>\n";
                }
                else
                {
                    $dropdown .= "<option value=".$row['id'].">".$row['name']."</option>\n";
                }
            }			
            return $dropdown;
        } 


}

?>
 



