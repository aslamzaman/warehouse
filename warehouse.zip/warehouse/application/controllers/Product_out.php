<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Product_out extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_out_model');
		$this->load->library(array('session','form_validation'));
		$this->load->helper(array('form', 'url'));
	}
	
	public function balance_stock()
	{
		$all_product     	= $this->product_out_model->product_in_select_all();
		$data_arr 			= array();
		if($all_product)
		{
			$n = 0;
			foreach($all_product as $row)
			{
				$id 							= $row['id'];
				$out_qty     					= $this->product_out_model->out_all($id);
				$stock 							= $row['qty'] - $out_qty['out_total'];
				if($stock > 0)
				{
					$data_arr[$n]['id'] 			= $id;
					$data_arr[$n]['dt'] 			= $row['dt'];
					$data_arr[$n]['product'] 		= $row['product'];
					$data_arr[$n]['qty'] 			= $stock;
					$data_arr[$n]['sales_value'] 	= $row['sales_value'];
				}
				$n++;
			}
		}
		return $data_arr;
	}
	
	
	public function index()
	{
		$data['product_ins']     = $this->balance_stock();
		$this->load->view('layout/header');
		$this->load->view('layout/header_closing');
		$this->load->view('layout/navbar');
		$this->load->view('product_out/index',$data);
		$this->load->view('layout/footer');
		$this->load->view('layout/footer_closing');
	}


	public function out_list()
	{
		$data['product_outs']     = $this->product_out_model->out_list();
		$this->load->view('layout/header');
		$this->load->view('layout/header_closing');
		$this->load->view('layout/navbar');
		$this->load->view('product_out/out_list',$data);
		$this->load->view('layout/footer');
		$this->load->view('layout/footer_closing');
	}



	public function add($id)
	{
		
		$data['id']     		= $id;
		$data['employee']     	= $this->product_out_model->drop_down_option('employee',1);
		$data['check_qty']     	= $this->product_out_model->balance_check($id);
		
		$this->load->view('layout/header');
		$this->load->view('layout/header_closing');
		$this->load->view('layout/navbar');
		$this->load->view('product_out/add',$data);		
		$this->load->view('layout/footer');
		$this->load->view('product_out/js',$data);
		$this->load->view('layout/footer_closing');
	}


	public function save()
	{
		$this->form_validation->set_rules('dt', 'Date', 'required|max_length[10]');
		$this->form_validation->set_rules('qty', 'Qty', 'required|max_length[5]');
		$this->form_validation->set_rules('rate', 'Rate', 'required|max_length[11]');
		$this->form_validation->set_rules('vat', 'Vat', 'required|max_length[11]');
		$this->form_validation->set_rules('tax', 'Tax', 'required|max_length[11]');
		$this->form_validation->set_rules('description', 'Description', 'required|max_length[100]');
		$this->form_validation->set_rules('employee_id', 'Employee_id', 'required|max_length[50]');
		$this->form_validation->set_rules('product_in_id', 'Product_in_id', 'required|max_length[50]');
		
		$this->form_validation->set_error_delimiters('<span class="small text-danger"><i> *', '</i></span>'); 

		if ($this->form_validation->run())
		{
			$data['dt']            		= $this->input->post('dt');	
			$data['qty']            	= $this->input->post('qty');	
			$data['rate']    			= $this->input->post('rate');	
			$data['vat']            	= $this->input->post('vat');	
			$data['tax']            	= $this->input->post('tax');	
			$data['description']        = $this->input->post('description');	
			$data['employee_id']		= $this->input->post('employee_id');
			$data['product_in_id']		= $this->input->post('product_in_id'); 
			
			$ret = $this->product_out_model->add($data);
			if($ret)
			{
				$_SESSION['msg'] = 'Record saved successfully';
			}
			else
			{
				$_SESSION['msg'] = 'Record failed to save!';
			}
			redirect('product_out');
		}
		else
		{
			$this->add($this->input->post('product_in_id'));
		}
	}




	public function remove($id)
	{
		$ret = $this->product_out_model->remove($id);
		if($ret)
		{
			$_SESSION['msg'] = 'Record deleted successfully';
		}
		else
		{
			$_SESSION['msg'] = 'Record failed to delete!';
		}
		redirect('product_out');
	}

	

}	





