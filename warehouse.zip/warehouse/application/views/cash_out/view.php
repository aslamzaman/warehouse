 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	


<h1>Cash Out Information</h1>
<hr>
<div class="table-responsive">
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Description</th>
				<th>Data</th>
			</tr>
		</thead>
		<tbody>
		<?php
		if($cash_out)
		{
		?>
			<tr>
				<td>Date</td>
				<td><?php echo $cash_out['dt'];?></td>
			</tr>
			<tr>
				<td>Chart Account</td>
				<td><?php echo $cash_out['chart'];?></td>
			</tr>
			<tr>
				<td>Amount</td>
				<td><?php echo $cash_out['amount'];?></td>
			</tr>
			<tr>
				<td>Cause</td>
				<td><?php echo $cash_out['cause'];?></td>
			</tr>
		<?php
		}
		?>			
		</tbody>
	</table>
	<a href="<?php echo base_url('cash_out');?>" class="btn btn-danger">Close</a>
</div>
<!-- /.table-responsive -->
		
 

 
 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>
