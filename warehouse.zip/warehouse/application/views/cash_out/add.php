 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	
  
<h1>Add New Cash</h1>
<hr>
<form action="<?php echo base_url('cash_out/save');?>" method="post">
	<div class="form-group">
		<label for="dt">Date</label><?php echo form_error('dt'); ?>
		<input type="date" class="form-control" name="dt" value="<?php echo set_value('dt');?>">
	</div>
	<div class="form-group">
		<label for="account_chart_id">Chart of Account</label>
		<select class="form-control" name="account_chart_id">
			<?php echo $chart;?>
		</select>	
	</div>
	<div class="form-group">
		<label for="amount">Amount</label><?php echo form_error('amount'); ?>
		<input type="number" class="form-control" name="amount" value="<?php echo set_value('amount');?>">
	</div>
	<div class="form-group">
		<label for="cause">Cause</label><?php echo form_error('cause'); ?>
		<input type="text" class="form-control" name="cause" value="<?php echo set_value('cause');?>">
	</div>
	<button type="submit" class="btn btn-primary">Save</button>
	<a href="<?php echo base_url('cash_out');?>" class="btn btn-danger">Close</a>
</form>
<!-- /.form -->


 


 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div> 