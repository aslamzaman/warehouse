 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	

<h1>Cash Out Information</h1>
<hr>
<a href="<?php echo base_url('cash_out/add');?>" class="btn btn-primary">Add New</a>
<p class="text-danger"><i>
	<?php
	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
		echo $_SESSION['msg'];
		unset($_SESSION['msg']);
	}
	else
	{
		echo "Total Cash Balance: ". number_format($balance,2);		
	}	
	?>
</i></p>    
<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Date</th>
				<th>Account Chart</th>
				<th class='text-right'>Amount</th>
				<th class='text-right'>Actions</th>
			</tr>
		</thead>                
		<tbody>
			<?php 
			if($cash_outs)
			{ 
				foreach ($cash_outs as $cash_out)
				{
					$id = $cash_out['id'];
					$id1 = $cash_out['chart_id'];
					
					$t 		= strtotime(date("Y-m-d")) - strtotime($cash_out['dt']);
					$d 		= 86400*6;
					$link 	= "";
					if($t > $d)
					{
						$link 	= "#";
					}
					else
					{
						$link 	= base_url('cash_out/remove/'.$id);
					}
					?>
					<tr>
						<td><?php echo $cash_out['dt'];?></td>
						<td><?php echo $cash_out['chart'];?></td>
						<td class='text-right'><?php echo $cash_out['amount'];?></td>
						<td class='text-right' style='width:210px;'>
						  <a href="<?php echo base_url('cash_out/view/'.$id);?>" class="btn btn-primary btn-sm">View</a>
						  <a href="<?php echo base_url('cash_out/edit/'.$id.'/'.$id1);?>" class="btn btn-success btn-sm">Update</a>
						  <a href="<?php echo $link;?>" class="btn btn-warning btn-sm">Delete</a>
						</td>
					</tr>
					<?php 
				}
			}
			?>
		</tbody>
	</table>
</div>
<!-- /.table-responsive -->
 
 
 
 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>
