 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	

<h1>Product In Information</h1>
<hr>
<a href="<?php echo base_url('product_in/add');?>" class="btn btn-primary">Add New</a>
<p class="text-danger"><i>
	<?php
	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
		echo $_SESSION['msg'];
		unset($_SESSION['msg']);
	}
	else
	{
		echo "Product_in List";		
	}	
	?>
</i></p>    
<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Date</th>
				<th>Name</th>
				<th class='text-right'>Qty</th>
				<th class='text-right'>Rate</th>
				<th class='text-right'>Sale Value</th>
				<th class='text-right'>Actions</th>
			</tr>
		</thead>                
		<tbody>
			<?php 
			if($product_ins)
			{ 
				foreach ($product_ins as $product_in)
				{
					$id 	= $product_in['id'];
					$id1 	= $product_in['product_id'];
					$id2 	= $product_in['account_chart_id'];
					$id3 	= $product_in['employee_id'];
					$id4 	= $product_in['location_id'];
					
					
					$t 		= strtotime(date("Y-m-d")) - strtotime($product_in['dt']);
					$d 		= 86400*6;
					$link 	= "";
					if($t > $d)
					{
						$link 	= "#";
					}
					else
					{
						$link 	= base_url('product_in/remove/'.$id);
					}
					?>
					<tr>
						<td><?php echo $product_in['dt'];?></td>
						<td><?php echo $product_in['product'];?></td>
						<td class='text-right'><?php echo $product_in['qty'];?></td>
						<td class='text-right'><?php echo $product_in['unit_value'];?></td>
						<td class='text-right'><?php echo $product_in['sales_value'];?></td>
						<td class='text-right' style='width:210px;'>
						  <a href="<?php echo base_url('product_in/view/'.$id);?>" class="btn btn-primary btn-sm">View</a>
						  <a href="<?php echo base_url('product_in/edit/'.$id.'/'.$id1.'/'.$id2.'/'.$id3.'/'.$id4);?>" class="btn btn-success btn-sm">Update</a>
						  <a href="<?php echo $link;?>" class="btn btn-warning btn-sm">Delete</a>
						</td>
					</tr>
					<?php 
				}
			}
			?>
		</tbody>
	</table>
</div>
<!-- /.table-responsive -->
 
 
 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>
