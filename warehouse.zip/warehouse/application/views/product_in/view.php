 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->

<h1>Product In Information</h1>
<hr>
<div class="table-responsive">
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Description</th>
				<th>Data</th>
			</tr>
		</thead>
		<tbody>
		<?php
		if($product_in)
		{
		?>
			<tr>
				<td>Date</td>
				<td><?php echo $product_in['dt'];?></td>
			</tr>
			<tr>
				<td>Product Name</td>
				<td><?php echo $product_in['product'];?></td>
			</tr>
			<tr>
				<td>Quantity</td>
				<td><?php echo $product_in['qty'];?></td>
			</tr>
			<tr>
				<td>Rate</td>
				<td><?php echo $product_in['unit_value'];?></td>
			</tr>
			<tr>
				<td>Sale Value</td>
				<td><?php echo $product_in['sales_value'];?></td>
			</tr>
			<tr>
				<td>Description</td>
				<td><?php echo $product_in['description'];?></td>
			</tr>
			<tr>
				<td>Chart of Account</td>
				<td><?php echo $product_in['chart'];?></td>
			</tr>
			<tr>
				<td>Employee</td>
				<td><?php echo $product_in['employee'];?></td>
			</tr>
			<tr>
				<td>Location</td>
				<td><?php echo $product_in['location'];?></td>
			</tr>

		<?php
		}
		?>			
		</tbody>
	</table>
	<a href="<?php echo base_url('product_in');?>" class="btn btn-danger">Close</a>
</div>
<!-- /.table-responsive -->
		
 

 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>
