 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
 
<h1>Add New Product</h1>
<hr>
<form action="<?php echo base_url('product_in/save');?>" method="post">
	<div class="form-group">
		<label for="dt">Date</label><?php echo form_error('dt'); ?>
		<input type="date" class="form-control" name="dt" value="<?php echo set_value('dt');?>">
	</div>
	<div class="form-group">
		<label for="product_id">Product</label>
		<select class="form-control" name="product_id" >
			<?php echo $product; ?>
		</select>
	</div>
	<div class="form-group">
		<label for="qty">Quantity</label><?php echo form_error('qty'); ?>
		<input type="number" class="form-control" name="qty" value="<?php echo set_value('qty');?>">
	</div>
	<div class="form-group">
		<label for="unit_value">Rate</label><?php echo form_error('unit_value'); ?>
		<input type="number" class="form-control" name="unit_value" value="<?php echo set_value('unit_value');?>">
	</div>
	<div class="form-group">
		<label for="sales_value">Sale Value</label><?php echo form_error('sales_value'); ?>
		<input type="number" class="form-control" name="sales_value" value="<?php echo set_value('sales_value');?>">
	</div>
	<div class="form-group">
		<label for="description">Description</label><?php echo form_error('description'); ?>
		<input type="text" class="form-control" name="description" value="<?php echo set_value('description');?>">
	</div>
	<div class="form-group">
		<label for="account_chart_id">Chart of Account</label>
		<select class="form-control" name="account_chart_id" >
			<?php echo $chart; ?>
		</select>
	</div>
	<div class="form-group">
		<label for="employee_id">Employee Name</label>
		<select class="form-control" name="employee_id" >
			<?php echo $employee; ?>
		</select>
	</div>
	<div class="form-group">
		<label for="location_id">Location</label>
		<select class="form-control" name="location_id">
			<?php echo $location; ?>
		</select>
	</div>
	<button type="submit" class="btn btn-primary">Save</button>
	<a href="<?php echo base_url('product_in');?>" class="btn btn-danger">Close</a>
</form>
<!-- /.form -->


 	
 


 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div> 