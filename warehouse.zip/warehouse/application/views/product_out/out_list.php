 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	
<h1>Product Out List</h1>
<hr>
<a href="<?php echo base_url('product_out');?>" class="btn btn-primary"><span class="glyphicon glyphicon-remove"></span> Close</a>
<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Date</th>
				<th>Product_id</th>
				<th class='text-right'>Qty</th>
				<th class='text-right'>Rate</th>
				<th class='text-right'>Total</th>
				<th class='text-right'>Actions</th>
			</tr>
		</thead>                
		<tbody>
			<?php 
			if($product_outs)
			{ 
				foreach ($product_outs as $product_out)
				{
					$id = $product_out['id'];
					$t 		= strtotime(date("Y-m-d")) - strtotime($product_out['dt']);
					$d 		= 86400*6;
					$link_delete 	= "";
					if($t > $d)
					{
						$link_delete 	= "#";
					}
					else
					{
						$link_delete 	= base_url('product_out/remove/'.$id);
					}										
					?>
					<tr>
						<td><?php echo $product_out['dt'];?></td>
						<td><?php echo $product_out['name'];?></td>
						<td class='text-right'><?php echo $product_out['qty'];?></td>
						<td class='text-right'><?php echo $product_out['rate'];?></td>

						<td class='text-right'><?php echo $product_out['total'];?></td>
						<td class='text-right' style='width:80px;'>
						  <a href="<?php echo $link_delete;?>" class="btn btn-warning btn-sm">Delete</a>
						</td>
					</tr>
					<?php 
				}
			}
			?>
		</tbody>
	</table>
</div>
<!-- /.table-responsive -->
 

 
 
 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>
