 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	

<h1>Edit Product Out</h1>
<hr>
<form action="<?php echo base_url('product_out/update');?>" method="post">
	<input type="hidden" class="form-control" name="id" value="<?php echo $product_out['id'];?>">
	<div class="form-group">
		<label for="dt">Date</label><?php echo form_error('dt'); ?>
		<input type="date" class="form-control" name="dt" value="<?php if(set_value('dt') != NULL){echo set_value('dt');}else{echo $product_out['dt'];}?>">
	</div>
	<div class="form-group">
		<label for="product_id">Product_id</label><?php echo form_error('product_id'); ?>
		<input type="text" class="form-control" name="product_id" value="<?php if(set_value('product_id') != NULL){echo set_value('product_id');}else{echo $product_out['product_id'];}?>">
	</div>
	<div class="form-group">
		<label for="qty">Qty</label><?php echo form_error('qty'); ?>
		<input type="number" class="form-control" name="qty" value="<?php if(set_value('qty') != NULL){echo set_value('qty');}else{echo $product_out['qty'];}?>">
	</div>
	<div class="form-group">
		<label for="sales_value">Sales_value</label><?php echo form_error('sales_value'); ?>
		<input type="number" class="form-control" name="sales_value" value="<?php if(set_value('sales_value') != NULL){echo set_value('sales_value');}else{echo $product_out['sales_value'];}?>">
	</div>
	<div class="form-group">
		<label for="vat">Vat</label><?php echo form_error('vat'); ?>
		<input type="number" class="form-control" name="vat" value="<?php if(set_value('vat') != NULL){echo set_value('vat');}else{echo $product_out['vat'];}?>">
	</div>
	<div class="form-group">
		<label for="tax">Tax</label><?php echo form_error('tax'); ?>
		<input type="number" class="form-control" name="tax" value="<?php if(set_value('tax') != NULL){echo set_value('tax');}else{echo $product_out['tax'];}?>">
	</div>
	<div class="form-group">
		<label for="description">Description</label><?php echo form_error('description'); ?>
		<input type="text" class="form-control" name="description" value="<?php if(set_value('description') != NULL){echo set_value('description');}else{echo $product_out['description'];}?>">
	</div>
	<div class="form-group">
		<label for="account_chart_id">Account_chart_id</label><?php echo form_error('account_chart_id'); ?>
		<input type="text" class="form-control" name="account_chart_id" value="<?php if(set_value('account_chart_id') != NULL){echo set_value('account_chart_id');}else{echo $product_out['account_chart_id'];}?>">
	</div>
	<div class="form-group">
		<label for="employee_id">Employee_id</label><?php echo form_error('employee_id'); ?>
		<input type="text" class="form-control" name="employee_id" value="<?php if(set_value('employee_id') != NULL){echo set_value('employee_id');}else{echo $product_out['employee_id'];}?>">
	</div>
	<div class="form-group">
		<label for="location_id">Location_id</label><?php echo form_error('location_id'); ?>
		<input type="text" class="form-control" name="location_id" value="<?php if(set_value('location_id') != NULL){echo set_value('location_id');}else{echo $product_out['location_id'];}?>">
	</div>
	<div class="form-group">
		<label for="product_in_id">Product_in_id</label><?php echo form_error('product_in_id'); ?>
		<input type="text" class="form-control" name="product_in_id" value="<?php if(set_value('product_in_id') != NULL){echo set_value('product_in_id');}else{echo $product_out['product_in_id'];}?>">
	</div>
	<button type="submit" class="btn btn-primary">Save</button>
	<a href="<?php echo base_url('product_out');?>" class="btn btn-danger">Close</a>
</form>
<!-- /.form -->
 

	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div> 