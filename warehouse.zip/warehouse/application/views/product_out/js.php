<script>
$(document).ready(function(){
  $("#save").click(function(){
	 var x = $("#check_qty").val();
	 var y = $("#qty").val();
	 if(y > x)
	 {
		$("#show").html('Balance not available!(<?php echo $check_qty;?>)');return false;
	 }
	 else
	 {
		$("#form").submit();
	 }
	
  });

});
</script>