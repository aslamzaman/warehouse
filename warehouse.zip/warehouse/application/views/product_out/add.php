 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
 
 
<h1>Product Out</h1>
<hr>
<p class="text-danger"><i>
<span id="show">
	<?php
		echo "Balance Product: ".$check_qty;
	?>
</span>
</i></p>
<form action="<?php echo base_url('product_out/save');?>" method="post" id="form">
	<input type="hidden" class="form-control" name="product_in_id" value="<?php echo $id;?>">
	<input type="hidden" class="form-control" id="check_qty" name="check_qty" value="<?php echo $check_qty;?>">
	<div class="form-group">
		<label for="dt">Date</label><?php echo form_error('dt'); ?>
		<input type="date" class="form-control" name="dt" value="<?php echo set_value('dt');?>">
	</div>

	<div class="form-group">
		<label for="qty">Qty</label><?php echo form_error('qty'); ?>
		<input type="number" class="form-control" name="qty"  id="qty" value="<?php echo set_value('qty');?>">
	</div>
	<div class="form-group">
		<label for="rate">Rate</label><?php echo form_error('rate'); ?>
		<input type="number" class="form-control" name="rate" value="<?php echo set_value('rate');?>">
	</div>
	<div class="form-group">
		<label for="vat">Vat</label><?php echo form_error('vat'); ?>
		<input type="number" class="form-control" name="vat" value="<?php echo set_value('vat');?>">
	</div>
	<div class="form-group">
		<label for="tax">Tax</label><?php echo form_error('tax'); ?>
		<input type="number" class="form-control" name="tax" value="<?php echo set_value('tax');?>">
	</div>
	<div class="form-group">
		<label for="employee_id">Employee</label>
		<select class="form-control" name="employee_id">
		<?php echo $employee;?>
		</select>
	</div>
	<div class="form-group">
		<label for="description">Description</label><?php echo form_error('description'); ?>
		<input type="text" class="form-control" name="description" value="<?php echo set_value('description');?>">
	</div>
	<input type="button" class="btn btn-primary" value="Save" id="save">
	<a href="<?php echo base_url('product_out');?>" class="btn btn-danger">Close</a>
</form>
<!-- /.form -->


 
 


 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div> 