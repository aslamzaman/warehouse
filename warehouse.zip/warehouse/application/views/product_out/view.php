 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->



<h1>Product_out Information</h1>
<hr>
<div class="table-responsive">
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Description</th>
				<th>Data</th>
			</tr>
		</thead>
		<tbody>
		<?php
		if($product_out)
		{
		?>
			<tr>
				<td>Id</td>
				<td><?php echo $product_out['id'];?></td>
			</tr>
			<tr>
				<td>Dt</td>
				<td><?php echo $product_out['dt'];?></td>
			</tr>
			<tr>
				<td>Product_id</td>
				<td><?php echo $product_out['product_id'];?></td>
			</tr>
			<tr>
				<td>Qty</td>
				<td><?php echo $product_out['qty'];?></td>
			</tr>
			<tr>
				<td>Sales_value</td>
				<td><?php echo $product_out['sales_value'];?></td>
			</tr>
			<tr>
				<td>Vat</td>
				<td><?php echo $product_out['vat'];?></td>
			</tr>
			<tr>
				<td>Tax</td>
				<td><?php echo $product_out['tax'];?></td>
			</tr>
			<tr>
				<td>Description</td>
				<td><?php echo $product_out['description'];?></td>
			</tr>
			<tr>
				<td>Account_chart_id</td>
				<td><?php echo $product_out['account_chart_id'];?></td>
			</tr>
			<tr>
				<td>Employee_id</td>
				<td><?php echo $product_out['employee_id'];?></td>
			</tr>
			<tr>
				<td>Location_id</td>
				<td><?php echo $product_out['location_id'];?></td>
			</tr>
			<tr>
				<td>Entry_dt</td>
				<td><?php echo $product_out['entry_dt'];?></td>
			</tr>
			<tr>
				<td>Product_in_id</td>
				<td><?php echo $product_out['product_in_id'];?></td>
			</tr>
		<?php
		}
		?>			
		</tbody>
	</table>
	<a href="<?php echo base_url('product_out');?>" class="btn btn-danger">Close</a>
</div>
<!-- /.table-responsive -->
		
 

 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>
