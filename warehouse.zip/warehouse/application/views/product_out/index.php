 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	

<h1>Product Out</h1>
<hr>
<a href="<?php echo base_url('product_out/out_list');?>" class="btn btn-primary"><span class="glyphicon glyphicon-list"></span> List</a>
<p class="text-danger"><i>
	<?php
	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
		echo $_SESSION['msg'];
		unset($_SESSION['msg']);
	}
	else
	{
		echo "Product List";		
	}	
	?>
</i></p>    
<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Date</th>
				<th>Name</th>
				<th class='text-right'>Stock</th>
				<th class='text-right'>Sale Value</th>
				<th class='text-right'>Actions</th>
			</tr>
		</thead>                
		<tbody>
			<?php 
			if($product_ins)
			{ 
				foreach ($product_ins as $product_in)
				{
					$id 	= $product_in['id'];
					?>
					<tr>
						<td><?php echo $product_in['dt'];?></td>
						<td><?php echo $product_in['product'];?></td>
						<td class='text-right'><?php echo $product_in['qty'];?></td>
						<td class='text-right'><?php echo $product_in['sales_value'];?></td>
						
						<td class='text-right' style='width:80px;'>
						  <a href="<?php echo base_url('product_out/add/'.$id);?>" class="btn btn-primary btn-sm">Out <span class="glyphicon glyphicon-export"></span></a>
						</td>
					</tr>
					<?php 
				}
			}
			?>
		</tbody>
	</table>
</div>
<!-- /.table-responsive -->
 
 
 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>
