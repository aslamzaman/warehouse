 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	

<h1>Cheque In (Deposit)</h1>
<hr>
<p class="text-danger"><i>
	<?php
	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
		echo $_SESSION['msg'];
		unset($_SESSION['msg']);
	}
	else
	{
		echo "Bank Information";		
	}	
	?>
</i></p>    
<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th></th>
				<th>Bank Name</th>
				<th>Account No</th>
				<th class='text-right'>Balance</th>
				<th></th>
			</tr>
		</thead>                
		<tbody>
			<?php 
			if($banks)
			{ 
				foreach ($banks as $bank)
				{
					$id = $bank['id'];
					?>
					<tr>
						<td style='width:70px;'>
						  <a href="<?php echo base_url('cheque_in/add/'.$id);?>" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-import"></span></a>
						</td>						
						<td><?php echo $bank['name'];?></td>
						<td><?php echo $bank['ac_no'];?></td>
						<td class='text-right'><?php echo $bank['balance'];?></td>
						<td style='width:70px;'>
						  <a href="<?php echo base_url('cheque_in/bank_info/'.$id);?>" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-list"></span> View</a>
						</td>						
					</tr>
					<?php 
				}
			}
			?>
		</tbody>
	</table>
</div>
<!-- /.table-responsive -->
 
 
 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>
