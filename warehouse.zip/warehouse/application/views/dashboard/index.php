

<div class="container">    
  <div class="row">
    <div class="col-sm-4">
	<!--   ------------***-------------  -->
		<h1>Dashboard</h1>
		<hr>	
	
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>