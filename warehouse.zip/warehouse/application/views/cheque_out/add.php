 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	
 
<h1>Cheque Out (Withdrawal)</h1>
<hr>
<h3>Bank Name: <?php echo $bank['name'];?></h3>
<p>Account No.<?php echo $bank['ac_no'];?></p>


<form action="<?php echo base_url('cheque_out/save');?>" method="post">
	<input type="hidden" name="bank_account_id" value="<?php echo $bank['id'] ;?>">	
	<div class="form-group">
		<label for="dt">Date</label><?php echo form_error('dt'); ?>
		<input type="date" class="form-control" name="dt" value="<?php echo set_value('dt');?>">
	</div>
	<div class="form-group">
		<label for="account_chart_id">Chart of Account</label>
		<select class="form-control" name="account_chart_id">
		<?php echo $ac_charts;?>
		</select>
	</div>
	<div class="form-group">
		<label for="cheque_no">Cheque No</label><?php echo form_error('cheque_no'); ?>
		<input type="number" class="form-control" name="cheque_no" value="<?php echo set_value('cheque_no');?>">
	</div>
	<div class="form-group">
		<label for="cheque_dt">Cheque Date</label><?php echo form_error('cheque_dt'); ?>
		<input type="Date" class="form-control" name="cheque_dt" value="<?php echo set_value('cheque_dt');?>">
	</div>
	<div class="form-group">
		<label for="amount">Amount</label><?php echo form_error('amount'); ?>
		<input type="number" class="form-control" name="amount" value="<?php echo set_value('amount');?>">
	</div>
	<div class="form-group">
		<label for="cause">Cause</label><?php echo form_error('cause'); ?>
		<input type="text" class="form-control" name="cause" value="<?php echo set_value('cause');?>">
	</div>
	<button type="submit" class="btn btn-primary">Save</button>
	<a href="<?php echo base_url('cheque_out');?>" class="btn btn-danger">Close</a>
</form>
<!-- /.form -->


 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div> 