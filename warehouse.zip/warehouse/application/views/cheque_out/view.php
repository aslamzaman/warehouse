 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	

<h1>Cheque Out (Withdrawal)</h1>
<hr>
<h3>Bank Name: <?php echo $bank_info['name'];?></h3>
<p>Account No.<?php echo $bank_info['ac_no'];?></p>
<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Date</th>
				<th>To</th>
				<th>Cheque No</th>
				<th>Cheque Date</th>
				<th class='text-right'>Amount</th>
				<th></th>
			</tr>
		</thead>                
		<tbody>
			<?php 
			if($banks)
			{ 
				foreach ($banks as $bank)
				{
					$id 	= $bank['id'];
					$t 		= strtotime(date("Y-m-d")) - strtotime($bank['dt']);
					$d 		= 86400*6;
					$link 	= "";
					if($t > $d)
					{
						$link 	= "#";
					}
					else
					{
						$link 	= base_url('cheque_out/remove/'.$id);
					}
					?>
					<tr>
						<td><?php echo $bank['dt'];?></td>
						<td><?php echo $bank['bank'];?></td>
						<td><?php echo $bank['cheque_no'];?></td>
						<td><?php echo $bank['cheque_dt'];?></td>
						<td class='text-right'><?php echo $bank['amount'];?></td>
						<td class='text-right' style='width:80px;'>
						  <a href="<?php echo $link;?>" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-delete"></span> Delete</a>
						</td>						
					</tr>
					<?php 
				}
			}
			?>
		</tbody>
	</table>
</div>
<!-- /.table-responsive -->
<a href="<?php echo base_url('cheque_out');?>" class="btn btn-danger">Close</a> 
 
 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>
