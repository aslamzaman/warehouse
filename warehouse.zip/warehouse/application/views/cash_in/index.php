 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	

<h1>Cash In Information</h1>
<hr>
<a href="<?php echo base_url('cash_in/add');?>" class="btn btn-primary">Add New</a>
<p class="text-danger"><i>
	<?php
	if(isset($_SESSION['msg']) && !empty($_SESSION['msg'])){
		echo $_SESSION['msg'];
		unset($_SESSION['msg']);
	}
	else
	{
		echo "Total Cash Balance: ". number_format($balance,2);		
	}	
	?>
</i></p>    
<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Date</th>
				<th>Account Chart</th>
				<th class='text-right'>Amount</th>
				<th class='text-right'>Actions</th>
			</tr>
		</thead>                
		<tbody>
			<?php 
			if($cash_ins)
			{ 
				foreach ($cash_ins as $cash_in)
				{
					$id = $cash_in['id'];
					$id1 = $cash_in['chart_id'];
					
					$t 		= strtotime(date("Y-m-d")) - strtotime($cash_in['dt']);
					$d 		= 86400*6;
					$link_update 	= "";
					$link_delete 	= "";
					if($t > $d)
					{
						$link_update 	= "#";
						$link_delete 	= "#";
					}
					else
					{
						$link_update 	= base_url('cash_in/edit/'.$id.'/'.$id1);
						$link_delete 	= base_url('cash_in/remove/'.$id);
					}
					?>
					<tr>
						<td><?php echo $cash_in['dt'];?></td>
						<td><?php echo $cash_in['chart'];?></td>
						<td class='text-right'><?php echo $cash_in['amount'];?></td>
						<td class='text-right' style='width:210px;'>
						  <a href="<?php echo base_url('cash_in/view/'.$id);?>" class="btn btn-primary btn-sm">View</a>
						  <a href="<?php echo $link_update;?>" class="btn btn-success btn-sm">Update</a>
						  <a href="<?php echo $link_delete;?>" class="btn btn-warning btn-sm">Delete</a>
						</td>
					</tr>
					<?php 
				}
			}
			?>
		</tbody>
	</table>
</div>
<!-- /.table-responsive -->
 
 
 
 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>
