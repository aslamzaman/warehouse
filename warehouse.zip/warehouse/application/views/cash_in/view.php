 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	


<h1>Cash In Information</h1>
<hr>
<div class="table-responsive">
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Description</th>
				<th>Data</th>
			</tr>
		</thead>
		<tbody>
		<?php
		if($cash_in)
		{
		?>
			<tr>
				<td>Date</td>
				<td><?php echo $cash_in['dt'];?></td>
			</tr>
			<tr>
				<td>Chart Account</td>
				<td><?php echo $cash_in['chart'];?></td>
			</tr>

			<tr>
				<td>Amount</td>
				<td><?php echo $cash_in['amount'];?></td>
			</tr>
			<tr>
				<td>Cause</td>
				<td><?php echo $cash_in['cause'];?></td>
			</tr>
		<?php
		}
		?>			
		</tbody>
	</table>
	<a href="<?php echo base_url('cash_in');?>" class="btn btn-danger">Close</a>
</div>
<!-- /.table-responsive -->
		
 

 
 
	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div>
