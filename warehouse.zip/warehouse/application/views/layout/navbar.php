
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?php echo base_url('dashboard');?>">Home</a></li>
		<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Settings <span class="caret"></span></a>
			<ul class="dropdown-menu">
			
				<li class="dropdown-header">Products</li>	
				<li><a href="<?php echo base_url('product_in');?>">Products In</a></li>
				<li><a href="<?php echo base_url('product_out');?>">Products Out</a></li>
				<li class="divider"></li>
				<li class="dropdown-header">Cash</li>	
				<li><a href="<?php echo base_url('cash_in');?>">Cash In</a></li>
				<li><a href="<?php echo base_url('cash_out');?>">Cash Out</a></li>
				<li class="divider"></li>
				<li class="dropdown-header">Cheque</li>	
				<li><a href="<?php echo base_url('cheque_in');?>">Cheque In</a></li>	
				<li><a href="<?php echo base_url('cheque_out');?>">Cheque Out</a></li>
				<li>&nbsp;</li>
				<li>&nbsp;</li>				
			
			
			
			
				<li><a href="<?php echo base_url('customer');?>">Customer</a></li>
				<li><a href="<?php echo base_url('items');?>">Items</a></li>
				<li><a href="<?php echo base_url('sale');?>">Sale</a></li>
				<li><a href="<?php echo base_url('acpayable');?>">Acpayable</a></li>
				<li><a href="<?php echo base_url('acpayable_paid');?>">Acpayable Paid</a></li>
				<li><a href="<?php echo base_url('payment');?>">Payment</a></li>
				<li><a href="<?php echo base_url('lc');?>">LC</a></li>
				<li><a href="<?php echo base_url('arpaid');?>">Arpaid</a></li>
				<li><a href="<?php echo base_url('expenditure');?>">Expenditure</a></li>
				<li><a href="<?php echo base_url('invoice');?>">Bill/Invoice</a></li>
				<li><a href="<?php echo base_url('settings');?>">Settings</a></li>				
				<li><a href="<?php echo base_url('all_dues');?>">All Dues</a></li>
				<li><a href="<?php echo base_url('customer_history');?>">Customer History</a></li>
				<li><a href="<?php echo base_url('expenditure_show');?>">Expenditure Show</a></li>
				<li><a href="<?php echo base_url('yearly_less');?>">Yearly Less</a></li>
				
			</ul>
		</li>
        <li><a href="#">Products</a></li>
        <li><a href="#">Deals</a></li>
        <li><a href="#">Stores</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Your Account</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
      </ul>
    </div>
  </div>
</nav>

