 
<div class="container">    
  <div class="row">
    <div class="col-sm-12">
	<!--   ------------***-------------  -->
	

	
	<!--   ------------***-------------  -->
    </div>
  </div>
</div> 